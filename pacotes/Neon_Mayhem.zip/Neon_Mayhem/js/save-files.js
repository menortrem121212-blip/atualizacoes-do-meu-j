/* Packaged SAVES folder support. The APK's assets are read-only; live edits
   stay in the app's private WebView storage. A predios.json bundled before
   packaging seeds a fresh installation automatically. */
(function () {
  'use strict';
  window.GAME = window.GAME || {};
  GAME.SAVES = {
    loadPackagedBuildings: function () {
      // Never overwrite an existing device save with the packaged template.
      try {
        if (localStorage.getItem('neonMayhemBuildingDimsV3') !== null) return;
      } catch (_) { return; }
      function apply(data) {
        if (!data || data.game !== 'neon-mayhem' || data.type !== 'building-dimensions' || !data.buildings || typeof data.buildings !== 'object') return;
        var clean = {};
        Object.keys(data.buildings).forEach(function (id) {
          var v = data.buildings[id], w = Number(v && v.w), d = Number(v && v.d), h = Number(v && v.h);
          if (isFinite(w) && isFinite(d) && isFinite(h) && w > 0 && d > 0 && h > 0) clean[id] = { w:w, d:d, h:h };
        });
        try { localStorage.setItem('neonMayhemBuildingDimsV3', JSON.stringify(clean)); } catch (_) { return; }
        if (!GAME.city || !GAME.city.editableBuildings) return;
        GAME.city.editableBuildings.forEach(function (rec) {
          var v = clean[rec.id];
          if (!v || !rec.mesh || !rec.solid) return;
          rec.mesh.scale.set(v.w, v.h, v.d);
          rec.mesh.updateMatrix(); rec.mesh.updateMatrixWorld(true);
          if (rec.mesh.geometry) { rec.mesh.geometry.computeBoundingBox(); rec.mesh.geometry.computeBoundingSphere(); }
          GAME.city.hash.remove(rec.solid);
          rec.solid.minX = rec.x - rec.base.w * v.w / 2;
          rec.solid.maxX = rec.x + rec.base.w * v.w / 2;
          rec.solid.minZ = rec.z - rec.base.d * v.d / 2;
          rec.solid.maxZ = rec.z + rec.base.d * v.d / 2;
          rec.solid.h = rec.base.h * v.h;
          GAME.city.hash.insert(rec.solid);
          rec.dims = { w:v.w, d:v.d, h:v.h };
        });
      }
      // XHR also works in common offline WebView wrappers that expose app assets.
      try {
        var xhr = new XMLHttpRequest();
        xhr.open('GET', 'SAVES/predios.json', true);
        xhr.onload = function () { if (xhr.status === 0 || (xhr.status >= 200 && xhr.status < 300)) { try { apply(JSON.parse(xhr.responseText)); } catch (_) {} } };
        xhr.send();
      } catch (_) {}
    }
  };
})();

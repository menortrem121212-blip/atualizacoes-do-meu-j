/* Vehicle dimension editor: scales the complete existing vehicle hierarchy and
   keeps the collision dimensions in sync. It is deliberately additive. */
(function () {
  'use strict';
  var root = document.getElementById('vehicle-editor');
  if (!root) return;
  var $ = function (id) { return document.getElementById(id); };
  var active = false, selected = null, original = null, tapAt = 0, lastTap = null;
  var raycaster = new THREE.Raycaster(), pointer = new THREE.Vector2();
  var controls = $('ve-controls'), status = $('ve-status');
  // Close hides the floating panel without disabling the game; reopen it from Settings.
  var closeBtn = $('ve-close');
  if (closeBtn) closeBtn.addEventListener('click', function (e) {
    e.preventDefault(); e.stopPropagation();
    root.classList.remove('open'); root.setAttribute('aria-hidden', 'true');
    active = false; if ($('ve-toggle')) $('ve-toggle').textContent = 'ATIVAR';
    if (GAME.hud && GAME.hud.setPaused) GAME.hud.setPaused(false);
  });
  // Controles permanentes do menu: mover e ajustar tamanho no celular.
  (function bindMenuTools(){
    var card = $('vehicle-editor-card');
    var move = $('ve-move-menu');
    var slider = $('ve-menu-size');
    var output = $('ve-menu-size-value');
    if (!card || !move || !slider || !output) return;

    slider.addEventListener('pointerdown', function(e){ e.stopPropagation(); });
    slider.addEventListener('input', function(){
      var value = Number(slider.value);
      card.style.zoom = String(value / 100);
      output.textContent = value + '%';
    });

    var drag = null;
    move.addEventListener('pointerdown', function(e){
      if (e.button !== undefined && e.button !== 0) return;
      var rect = root.getBoundingClientRect();
      drag = { id:e.pointerId, x:e.clientX, y:e.clientY, left:rect.left, top:rect.top };
      root.style.position = 'fixed';
      root.style.transform = 'none';
      root.style.margin = '0';
      root.style.left = rect.left + 'px';
      root.style.top = rect.top + 'px';
      root.style.right = 'auto';
      root.style.bottom = 'auto';
      root.style.width = Math.min(rect.width, window.innerWidth - 12) + 'px';
      try { move.setPointerCapture(e.pointerId); } catch (_) {}
      e.preventDefault();
      e.stopPropagation();
    });
    move.addEventListener('pointermove', function(e){
      if (!drag || e.pointerId !== drag.id) return;
      var rect = root.getBoundingClientRect();
      root.style.left = Math.max(0, Math.min(window.innerWidth - rect.width, drag.left + e.clientX - drag.x)) + 'px';
      root.style.top = Math.max(0, Math.min(window.innerHeight - rect.height, drag.top + e.clientY - drag.y)) + 'px';
    });
    function stop(e){ if (drag && (e.pointerId === undefined || e.pointerId === drag.id)) drag = null; }
    move.addEventListener('pointerup', stop);
    move.addEventListener('pointercancel', stop);
  })();
  var dimsStore = {};
  try { dimsStore = JSON.parse(localStorage.getItem('neonMayhemVehicleDims') || '{}') || {}; } catch (_) {}

  // Every imported 3D file has its own numeric ID (ID 1, ID 2, ...).
  // Saved dimensions are isolated by that ID, so changing one GLB never changes
  // another vehicle that merely shares its generic category (sedan/van/sports).
  // Built-in vehicles keep a separate stable key by their own vehicle type.
  // One strict key space for all 48 catalog entries:
  // IDs 1–24 = exact imported GLB; IDs 25+ = exact native VEHICLES type.
  // Never fall back to generic type keys, because a GLB and a native vehicle
  // can share a category such as "sports" and must remain independent.
  function keyFor(car) {
    if (!car) return 'vehicle-id:unknown';
    if (car._townModelId != null) return 'vehicle-id:' + Number(car._townModelId);
    if (car._nativeVehicleId != null) return 'vehicle-id:' + Number(car._nativeVehicleId);
    var types = Object.keys(VEHICLES || {}), idx = types.indexOf(car.type);
    if (idx >= 0) return 'vehicle-id:' + (25 + idx);
    var modelKey = car.editorModelKey || car._townModelKey;
    return modelKey ? 'vehicle-model:' + modelKey : 'vehicle-type:' + (car.type || 'unknown');
  }
  function baseDims(car) {
    // Freeze the untouched factory dimensions and mesh scale once per instance.
    // Never derive a new baseline from an already edited vehicle: doing so made
    // successive edits compound and caused NPC/spawned copies to diverge.
    if (!car.editorBase) {
      var factory = (VEHICLES && VEHICLES[car.type]) || car.spec || {};
      car.editorBase = { w: factory.w || car.spec.w || 1, l: factory.l || car.spec.l || 1, h: factory.h || factory.height || car.spec.h || car.spec.height || 1, sx: car.mesh.scale.x || 1, sy: car.mesh.scale.y || 1, sz: car.mesh.scale.z || 1 };
    }
    return car.editorBase;
  }
  function apply(car, vals) {
    var b = baseDims(car);
    car.mesh.scale.set(b.sx * vals.w, b.sy * vals.h, b.sz * vals.l);
    // Physics uses per-instance specs; do not mutate the shared VEHICLES table.
    car.spec.w = b.w * vals.w; car.spec.l = b.l * vals.l;
    if (car.spec.h !== undefined) car.spec.h = b.h * vals.h;
    if (car.spec.height !== undefined) car.spec.height = b.h * vals.h;
    car.radius = car.spec.l * 0.42;
    car.editorDims = { w: vals.w, l: vals.l, h: vals.h };
    car.mesh.updateMatrixWorld(true);
  }
  function values() { return { w: +$('ve-width').value, l: +$('ve-length').value, h: +$('ve-height').value }; }
  function showValues(v) {
    $('ve-width').value = v.w; $('ve-length').value = v.l; $('ve-height').value = v.h;
    $('ve-width-value').textContent = v.w.toFixed(2) + '×';
    $('ve-length-value').textContent = v.l.toFixed(2) + '×';
    $('ve-height-value').textContent = v.h.toFixed(2) + '×';
  }
  function closeEditor() {
    root.classList.remove('open'); root.setAttribute('aria-hidden', 'true');
    active = false; selected = null; original = null;
    if (GAME.hud && GAME.hud.setPaused) GAME.hud.setPaused(false);
  }
  function selectCar(car) {
    if (!car || car.gone || !car.mesh) return;
    selected = car;
    // Ensure physics specs are instance-local before any dimension edit.
    if (!car.editorSpecCloned) { car.spec = Object.assign({}, car.spec); car.editorSpecCloned = true; }
    var b = baseDims(car), saved = dimsStore[keyFor(car)];
    var v = saved || car.editorDims || { w: 1, l: 1, h: 1 };
    original = { w: v.w, l: v.l, h: v.h };
    showValues(v); controls.hidden = false;
    status.textContent = 'Selecionado: ' + ((GAME.vehicles.TYPES[car.type] || {}).label || car.type) + ' — ajuste as dimensões.';
    apply(car, v);
  }
  function hitTest(e) {
    var renderer = GAME.renderer, camera = GAME.cameraObj;
    if (!renderer || !camera || !GAME.world || !GAME.world.cars) return null;
    var rect = renderer.domElement.getBoundingClientRect();
    pointer.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    pointer.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
    raycaster.setFromCamera(pointer, camera);
    var meshes = [];
    GAME.world.cars.forEach(function (c) { if (c && !c.gone && c.mesh) meshes.push(c.mesh); });
    var hits = raycaster.intersectObjects(meshes, true);
    if (!hits.length) return null;
    var obj = hits[0].object;
    while (obj && obj.parent && !obj.userData.__vehicleRoot) obj = obj.parent;
    var cars = GAME.world.cars;
    for (var i = 0; i < cars.length; i++) if (cars[i] && cars[i].mesh && (cars[i].mesh === obj || cars[i].mesh === hits[0].object || isChild(hits[0].object, cars[i].mesh))) return cars[i];
    return null;
  }
  function isChild(obj, parent) { while (obj) { if (obj === parent) return true; obj = obj.parent; } return false; }
  function onCanvasTap(e) {
    if (!active || e.target.closest('#vehicle-editor') || !GAME.renderer || e.target !== GAME.renderer.domElement) return;
    var now = Date.now(), car = hitTest(e);
    if (!car) { lastTap = null; return; }
    if (lastTap === car && now - tapAt < 420) { selectCar(car); lastTap = null; e.preventDefault(); }
    else { lastTap = car; tapAt = now; }
  }
  function onRange() {
    var v = values(); showValues(v);
    if (selected) apply(selected, v);
  }
  $('ve-toggle').addEventListener('click', function () {
    active = !active;
    $('ve-toggle').textContent = active ? 'DESATIVAR' : 'ATIVAR';
    status.textContent = active ? 'Editor ativo: dê dois toques em um veículo.' : 'Editor desativado.';
    if (!active) { selected = null; controls.hidden = true; }
  });
  ['ve-width','ve-length','ve-height'].forEach(function (id) { $(id).addEventListener('input', onRange); });
  $('ve-save').addEventListener('click', function () {
    if (!selected) { status.textContent = 'Selecione um veículo primeiro.'; return; }
    var v = values(); apply(selected, v); dimsStore[keyFor(selected)] = v;
    // Store only this exact model key. Different 3D variants keep their own factory proportions.
    try { localStorage.setItem('neonMayhemVehicleDims', JSON.stringify(dimsStore)); } catch (_) {}
    original = { w: v.w, l: v.l, h: v.h };
    // Update every live copy of this exact 3D model immediately. Other variants
    // of the same category keep their own factory proportions and independent scale.
    var savedKey = keyFor(selected), selectedType = selected.type;
    if (GAME.world && GAME.world.cars) GAME.world.cars.forEach(function (car) {
      if (!car || car.gone || !car.mesh) return;
      if (keyFor(car) !== savedKey) return;
      if (!car.editorSpecCloned) { car.spec = Object.assign({}, car.spec); car.editorSpecCloned = true; }
      try { apply(car, v); } catch (_) {}
    });
    status.textContent = '✅ Salvo! Todos os veículos deste modelo foram atualizados.';
    var toast = document.getElementById('vehicle-dim-save-toast');
    if (!toast) { toast = document.createElement('div'); toast.id = 'vehicle-dim-save-toast'; toast.style.cssText = 'position:fixed;left:50%;top:18px;transform:translateX(-50%);z-index:20000;padding:11px 16px;border-radius:10px;background:rgba(12,120,77,.94);border:1px solid #8affc6;color:white;font:800 13px system-ui;box-shadow:0 4px 18px #0006;pointer-events:none;text-align:center;'; document.body.appendChild(toast); }
    toast.textContent = '✓ Tamanho salvo para todos os veículos ' + (selectedType || 'deste modelo');
    toast.style.display = 'block'; clearTimeout(toast._hideTimer); toast._hideTimer = setTimeout(function(){ toast.style.display = 'none'; }, 2600);
  });
  $('ve-cancel').addEventListener('click', function () {
    if (!selected || !original) { controls.hidden = true; return; }
    apply(selected, original); showValues(original); status.textContent = 'Alterações não salvas canceladas.';
  });
  $('ve-reset').addEventListener('click', function () {
    if (!selected) { status.textContent = 'Selecione um veículo primeiro.'; return; }
    var one = { w: 1, l: 1, h: 1 }; apply(selected, one); showValues(one);
    delete dimsStore[keyFor(selected)]; try { localStorage.setItem('neonMayhemVehicleDims', JSON.stringify(dimsStore)); } catch (_) {}
    original = one; status.textContent = 'Dimensões originais restauradas apenas neste veículo.';
  });
  $('pause-vehicle-editor').addEventListener('click', function (e) {
    e.preventDefault(); e.stopPropagation();
    if (GAME.paused && GAME.togglePause) GAME.togglePause();
    root.classList.add('open'); root.setAttribute('aria-hidden', 'false');
    active = false; $('ve-toggle').textContent = 'ATIVAR'; controls.hidden = true;
    status.textContent = 'Ative o editor e dê dois toques em um veículo.';
  });
  document.addEventListener('pointerup', onCanvasTap, true);
  // Called by townvehicles.js after it assigns a specific imported model.
  // It also works for built-in vehicles and later spawns.
  GAME.vehicleEditorApplySavedDimensions = function (car) {
    if (!car || car.gone || !car.mesh) return;
    if (car._townModelId == null && car._nativeVehicleId == null) { var nativeTypes = Object.keys(VEHICLES || {}), nativeIndex = nativeTypes.indexOf(car.type); if (nativeIndex >= 0) car._nativeVehicleId = 25 + nativeIndex; }
    var saved = dimsStore[keyFor(car)];
    if (!saved && !car.editorDims) return;
    var target = saved || car.editorDims || { w: 1, l: 1, h: 1 };
    // spawnCar and townvehicles may both notify us for the same instance.
    // Do not scale twice when the model and dimensions are already applied.
    if (car.editorDims && Math.abs(car.editorDims.w-target.w)<0.0001 && Math.abs(car.editorDims.l-target.l)<0.0001 && Math.abs(car.editorDims.h-target.h)<0.0001) return;
    if (!car.editorSpecCloned) { car.spec = Object.assign({}, car.spec); car.editorSpecCloned = true; }
    // If a town GLB was just assigned, townvehicles.js marks it as replaced;
    // otherwise preserve the original baseline so saved multipliers never stack.
    if (car._vehicleMeshReplaced) { car.editorBase = null; car._vehicleMeshReplaced = false; }
    apply(car, target);
  };

  // Reapply only the saved multiplier for this exact model; each mesh keeps its own original scale.
  var originalSpawn = GAME.vehicles && GAME.vehicles.spawnCar;
  if (originalSpawn) GAME.vehicles.spawnCar = function () {
    var car = originalSpawn.apply(this, arguments);
    try { GAME.vehicleEditorApplySavedDimensions(car); } catch (_) {}
    return car;
  };
  // Catch vehicles that already existed when this script was loaded.
  if (GAME.world && GAME.world.cars) GAME.world.cars.forEach(function (car) {
    try { GAME.vehicleEditorApplySavedDimensions(car); } catch (_) {}
  });
  // Keep the game usable without a full-page reload.
  root.addEventListener('dblclick', function (e) { e.stopPropagation(); });
})();

GAME.hud = (function () {
  // the line a route is drawn in, on the big map and on the radar: a fifth
  // heavier than it was, so it can be followed at a glance rather than found
  var ROUTE_W = 3.0, RADAR_ROUTE_W = 2.9;
  var el = {};
  var lastClock = -1;
  // what the per-tick readouts last wrote, so a tick that changes nothing
  // builds no strings and touches no styles
  var lastHealthW = -1, lastArmorW = -1, lastAirPct = -2, lastAirCol = '', vehicleLine;
  var lastPoiHint = null;
  var shownCash = 0, targetCash = 0;
  var countT = 0, zoneT = 0, lastZone = '';
  var radioT = 0;
  // the star count as the HUD last drew it, so wantedChanged can tell going up
  // from coming down — nothing that calls it passes the level you were on
  var wantedShown = 0;
  var mapBuffer = null, MAP_S = 0.5, MAP_OX = 520, MAP_OY = 560;
  var MAP_W = 1020, MAP_H = 560;   // world -520..1520 by -560..560, at 0.5 px/m
  var dmgFlash = null;
  var PICKUP_BLIP = {
    pistol: '#eef0ff', smg: '#ffe14f', shotgun: '#ff8a3d',
    health: '#ff4d6a', armor: '#4a6cff', rifle: '#8dffd8',
    bat: '#ffd24a', knife: '#ffd24a', katana: '#ffd24a', chainsaw: '#ffd24a', grenade: '#ff8a3d', molotov: '#ff8a3d', sniper: '#8dffd8', rocket: '#ff6fb8'
  };

  function $(id) { return document.getElementById(id); }

  function init() {
    ['minimap', 'clock', 'cash', 'wanted-stars', 'health-fill', 'armor-fill', 'weapon-line', 'radio-popup', 'zone-popup',
      'msg-line', 'count-big', 'poi-hint', 'mission-hud', 'mission-title', 'mission-obj', 'mission-timer', 'title-screen', 'pause-screen',
      'wasted-screen', 'busted-screen', 'fade-layer', 'crt-layer', 'press-enter', 'title-best', 'pause-controls',
      'controls-bar', 'map-screen', 'bigmap', 'map-clear', 'map-close', 'pager', 'pager-face', 'pager-from', 'pager-text', 'enter-hint']
      .forEach(function (id) { el[id] = $(id); });
    var stars = '';
    for (var i = 0; i < 6; i++) stars += '<span>★</span>';
    el['wanted-stars'].innerHTML = stars;
    paintKeyHelp();

    dmgFlash = document.createElement('div');
    dmgFlash.style.cssText = 'position:fixed;inset:0;pointer-events:none;z-index:22;background:radial-gradient(ellipse at center, transparent 55%, rgba(255,30,60,.45) 100%);opacity:0;transition:opacity .35s;';
    document.body.appendChild(dmgFlash);

    buildMapBuffer();
    targetCash = shownCash = GAME.player.cash;
    updateCashText();
    // The trophy shelf, in plain words: how many marked missions have a
    // personal best on file, out of how many exist — "Best runs saved: 7"
    // answered a question nobody asked. While the channel is still closed,
    // the same count doubles as the road to the island, so say that too.
    var bests = GAME.bests || {};
    var defs = (GAME.missions && GAME.missions.DEFS) || [];
    var beaten = 0;
    for (var di = 0; di < defs.length; di++) if (bests[defs[di].id] !== undefined) beaten++;
    if (beaten) {
      var bl = 'Missões concluídas: ' + beaten + ' of ' + defs.length;
      if (GAME.isla && !GAME.isla.isOpen()) {
        var need = GAME.isla.required || 4;
        bl += '  ·  ' + Math.min(beaten, need) + ' of ' + need + ' rumo às pontes';
      }
      el['title-best'].textContent = bl + '  ·  Grana: $' + GAME.player.cash;
    } else if (GAME.player.cash !== 250) {
      el['title-best'].textContent = 'Grana: $' + GAME.player.cash;
    }

    el['press-enter'].addEventListener('click', function () { GAME.startGame(); });
    el['title-screen'].addEventListener('click', function () { GAME.startGame(); });
    // preventDefault matters: without it the browser follows the touch with a
    // synthetic mousedown ~300ms later — by then the title is hidden, the
    // click lands on the canvas, and the game opened with a punch or a shot
    el['title-screen'].addEventListener('touchend', function (e) { e.preventDefault(); GAME.startGame(); });

    // the in-game dialog's buttons; clicks must not fall through to whatever
    // screen is underneath (the pause screen resumes on any tap)
    ['click', 'touchend'].forEach(function (ev) {
      $('game-modal').addEventListener(ev, function (e) { e.stopPropagation(); e.preventDefault(); });
      $('game-modal-ok').addEventListener(ev, function (e) { e.stopPropagation(); e.preventDefault(); closeDialog(true); });
      $('game-modal-cancel').addEventListener(ev, function (e) { e.stopPropagation(); e.preventDefault(); closeDialog(false); });
    });

    // pause: RESUME, Esc, or a click or tap on the empty screen around the
    // menu carries on. Only the empty part: a press that just missed a button
    // (within a finger's width of one, which covers every gap between them)
    // does nothing, and neither does a drag that scrolled a short screen.
    var NEAR_MISS = 16;
    function offTheButtons(x, y) {
      var bs = el['pause-screen'].querySelectorAll('.mbtn');
      for (var i = 0; i < bs.length; i++) {
        var r = bs[i].getBoundingClientRect();
        if (!r.width) continue;   // hidden (ABANDON with nothing running)
        if (x > r.left - NEAR_MISS && x < r.right + NEAR_MISS && y > r.top - NEAR_MISS && y < r.bottom + NEAR_MISS) return false;
      }
      return true;
    }
    function pauseBackground(e, x, y) {
      var ps = el['pause-screen'];
      if (!GAME.paused || e.target.closest('a, input')) return false;
      if (x >= ps.getBoundingClientRect().left + ps.clientWidth) return false;   // its scrollbar
      // the card is somewhere to read, not empty screen
      var pr = $('pause-panel').getBoundingClientRect();
      if (x >= pr.left && x <= pr.right && y >= pr.top && y <= pr.bottom) return false;
      return offTheButtons(x, y);
    }
    el['pause-screen'].addEventListener('click', function (e) {
      if (pauseBackground(e, e.clientX, e.clientY)) GAME.togglePause();
    });
    var pauseTouch = null;
    el['pause-screen'].addEventListener('touchstart', function (e) {
      var t = e.changedTouches[0];
      pauseTouch = e.touches.length === 1 ? { x: t.clientX, y: t.clientY } : null;
    }, { passive: true });
    el['pause-screen'].addEventListener('touchend', function (e) {
      var t = e.changedTouches[0], s = pauseTouch;
      pauseTouch = null;
      if (!s || Math.abs(t.clientX - s.x) > 10 || Math.abs(t.clientY - s.y) > 10) return;
      if (!pauseBackground(e, t.clientX, t.clientY)) return;
      // no synthetic click after it, to land on whatever is under the menu
      e.preventDefault();
      GAME.togglePause();
    });
    function pauseBtn(id, fn) {
      var b = $(id);
      ['click', 'touchend'].forEach(function (ev) {
        b.addEventListener(ev, function (e) { e.stopPropagation(); e.preventDefault(); fn(); });
      });
    }
    // the sections: a tap opens one in the card
    var ptabs = el['pause-screen'].querySelectorAll('.ptab[data-panel]');
    for (var pt = 0; pt < ptabs.length; pt++) (function (t) {
      pauseBtn(t.id, function () { showPausePanel(t.getAttribute('data-panel')); pauseZone = 'tabs'; paintPauseSel(); });
    })(ptabs[pt]);
    pauseBtn('pause-resume', function () { if (GAME.paused) GAME.togglePause(); });
    pauseBtn('pause-map', function () { if (GAME.paused) GAME.togglePause(); api.toggleMap(true); });
    // Lola, called up (lola.js): the way a touchscreen reaches her
    pauseBtn('pause-lola', function () { if (GAME.lola) GAME.lola.open(); });
    // the cheat box (cheats.js): codes typed in
    pauseBtn('pause-cheats', function () { if (GAME.cheats) GAME.cheats.open(); });
    // walking away from a run, for the pad and the touchscreen as much as
    // anybody (X on a keyboard): shown only with one going, and asks once
    var abandonSure = false;
    function paintAbandon() {
      // (a stranger's favour walks away the same way: strangers.js)
      var b = $('pause-abandon'), a = GAME.missions && (GAME.missions.active || (GAME.strangers && GAME.strangers.activeJob) || (GAME.heist && GAME.heist.activeJob));
      b.style.display = a ? '' : 'none';
      if (!a) return;
      var what = a.def.job ? 'RELÓGIO DESLIGADO' : 'ABANDONAR MISSÃO';
      b.textContent = abandonSure ? '✖ ' + what + ' — TEM CERTEZA?' : '✖ ' + what;
      b.classList.toggle('danger', abandonSure);
    }
    api.paintAbandon = function (reset) { if (reset) abandonSure = false; paintAbandon(); };
    // Lola's first-time tips (lola.js), off for anybody who knows the town
    function paintTips() { $('pause-tips').textContent = (GAME.lola && !GAME.lola.tips) ? '💬 DICAS DA LOLA: DESLIGADAS' : '💬 DICAS DA LOLA: LIGADAS'; }
    pauseBtn('pause-tips', function () { if (GAME.lola) GAME.lola.setTips(!GAME.lola.tips); paintTips(); });
    paintTips();
    pauseBtn('pause-abandon', function () {
      if (!GAME.missions || !(GAME.missions.active || (GAME.strangers && GAME.strangers.busy) || (GAME.heist && GAME.heist.busy))) return;
      if (!abandonSure) { abandonSure = true; paintAbandon(); return; }
      abandonSure = false;
      if (GAME.paused) GAME.togglePause();
      GAME.missions.abandon();
    });
    // Mute is one switch however you reach it — the button here or M — and it
    // is remembered like the others. M used to flip the sound behind this
    // label's back (it still said SOUND) and nothing kept it past a reload.
    function paintMute() { $('pause-mute').textContent = GAME.audio.muted ? '🔇 MUDO' : '🔊 SOM'; }
    api.toggleMute = function () {
      var m = GAME.audio.toggleMute();
      if (GAME.prefs) { GAME.prefs.muted = m; GAME.save(); }
      paintMute();
      return m;
    };
    pauseBtn('pause-mute', function () { api.toggleMute(); });
    // music and effects are separate taps: kill the radio and keep the crashes,
    // or the other way round. The choice is remembered.
    function paintAudioBtns() {
      $('pause-music').textContent = GAME.audio.musicOn ? '🎵 MÚSICA: LIGADA' : '🎵 MÚSICA: DESLIGADA';
      $('pause-sfx').textContent = GAME.audio.sfxOn ? '💥 EFEITOS: LIGADOS' : '💥 EFEITOS: DESLIGADOS';
    }
    pauseBtn('pause-music', function () {
      GAME.audio.setMusicOn(!GAME.audio.musicOn);
      if (GAME.prefs) { GAME.prefs.musicOff = !GAME.audio.musicOn; GAME.save(); }
      paintAudioBtns();
    });
    pauseBtn('pause-sfx', function () {
      GAME.audio.setSfxOn(!GAME.audio.sfxOn);
      if (GAME.prefs) { GAME.prefs.sfxOff = !GAME.audio.sfxOn; GAME.save(); }
      paintAudioBtns();
    });
    if (GAME.prefs) {
      if (GAME.prefs.musicOff) GAME.audio.setMusicOn(false);
      if (GAME.prefs.sfxOff) GAME.audio.setSfxOn(false);
      if (GAME.prefs.muted && !GAME.audio.muted) GAME.audio.toggleMute();
    }
    paintAudioBtns();
    paintMute();
    // Rumble sits with the other outputs and is remembered the same way. The
    // button only appears where a buzz could actually happen: a phone with the
    // API. Desktop Chrome has navigator.vibrate and no motor to run it, and a
    // switch for something that cannot occur is worse than no switch.
    function paintHapticBtn() {
      $('pause-haptic').textContent = GAME.haptics.on ? '📳 VIBRAÇÃO: LIGADA' : '📳 VIBRAÇÃO: DESLIGADA';
    }
    if (GAME.isTouch && GAME.haptics.available) {
      pauseBtn('pause-haptic', function () {
        GAME.haptics.setOn(!GAME.haptics.on);
        // switching it on and feeling nothing reads as a promise rather than
        // as a thing that happened, so show what was just switched on
        if (GAME.haptics.on) GAME.haptics.demo();
        if (GAME.prefs) { GAME.prefs.rumbleOff = !GAME.haptics.on; GAME.save(); }
        paintHapticBtn();
      });
      if (GAME.prefs && GAME.prefs.rumbleOff) GAME.haptics.setOn(false);
      paintHapticBtn();
    } else {
      $('pause-haptic').style.display = 'none';
    }
    // How much the city fights with itself. A cycle rather than a slider,
    // because the other settings here are all buttons and a five-stop range
    // reads fine as one. It is on every platform: unlike rumble there is
    // nothing device-specific about wanting a quieter street.
    function paintChaosBtn() {
      $('pause-chaos').textContent = '🌆 CIDADE: ' + GAME.chaos.name;
    }
    pauseBtn('pause-chaos', function () {
      GAME.chaos.cycle();
      if (GAME.prefs) { GAME.prefs.chaos = GAME.chaos.level; GAME.save(); }
      paintChaosBtn();
      GAME.hud.message('Cidade ajustada para ' + GAME.chaos.name + '.', 2);
    });
    if (GAME.prefs && GAME.prefs.chaos !== undefined) GAME.chaos.set(GAME.prefs.chaos);
    paintChaosBtn();

    // Handedness, remembered like the rest. touch.init() runs before the save
    // is read, so the stored choice can only be applied from here — the same
    // reason the rumble switch above reads its pref at this point.
    function paintLeftyBtn() {
      $('pause-lefty').textContent = GAME.touch.lefty ? '🎮 CONTROLES: ESQUERDA' : '🎮 CONTROLES: DIREITA';
    }
    if (GAME.isTouch) {
      pauseBtn('pause-lefty', function () {
        GAME.touch.setLefty(!GAME.touch.lefty);
        if (GAME.prefs) { GAME.prefs.lefty = GAME.touch.lefty; GAME.save(); }
        paintLeftyBtn();
      });
      if (GAME.prefs && GAME.prefs.lefty) GAME.touch.setLefty(true);
      paintLeftyBtn();
    } else {
      $('pause-lefty').style.display = 'none';
    }
    pauseBtn('pause-crt', function () { GAME.hud.toggleCRT(); });
    pauseBtn('pause-keys', function () { GAME.controls.show(true); });
    // the bar of controls along the bottom, which only H could hide — out of
    // reach of a controller (touch screens never show it)
    function paintHintBar() {
      var b = $('pause-hintbar');
      if (!b) return;
      b.style.display = GAME.isTouch ? 'none' : '';
      b.textContent = GAME.prefs && GAME.prefs.hideCtl ? '💡 BARRA DE DICAS: DESLIGADA' : '💡 BARRA DE DICAS: LIGADA';
    }
    pauseBtn('pause-hintbar', function () { api.toggleControlsBar(); });
    // Full screen from the pause screen, which is the only way a controller
    // can ask for it: every button on a pad already has a job, and the one
    // left over (the Xbox / PS / Home button) is taken by the system before
    // a page sees it. A browser goes full screen only for a gesture, and not
    // every one counts a controller's press as one; where it does not, the
    // request would just be refused, so it waits for the next click, key or
    // tap and says so.
    pauseBtn('pause-fs', function () {
      var ua = navigator.userActivation;
      if (!GAME.fullscreenEl() && GAME.canFullscreen && GAME.controls && GAME.controls.usingPad() && ua && !ua.isActive) {
        GAME.fullscreenOnNextGesture();
        GAME.hud.message('Este navegador só abre a tela cheia após um clique, uma tecla ou um toque — o próximo que você fizer leva você para lá.', 5);
        return;
      }
      GAME.toggleFullscreen();
    });
    api.paintHintBar = paintHintBar;
    paintHintBar();
    // camera shake, for anyone it makes ill (remembered like the rest)
    function paintShakeBtn() { $('pause-shake').textContent = GAME.prefs && GAME.prefs.noShake ? '🎥 TREMOR: DESLIGADO' : '🎥 TREMOR: LIGADO'; }
    pauseBtn('pause-shake', function () {
      GAME.prefs = GAME.prefs || {};
      GAME.prefs.noShake = !GAME.prefs.noShake;
      GAME.save();
      paintShakeBtn();
    });
    paintShakeBtn();
    // graphics: resolution, draw distance and crowd, in three steps (main.js)
    function paintGfxBtn() { $('pause-gfx').textContent = '🖥 GRÁFICOS: ' + ({ high: 'ALTO', medium: 'MÉDIO', low: 'BAIXO', ultra: 'ULTRA' }[GAME.quality] || GAME.quality.toUpperCase()); }
    pauseBtn('pause-gfx', function () {
      var order = ['high', 'medium', 'low'];
      GAME.setQuality(order[(order.indexOf(GAME.quality) + 1) % order.length]);
      paintGfxBtn();
    });
    if (GAME.prefs && GAME.prefs.quality) GAME.setQuality(GAME.prefs.quality, true);
    paintGfxBtn();
    pauseBtn('pause-day', function () { api.refreshTimeBtn(GAME.cycleTimeMode()); });
    function paintWeatherBtn() { $('pause-weather').textContent = '🌧 CLIMA: ' + ({ auto: 'AUTO', clear: 'LIMPO', sunny: 'ENSOLARADO', fine: 'BOM', overcast: 'NUBLADO', rain: 'CHUVA', fog: 'NEBLINA' }[GAME.weather.mode] || GAME.weather.mode.toUpperCase()); }
    pauseBtn('pause-weather', function () { GAME.weather.cycle(); paintWeatherBtn(); });
    if (GAME.prefs && GAME.prefs.weather) GAME.weather.setMode(GAME.prefs.weather, true);
    paintWeatherBtn();
    api.refreshTimeBtn(GAME.timeMode);
    // the save travels: export downloads a file, import reads one back and
    // reloads into the imported life
    pauseBtn('pause-export', function () {
      var blob = new Blob([GAME.exportSave()], { type: 'application/json' });
      var a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = 'neon-mayhem-save.json';
      a.click();
      setTimeout(function () { URL.revokeObjectURL(a.href); }, 4000);
      GAME.track('save-exported');
    });
    pauseBtn('pause-import', function () {
      // an import is an overwrite: make sure the player knows the life they
      // are living right now is about to be replaced, and offer the way out
      dialog({
        title: 'IMPORTAR SAVE',
        body: 'Importar SUBSTITUI o seu progresso atual — grana, imóveis, garagem, seu visual, tudo.\nQuer manter essa vida? Cancele e use EXPORTAR SAVE antes.',
        ok: 'IMPORTAR E SOBRESCREVER', danger: true,
        onOk: function () {
          // a phone picks the file on a page with no city behind it (main.js
          // importScreen): the picker sends the tab to the background, where
          // a game this size is what Android reclaims first
          if (GAME.isTouch) { GAME.save(); location.hash = 'import'; location.reload(); return; }
          $('save-file').click();
        }
      });
    });
    pauseBtn('pause-reset', function () {
      // a reset is the import warning with no way back — so it points at the
      // way out first, then asks once more before burning it all down
      dialog({
        title: 'ZERAR PROGRESSO',
        body: 'Isso apaga TUDO — grana, missões, saltos acrobáticos, imóveis, garagem, seu visual, suas fotos. Não dá para desfazer.\nQuer um backup? Cancele e use EXPORTAR SAVE antes.',
        ok: 'APAGAR TUDO', danger: true,
        onOk: function () {
          dialog({
            title: 'ÚLTIMA CHANCE',
            body: 'Apagar o save e o álbum de fotos e começar Costa Rosa do zero?',
            ok: 'APAGAR O SAVE', danger: true,
            onOk: function () {
              GAME.track('progress-reset');
              // (the game's keys only: the origin is shared with other pages)
              try { (GAME.SAVE_KEYS || ['neonMayhemSave', 'nm_chaos']).forEach(function (k) { localStorage.removeItem(k); }); } catch (e) { }
              // ...and the photo album with it, before the page goes
              if (GAME.photo && GAME.photo.wipe) GAME.photo.wipe(function () { location.reload(); });
              else location.reload();
            }
          });
        }
      });
    });
    $('save-file').addEventListener('change', function () {
      var f = this.files && this.files[0];
      this.value = '';
      if (!f) return;
      var rd = new FileReader();
      rd.onload = function () {
        var r = GAME.importSave(String(rd.result));
        if (r.ok) { GAME.track('save-imported'); location.reload(); }
        else dialog({ title: 'FALHA AO IMPORTAR', body: r.why, ok: 'OK', cancel: false });
      };
      rd.onerror = function () { dialog({ title: 'FALHA AO IMPORTAR', body: 'Não foi possível ler esse arquivo.', ok: 'OK', cancel: false }); };
      rd.readAsText(f);
    });
    pauseBtn('pause-exit', function () { location.reload(); });
    // death screens: tap to skip the wait
    ['wasted-screen', 'busted-screen'].forEach(function (id) {
      ['click', 'touchend'].forEach(function (ev) {
        el[id].addEventListener(ev, function () { GAME.skipScreen = true; });
      });
    });
    // corner fullscreen button
    var fsb = $('fs-btn');
    ['click', 'touchend'].forEach(function (ev) {
      fsb.addEventListener(ev, function (e) { e.stopPropagation(); e.preventDefault(); GAME.toggleFullscreen(); });
    });
    api.refreshFsBtn();
    ['fullscreenchange', 'webkitfullscreenchange'].forEach(function (ev) {
      document.addEventListener(ev, function () { api.refreshFsBtn(); });
    });

    el['bigmap'].addEventListener('click', onMapClick);
    // the wheel zooms about the pointer, a drag pans (and is then not a
    // click), two fingers pinch
    el['bigmap'].addEventListener('wheel', function (e) {
      e.preventDefault();
      var r = el.bigmap.getBoundingClientRect();
      zoomMapAt(e.clientX - r.left, e.clientY - r.top, e.deltaY < 0 ? 1.35 : 1 / 1.35);
    }, { passive: false });
    var mapPtrs = {}, mapMoved = 0, pinchD = 0;
    el['bigmap'].addEventListener('pointerdown', function (e) {
      mapPtrs[e.pointerId] = { x: e.clientX, y: e.clientY };
      mapMoved = 0; pinchD = 0; mapDragged = false;
    });
    el['bigmap'].addEventListener('pointermove', function (e) {
      var p = mapPtrs[e.pointerId];
      if (!p) return;
      var ids = Object.keys(mapPtrs);
      if (ids.length >= 2) {
        p.x = e.clientX; p.y = e.clientY;
        var a = mapPtrs[ids[0]], b = mapPtrs[ids[1]];
        var d = Math.hypot(a.x - b.x, a.y - b.y), r = el.bigmap.getBoundingClientRect();
        if (pinchD > 0 && d > 0) zoomMapAt((a.x + b.x) / 2 - r.left, (a.y + b.y) / 2 - r.top, d / pinchD);
        pinchD = d; mapDragged = true;
        return;
      }
      var dx = e.clientX - p.x, dy = e.clientY - p.y;
      p.x = e.clientX; p.y = e.clientY;
      mapMoved += Math.abs(dx) + Math.abs(dy);
      if (mapMoved > 6 && mapZoom > 1) { mapDragged = true; mapPanX -= dx; mapPanY -= dy; drawBigMap(); }
    });
    ['pointerup', 'pointercancel', 'pointerleave'].forEach(function (ev) {
      el['bigmap'].addEventListener(ev, function (e) { delete mapPtrs[e.pointerId]; pinchD = 0; });
    });
    ['click', 'touchend'].forEach(function (ev) {
      $('map-zin').addEventListener(ev, function (e) { e.preventDefault(); e.stopPropagation(); api.mapZoom(1.5); });
      $('map-zout').addEventListener(ev, function (e) { e.preventDefault(); e.stopPropagation(); api.mapZoom(1 / 1.5); });
    });
    // the full map is drawn to size each time it opens (drawBigMap), so while
    // it is shut its canvas holds nothing — ~1.7 MB it used to keep for the
    // rest of the session after the first look
    el['bigmap'].width = el['bigmap'].height = 0;
    el['map-clear'].addEventListener('click', function () { GAME.nav.clear(); drawBigMap(); });
    el['map-close'].addEventListener('click', function () { api.toggleMap(false); });
    // like the pause screen: a click on the dark around the map closes it
    ['click', 'touchend'].forEach(function (ev) {
      el['map-screen'].addEventListener(ev, function (e) {
        if (e.target === el['map-screen']) { e.preventDefault(); api.toggleMap(false); }
      });
    });

    // legend entries behave like a mixer's solo buttons: tap one to show ONLY
    // that marker family, tap again to show all. The choice persists.
    mapSolo = (GAME.prefs && GAME.prefs.mapSolo) || null;
    if (mapSolo === 'icecream') mapSolo = 'shops';   // (a save from when the depot had its own row)
    refreshLegend();
  }

  // ---------- toggleable legend ----------
  var HOSPITAL_HEX = '#f2f4f8', DEST_HEX = '#c6ff3d', DEPOT_HEX = '#ffe9b0';
  var LEGEND = [
    ['#ff8a3d', 'Corrida', 'race'], ['#38e8ff', 'Courier', 'courier'], ['#ff4fa3', 'Fúria', 'rampage'], ['#ff3b3b', 'Caça ao Alvo', 'takedown'],
    // no two families a near-match: armour was the courier's cyan, and the
    // hospital, the destination and the depot were three more pinks beside
    // the rampage's
    ['#c86bff', 'S — Repintura', 'respray'], [HOSPITAL_HEX, 'H — Hospital', 'hospital'], ['#5aa0ff', 'P — Polícia', 'police'],
    ['#eef0ff', 'Arma', 'weapon'], ['#ff4d6a', 'Vida', 'health'], ['#4a6cff', 'Colete', 'armor'],
    ['#8de0ff', '✈ Aeroporto · Ⓗ Heliponto · ⚓ Barcos', 'airport'],
    // (the ice cream depot is a place of business like the rest: one family,
    // and one less row in the legend)
    ['#8de8b0', '$ Lojas e imóveis · ☀ Garagem', 'shops'], ['#5dff9e', '⌂ Seu esconderijo', 'home'],
    [DEST_HEX, 'Destino', 'dest'], ['#ffe14f', 'Objetivo', 'objective']
  ];
  // Tap-to-SOLO, like muting a mixing desk: tap a legend and everything ELSE
  // is struck — only that category (plus navigation) stays on the map. Tap it
  // again (or tap another) to release/switch. Your destination and the active
  // objective are never filtered: a route you just plotted must always show.
  var mapSolo = null;
  var NAV_ALWAYS = { dest: 1, objective: 1 };
  function catVis(k) { return !!NAV_ALWAYS[k] || !mapSolo || mapSolo === k; }
  // Which helipads are shown, and whether any are. BOTH surfaces call this —
  // the big map and the radar — rather than each repeating the rule, so they
  // cannot drift apart and a check standing on it cannot pass while either
  // one disagrees. A pad is treated exactly like the airport it shares a
  // legend row with: same family, same filter, same blip.
  // (refilled, not rebuilt: the radar asks twenty times a second, and every
  // caller reads the list straight away and keeps none of it; written by
  // index and cut to length, since emptying it would drop its storage)
  var padBuf = [];
  function shownHelipads() {
    var n = 0;
    if (catVis('airport')) {
      if (GAME.city.helipad) padBuf[n++] = GAME.city.helipad;
      if (GAME.city.roofHelipad) padBuf[n++] = GAME.city.roofHelipad;
    }
    padBuf.length = n;
    return padBuf;
  }
  function pickupCat(t) { return t === 'health' ? 'health' : t === 'armor' ? 'armor' : 'weapon'; }
  function toggleCat(k) {
    if (NAV_ALWAYS[k]) return;            // navigation rows are labels, not filters
    mapSolo = mapSolo === k ? null : k;
    GAME.prefs = GAME.prefs || {};
    GAME.prefs.mapSolo = mapSolo;
    GAME.save();
    refreshLegend();
    if (GAME.mapOpen) drawBigMap();
  }
  // The arrows (a pad's D-pad) step the solo through the families, then
  // back to all of them: the legend answered only a click or a tap.
  function stepSolo(dir) {
    var fams = LEGEND.filter(function (e) { return !NAV_ALWAYS[e[2]]; }).map(function (e) { return e[2]; });
    var i = (mapSolo ? fams.indexOf(mapSolo) : -1) + dir;
    if (i < -1) i = fams.length - 1;
    if (i >= fams.length) i = -1;
    mapSolo = i < 0 ? null : fams[i];
    GAME.prefs = GAME.prefs || {};
    GAME.prefs.mapSolo = mapSolo;
    GAME.save();
    refreshLegend();
    if (GAME.mapOpen) drawBigMap();
  }
  function refreshLegend() {
    var box = $('map-legend');
    box.innerHTML = LEGEND.map(function (e) {
      return '<span class="lgd' + (!catVis(e[2]) ? ' off' : '') + (mapSolo === e[2] ? ' sel' : '') + '" data-k="' + e[2] + '">' +
        '<i style="background:' + e[0] + '"></i>' + e[1] + '</span>';
    }).join('');
    for (var i = 0; i < box.children.length; i++) {
      // taps don't reliably become clicks in this app (same reason the pause
      // screen and fs button bind both); touchend's preventDefault also stops
      // the browser double-firing a synthetic click after it
      ['click', 'touchend'].forEach(function (ev) {
        box.children[i].addEventListener(ev, function (e) {
          e.preventDefault();
          e.stopPropagation();
          toggleCat(this.getAttribute('data-k'));
        });
      });
    }
  }

  // ---------- full-screen map ----------
  // It zooms now (wheel, pinch, the +/- buttons or keys) and pans by drag;
  // the pan is in canvas pixels at the current zoom, held inside the map.
  var mapScale = 1, mapZoom = 1, mapPanX = 0, mapPanY = 0, MAP_ZOOM_MAX = 5;
  var mapDragged = false, mapCentreOnYou = false;
  // A cursor for a pad, in world metres. The map was a mouse screen — click
  // to route, wheel to zoom — and a controller could open it and close it
  // and nothing in between. The left stick moves this; A routes to it.
  var mapCur = null;
  // where each district's name is written on the big map
  var DISTRICT_LABELS = [['OCEAN STRIP', 262, -230], ['CENTRO ALTO', -100, -150], ['PUERTO VIEJO', -330, 330],
    ['LAS COLINAS', 40, 330], ['LAS COLINAS', -340, -320]];
  // Isla Verde's districts, named on the map the way Costa Rosa's are. They
  // were only ever named on the HUD as you drove through; the map left the
  // island blank. Found once by sampling the island's land and labelling the
  // middle of each district's ground (the sample nearest its centre, so a
  // curved district is never named out at sea).
  var islaLabels = null;
  function islaDistrictLabels() {
    if (islaLabels) return islaLabels;
    var I = GAME.isla, B = GAME.city.isla && GAME.city.isla.bounds;
    if (!I || !I.districtName || !B) return [];
    islaLabels = [];
    var acc = {}, order = [];
    for (var x = B.cx - B.rx * 1.2; x <= B.cx + B.rx * 1.2; x += 12) {
      for (var z = B.cz - B.rz * 1.2; z <= B.cz + B.rz * 1.2; z += 12) {
        if (!I.contains(x, z) || GAME.city.isInWater(x, z)) continue;
        var n = I.districtName(x, z);
        if (!acc[n]) { acc[n] = { x: 0, z: 0, n: 0, pts: [] }; order.push(n); }
        acc[n].x += x; acc[n].z += z; acc[n].n++; acc[n].pts.push(x, z);
      }
    }
    order.forEach(function (n) {
      var a = acc[n], cx = a.x / a.n, cz = a.z / a.n, bx = cx, bz = cz, bd = 1e18;
      for (var i = 0; i < a.pts.length; i += 2) {
        var d = U.dist2(a.pts[i], a.pts[i + 1], cx, cz);
        if (d < bd) { bd = d; bx = a.pts[i]; bz = a.pts[i + 1]; }
      }
      islaLabels.push([n.toUpperCase(), bx, bz]);
    });
    return islaLabels;
  }
  function clampMapPan(cv) {
    mapPanX = U.clamp(mapPanX, 0, Math.max(0, MAP_W * mapScale - cv.width));
    mapPanY = U.clamp(mapPanY, 0, Math.max(0, MAP_H * mapScale - cv.height));
  }
  // zoom by `f` keeping the map point under canvas pixel (cx, cy) where it is
  function zoomMapAt(cx, cy, f) {
    var z1 = U.clamp(mapZoom * f, 1, MAP_ZOOM_MAX);
    if (z1 === mapZoom) return;
    var k = z1 / mapZoom;
    mapPanX = (cx + mapPanX) * k - cx;
    mapPanY = (cy + mapPanY) * k - cy;
    mapZoom = z1;
    drawBigMap();
  }
  function drawBigMap() {
    var cv = el.bigmap;
    // short screens hand more of their height to the legend and buttons —
    // a map you can see all of beats a bigger map with the CLOSE button
    // pushed off the bottom
    var hFactor = window.innerHeight < 460 ? 0.52 : 0.68;
    var size = Math.floor(Math.min(window.innerWidth * 0.92, window.innerHeight * hFactor * MAP_W / MAP_H, 900));
    cv.width = size; cv.height = Math.floor(size * MAP_H / MAP_W);
    var g = cv.getContext('2d');
    mapScale = size / MAP_W;   // the whole map across the canvas: zoom 1 (times mapZoom below)
    g.fillStyle = '#141020';
    g.fillRect(0, 0, cv.width, cv.height);
    mapScale = mapScale * mapZoom;
    if (mapCentreOnYou) {
      // opened zoomed in: start on wherever you are, not where you last looked
      mapCentreOnYou = false;
      var you = GAME.focus();
      mapPanX = (you.x + MAP_OX) * MAP_S * mapScale - cv.width / 2;
      mapPanY = (you.z + MAP_OY) * MAP_S * mapScale - cv.height / 2;
    }
    clampMapPan(cv);
    g.drawImage(mapBuffer, -mapPanX, -mapPanY, MAP_W * mapScale, MAP_H * mapScale);
    function w2mx(x) { return (x + MAP_OX) * MAP_S * mapScale - mapPanX; }
    function w2my(z) { return (z + MAP_OY) * MAP_S * mapScale - mapPanY; }
    // a name, outlined so it reads over streets and water alike
    function label(text, x, y, color, px, align) {
      g.font = '800 ' + px + 'px "Segoe UI", Arial, sans-serif';
      g.textAlign = align || 'left'; g.textBaseline = 'middle';
      g.lineWidth = 3; g.strokeStyle = 'rgba(8,4,18,.85)';
      g.strokeText(text, x, y);
      g.fillStyle = color;
      g.fillText(text, x, y);
    }
    // the districts, faint and large, under everything else
    var dpx = Math.round(U.clamp(11 * Math.sqrt(mapZoom) * cv.width / 900, 9, 22));
    var dls = DISTRICT_LABELS.concat(islaDistrictLabels());
    for (var dl = 0; dl < dls.length; dl++) {
      var D = dls[dl];
      label(D[0], w2mx(D[1]), w2my(D[2]), 'rgba(207,230,255,.42)', dpx, 'center');
    }
    // route + destination
    var P = GAME.player;
    var PF = GAME.focus();
    var px = PF.x;
    var pz = PF.z;
    if (GAME.nav.dest && catVis('dest')) {
      // an empty path is "no route" (a destination the streets can't reach,
      // e.g. the island while the bridges are closed) — stroking through it
      // drew one confident straight line across the water. Marker only.
      if (GAME.nav.path.length) {
        g.strokeStyle = 'rgba(141,255,216,.95)';
        g.lineWidth = ROUTE_W;
        g.beginPath();
        g.moveTo(w2mx(px), w2my(pz));
        GAME.nav.path.forEach(function (n) { g.lineTo(w2mx(n.x), w2my(n.z)); });
        g.lineTo(w2mx(GAME.nav.dest.x), w2my(GAME.nav.dest.z));
        g.stroke();
      }
      g.fillStyle = DEST_HEX;
      g.beginPath();
      g.arc(w2mx(GAME.nav.dest.x), w2my(GAME.nav.dest.z), 6, 0, Math.PI * 2);
      g.fill();
      g.strokeStyle = '#fff'; g.lineWidth = 1.5; g.stroke();
    }
    // active mission route
    var mroute = catVis('objective') ? GAME.missions.getRoutePoints() : null;
    if (mroute && mroute.length) {
      g.strokeStyle = 'rgba(255,138,61,.95)';
      g.lineWidth = ROUTE_W;
      g.beginPath();
      g.moveTo(w2mx(px), w2my(pz));
      for (var mr = 0; mr < mroute.length; mr++) g.lineTo(w2mx(mroute[mr][0]), w2my(mroute[mr][1]));
      g.stroke();
      var mobj2 = GAME.missions.getObjectivePoint();
      if (mobj2) {
        g.fillStyle = '#ffe14f';
        g.beginPath();
        g.arc(w2mx(mobj2[0]), w2my(mobj2[1]), 5, 0, Math.PI * 2);
        g.fill();
      }
    }
    // mission / respray blips: a mission you have beaten is a ring with a
    // tick in it, one still to do a solid dot; each named once there is room
    var mb = GAME.missions.getBlips();
    var named = mapZoom >= 1.5 || cv.width >= 700;
    for (var i = 0; i < mb.length; i++) {
      if (mb[i].kind && !catVis(mb[i].kind)) continue;
      var bx = w2mx(mb[i].x), by = w2my(mb[i].z);
      g.beginPath();
      g.arc(bx, by, 5, 0, Math.PI * 2);
      if (mb[i].done) {
        g.fillStyle = 'rgba(12,8,22,.9)'; g.fill();
        g.strokeStyle = mb[i].color; g.lineWidth = 2; g.stroke();
        g.beginPath(); g.moveTo(bx - 2.4, by + 0.2); g.lineTo(bx - 0.6, by + 2); g.lineTo(bx + 2.6, by - 2.2);
        g.lineWidth = 1.6; g.stroke();
      } else {
        g.fillStyle = mb[i].color; g.fill();
        if (mb[i].name) { g.strokeStyle = 'rgba(255,255,255,.85)'; g.lineWidth = 1.2; g.stroke(); }
      }
      if (named && mb[i].name) label(mb[i].name, bx + 8, by, mb[i].done ? 'rgba(207,230,255,.6)' : mb[i].color, 10);
    }
    // labelled POI badges
    function badge(x, z, color, letter) {
      g.fillStyle = color;
      g.beginPath();
      g.arc(w2mx(x), w2my(z), 8, 0, Math.PI * 2);
      g.fill();
      g.strokeStyle = 'rgba(255,255,255,.8)'; g.lineWidth = 1.2; g.stroke();
      g.fillStyle = '#0c0816';
      g.font = 'bold 11px Arial, sans-serif';
      g.textAlign = 'center'; g.textBaseline = 'middle';
      g.fillText(letter, w2mx(x), w2my(z) + 0.5);
    }
    // weapon / health / armor pickups
    GAME.world.pickups.forEach(function (pk) {
      if (pk.taken || !PICKUP_BLIP[pk.type]) return;
      if (!catVis(pickupCat(pk.type))) return;
      g.fillStyle = PICKUP_BLIP[pk.type];
      g.beginPath();
      g.arc(w2mx(pk.pos.x), w2my(pk.pos.z), 3.5, 0, Math.PI * 2);
      g.fill();
    });
    if (catVis('hospital')) GAME.city.pois.hospitals.forEach(function (hp) { badge(hp.x, hp.z, HOSPITAL_HEX, 'H'); });
    if (catVis('police')) GAME.city.pois.stations.forEach(function (st) { badge(st.x, st.z, '#5aa0ff', 'P'); });
    if (catVis('respray')) GAME.city.pois.resprays.forEach(function (r) { badge(r.door.x, r.door.z, '#c86bff', 'S'); });
    if (GAME.shops) GAME.shops.blips().forEach(function (s) {
      if (!catVis(s.home ? 'home' : 'shops')) return;
      if (!s.home) { badge(s.x, s.z, s.color, s.label); return; }
      // property you OWN is a landmark, not a shop dot: a ringed disc with a
      // drawn house (fonts can't be trusted with ⌂) — the legend does the
      // talking, the way a map should
      var hx = w2mx(s.x), hy = w2my(s.z);
      g.fillStyle = s.color;
      g.beginPath(); g.arc(hx, hy, 11, 0, Math.PI * 2); g.fill();
      g.strokeStyle = '#ffffff'; g.lineWidth = 2.2; g.stroke();
      g.fillStyle = '#0c2418';
      g.beginPath();                        // roof
      g.moveTo(hx - 6, hy - 0.5); g.lineTo(hx, hy - 6); g.lineTo(hx + 6, hy - 0.5);
      g.closePath(); g.fill();
      g.fillRect(hx - 4, hy - 0.5, 8, 5.5); // walls
      g.fillStyle = s.color;
      g.fillRect(hx - 1.2, hy + 1.4, 2.4, 3.6); // door
    });
    if (catVis('airport')) badge(GAME.city.airport.apron.x, GAME.city.airport.apron.z, '#8de0ff', '✈');
    // the security van on its rounds (streetlife.js), while it is about
    if (GAME.streetlife) GAME.streetlife.blips().forEach(function (b) { if (b.ring) badge(b.x, b.z, b.color, '$'); });
    if (catVis('shops') && GAME.city.islaPois) badge(GAME.city.islaPois.factory.x, GAME.city.islaPois.factory.z, DEPOT_HEX, '☀');
    // helipads: a ringed cyan disc with an H, one per pad. Both of them —
    // the Alta Verde summit across the channel, and the one on the downtown
    // tower here, which is where the mainland's only helicopter stands.
    shownHelipads().forEach(function (hpb) {
      var hxp = w2mx(hpb.x), hyp = w2my(hpb.z);
      g.fillStyle = '#8de0ff';
      g.beginPath(); g.arc(hxp, hyp, 8, 0, Math.PI * 2); g.fill();
      g.strokeStyle = '#ffffff'; g.lineWidth = 1.5; g.stroke();
      g.strokeStyle = '#0c0816'; g.lineWidth = 2;
      g.beginPath();
      g.moveTo(hxp - 3, hyp - 3.5); g.lineTo(hxp - 3, hyp + 3.5);
      g.moveTo(hxp + 3, hyp - 3.5); g.lineTo(hxp + 3, hyp + 3.5);
      g.moveTo(hxp - 3, hyp); g.lineTo(hxp + 3, hyp);
      g.stroke();
    });
    // boat moorings: the same disc with an anchor drawn on it (a font's ⚓
    // cannot be counted on in a canvas) — shown with the airfield and pads,
    // the other places to find something that is not a car
    if (catVis('airport')) (GAME.city.moorings || []).forEach(function (mo) {
      // (the island's are drawn while its bridges are shut too, dimmed: they
      // are there, just not yet to be had)
      var shut = mo.isla && GAME.isla && !GAME.isla.isOpen();
      g.globalAlpha = shut ? 0.4 : 1;
      var ax = w2mx(mo.x), ay = w2my(mo.z);
      g.fillStyle = '#8de0ff';
      g.beginPath(); g.arc(ax, ay, 8, 0, Math.PI * 2); g.fill();
      g.strokeStyle = '#ffffff'; g.lineWidth = 1.5; g.stroke();
      g.strokeStyle = '#0c0816'; g.lineWidth = 1.8;
      g.beginPath();
      g.moveTo(ax, ay - 4.5); g.lineTo(ax, ay + 4);
      g.moveTo(ax - 3, ay - 2); g.lineTo(ax + 3, ay - 2);
      g.moveTo(ax - 4, ay + 1); g.quadraticCurveTo(ax - 3.5, ay + 4.5, ax, ay + 4.5);
      g.quadraticCurveTo(ax + 3.5, ay + 4.5, ax + 4, ay + 1);
      g.stroke();
      g.globalAlpha = 1;
    });
    // player arrow
    var h = P.inCar && P.car ? P.car.heading : P.heading;
    g.save();
    g.translate(w2mx(px), w2my(pz));
    g.rotate(-h);
    g.fillStyle = '#ffffff'; g.strokeStyle = '#ff4fa3'; g.lineWidth = 1.5;
    g.beginPath();
    g.moveTo(0, 8); g.lineTo(6, -7); g.lineTo(0, -3); g.lineTo(-6, -7);
    g.closePath(); g.fill(); g.stroke();
    g.restore();
    // the pad's cursor: a ring and a cross, over everything but the rose
    if (mapCur) {
      var qx = w2mx(mapCur.x), qy = w2my(mapCur.z);
      g.strokeStyle = 'rgba(8,4,18,.9)'; g.lineWidth = 4;
      g.beginPath(); g.arc(qx, qy, 11, 0, Math.PI * 2); g.stroke();
      g.strokeStyle = '#8dffd8'; g.lineWidth = 2;
      g.beginPath(); g.arc(qx, qy, 11, 0, Math.PI * 2);
      g.moveTo(qx - 18, qy); g.lineTo(qx - 5, qy); g.moveTo(qx + 5, qy); g.lineTo(qx + 18, qy);
      g.moveTo(qx, qy - 18); g.lineTo(qx, qy - 5); g.moveTo(qx, qy + 5); g.lineTo(qx, qy + 18);
      g.stroke();
    }
    // compass rose — the big map is drawn north-up, and now it says so
    var rcx = cv.width - 42, rcy = 42, RR = 24;
    g.fillStyle = 'rgba(8,4,18,.78)';
    g.beginPath(); g.arc(rcx, rcy, RR + 8, 0, Math.PI * 2); g.fill();
    g.strokeStyle = 'rgba(255,105,180,.8)'; g.lineWidth = 1.5;
    g.beginPath(); g.arc(rcx, rcy, RR + 8, 0, Math.PI * 2); g.stroke();
    g.fillStyle = '#ff5f8f';                 // the needle's north half
    g.beginPath(); g.moveTo(rcx, rcy - RR + 10); g.lineTo(rcx - 4.5, rcy); g.lineTo(rcx + 4.5, rcy);
    g.closePath(); g.fill();
    g.fillStyle = 'rgba(230,240,255,.4)';    // and its tail
    g.beginPath(); g.moveTo(rcx, rcy + RR - 10); g.lineTo(rcx - 4.5, rcy); g.lineTo(rcx + 4.5, rcy);
    g.closePath(); g.fill();
    g.font = '800 11px "Segoe UI", Arial, sans-serif';
    g.textAlign = 'center'; g.textBaseline = 'middle';
    g.fillStyle = '#9df3ff';
    g.fillText('N', rcx, rcy - RR + 2);
    g.fillStyle = 'rgba(207,230,255,.75)';
    g.fillText('E', rcx + RR - 2, rcy);
    g.fillText('S', rcx, rcy + RR - 1);
    g.fillText('W', rcx - RR + 2, rcy);
  }

  function onMapClick(e) {
    if (mapDragged) { mapDragged = false; return; }   // that was a pan, not a pick
    var rect = el.bigmap.getBoundingClientRect();
    var cx = e.clientX - rect.left, cy = e.clientY - rect.top;
    pickMapAt((cx + mapPanX) / mapScale / MAP_S - MAP_OX, (cy + mapPanY) / mapScale / MAP_S - MAP_OY);
  }
  // the pad's stick on the open map: the cursor moves at a steady speed on
  // screen whatever the zoom, and pushes a zoomed map along at its edges
  function mapPad(dt, lx, ly) {
    if (!GAME.mapOpen || (!lx && !ly)) return;
    if (!mapCur) { var f = GAME.focus(); mapCur = { x: f.x, z: f.z }; }
    var cv = el.bigmap, step = 360 * dt / (mapScale * MAP_S);   // metres this frame at full tilt
    mapCur.x = U.clamp(mapCur.x + lx * step, -MAP_OX, MAP_W / MAP_S - MAP_OX);
    mapCur.z = U.clamp(mapCur.z + ly * step, -MAP_OY, MAP_H / MAP_S - MAP_OY);
    var cx = (mapCur.x + MAP_OX) * MAP_S * mapScale - mapPanX, cy = (mapCur.z + MAP_OY) * MAP_S * mapScale - mapPanY, M = 28;
    if (cx < M) mapPanX -= M - cx; else if (cx > cv.width - M) mapPanX += cx - (cv.width - M);
    if (cy < M) mapPanY -= M - cy; else if (cy > cv.height - M) mapPanY += cy - (cv.height - M);
    drawBigMap();
  }
  function mapPick() {
    if (!GAME.mapOpen || !mapCur) return false;
    pickMapAt(mapCur.x, mapCur.z);
    return true;
  }
  function mapHint() {
    var h = $('map-hint');
    if (!h) return;
    if (h.getAttribute('data-keys') === null) h.setAttribute('data-keys', h.innerHTML);
    h.innerHTML = GAME.controls && GAME.controls.usingPad()
      ? '<b>Analógico esq.</b> move o cursor &nbsp;·&nbsp; <b>A</b> define um destino ali &nbsp;·&nbsp; <b>X</b> limpa &nbsp;·&nbsp; <b>LB / RB</b> zoom &nbsp;·&nbsp; <b>D-pad ← →</b> mostra um tipo &nbsp;·&nbsp; <b>BACK</b> ou <b>B</b> fecha'
      : h.getAttribute('data-keys');
  }
  function pickMapAt(wx, wz) {
    wx = U.clamp(wx, -495, 1500);
    wz = U.clamp(wz, -540, 540);
    // no charting a course into open sea: a click on the water walks the pin
    // to the nearest road instead (a bridge deck is a fine destination as-is)
    if (GAME.city.isInWater(wx, wz)) {
      var rp = GAME.city.nearestRoadPoint(wx, wz);
      if (GAME.city.isInWater(rp.x, rp.z)) return;   // nothing honest to aim at
      wx = rp.x; wz = rp.z;
    }
    GAME.nav.setDest(wx, wz);
    drawBigMap();
  }

  // ---------- controls hint bar ----------
  var ctlMode = '';
  // the key help on the title and pause screens, in whatever the keys are
  // bound to now (controls.js)
  function K(code) { return GAME.controls ? GAME.controls.label(code) : code; }
  function onPad() { return !!(GAME.controls && GAME.controls.usingPad && GAME.controls.usingPad()); }
  function titleText() {
    el['press-enter'].textContent = GAME.isTouch ? 'TOQUE PARA COMEÇAR' : onPad() ? 'APERTE A' : 'APERTE ENTER';
  }
  // the same help for a controller, while one is what you are playing with
  var PAD_HELP = '<b>Analógico esq.</b> andar / dirigir &nbsp;·&nbsp; <b>Analógico dir.</b> câmera &nbsp;·&nbsp; <b>LT</b> mirar / fixar alvo &nbsp;·&nbsp; <b>RT</b> atirar ' +
    '(em um veículo, <b>RT / LT</b> são acelerar e frear)<br>' +
    '<b>LB / RB</b> trocar alvo · tiro de carro · giro do avião &nbsp;·&nbsp; <b>A</b> pular · escalar / freio de mão &nbsp;·&nbsp; <b>Y</b> entrar / sair do carro &nbsp;·&nbsp; <b>B</b> correr<br>' +
    '<b>D-pad ↓</b> armas &nbsp;·&nbsp; <b>D-pad ← / →</b> rádio &nbsp;·&nbsp; <b>R3</b> buzina / sirene &nbsp;·&nbsp; <b>X</b> bico &nbsp;·&nbsp; <b>D-pad ↑</b> tentar de novo &nbsp;·&nbsp; ' +
    '<b>L3</b> foto &nbsp;·&nbsp; <b>BACK</b> mapa &nbsp;·&nbsp; <b>START</b> pausa — Lola, abandonar, som, tela cheia, as trapaças e o resto estão lá';
  var PAD_BAR = {
    car: '<b>RT / LT</b> dirigir · <b>analógico</b> virar · <b>A</b> freio de mão · <b>LB / RB</b> tiro de carro · <b>Y</b> sair · <b>R3</b> buzina · <b>D-pad ← →</b> rádio · <b>BACK</b> mapa',
    foot: '<b>analógico</b> andar · <b>B</b> correr · <b>A</b> pular · <b>LT</b> mirar · <b>RT</b> atirar · <b>D-pad ↓</b> armas · <b>Y</b> entrar no carro · <b>BACK</b> mapa',
    heli: '<b>RT</b> subir · <b>LT</b> descer · <b>analógico</b> frente / guinada · <b>Y</b> sair / pular fora · <b>BACK</b> mapa',
    plane: '<b>RT / LT</b> acelerador · <b>analógico</b> inclinar / virar · <b>A</b> subir · <b>B</b> mergulhar · <b>LB / RB</b> giro em parafuso · <b>Y</b> pular fora',
    chute: '<b>analógico</b> controle a descida · plane até pousar',
    swim: '<b>analógico</b> nadar · <b>B</b> braçada rápida · saia da água em uma praia, píer ou borda baixa · <b>Y</b> subir em um barco · <b>BACK</b> mapa',
    boat: '<b>RT / LT</b> acelerador · <b>analógico</b> virar · <b>A</b> derrapar · <b>Y</b> descer · <b>R3</b> buzina · <b>D-pad ← →</b> rádio · <b>BACK</b> mapa'
  };
  // ...and for thumbs: a phone's title screen used to list WASD and the mouse
  var TOUCH_HELP = '<b>Polegar esquerdo</b> andar / virar &nbsp;·&nbsp; <b>Arraste o lado direito</b> para olhar ao redor<br>' +
    '<b>CORRER · PULAR · MIRAR · ATIRAR</b> a pé &nbsp;·&nbsp; <b>ENTRAR</b> pegar o carro &nbsp;·&nbsp; <b>ACELERAR / FREAR</b> dirigir<br>' +
    '<b>Toque no radar</b> mapa &nbsp;·&nbsp; <b>❚❚</b> pausa — Lola, as trapaças, ajustes e o resto';
  function paintKeyHelp() {
    if (GAME.isTouch) {
      var tc = document.getElementById('controls-card');
      if (tc) tc.innerHTML = TOUCH_HELP;
      if (el['pause-controls']) el['pause-controls'].innerHTML = TOUCH_HELP;
      return;
    }
    if (onPad()) {
      var pc = document.getElementById('controls-card');
      if (pc) pc.innerHTML = PAD_HELP;
      if (el['pause-controls']) el['pause-controls'].innerHTML = PAD_HELP;
      return;
    }
    var h = '<b>' + K('KeyW') + K('KeyA') + K('KeyS') + K('KeyD') + '</b> andar / dirigir &nbsp;·&nbsp; <b>Mouse</b> câmera &nbsp;·&nbsp; <b>Botão dir. / ' + K('Tab') + '</b> mirar / fixar alvo &nbsp;·&nbsp; <b>Botão esq.</b> atirar<br>' +
      '<b>' + K('KeyQ') + ' / ' + K('KeyE') + '</b> trocar alvo · tiro de carro · giro do avião &nbsp;·&nbsp; <b>' + K('Space') + '</b> pular · escalar / freio de mão &nbsp;·&nbsp; <b>' + K('KeyF') + '</b> entrar / sair do carro &nbsp;·&nbsp; <b>' + K('ShiftLeft') + '</b> correr<br>' +
      '<b>1–9</b> armas &nbsp;·&nbsp; <b>' + K('Comma') + ' / ' + K('Period') + '</b> rádio &nbsp;·&nbsp; <b>' + K('KeyG') + '</b> buzina / sirene &nbsp;·&nbsp; <b>' + K('KeyJ') + '</b> bico &nbsp;·&nbsp; <b>' + K('KeyX') + '</b> abandonar missão &nbsp;·&nbsp; <b>' + K('KeyC') + '</b> foto · <b>' + K('KeyV') + '</b> ver &nbsp;·&nbsp; <b>' + K('KeyL') + '</b> Lola &nbsp;·&nbsp; <b>' + K('KeyP') + '</b> mapa &nbsp;·&nbsp; <b>' + K('Backquote') + '</b> trapaças &nbsp;·&nbsp; <b>' + K('KeyM') + '</b> mudo &nbsp;·&nbsp; <b>' + K('KeyH') + '</b> ocultar ajuda &nbsp;·&nbsp; <b>Esc</b> pausar';
    var card = document.getElementById('controls-card');
    if (card) card.innerHTML = h;
    if (el['pause-controls']) el['pause-controls'].innerHTML = h;
  }
  function refreshControlsBar() {
    if (GAME.isTouch) { el['controls-bar'].style.display = 'none'; return; }
    var hidden = GAME.prefs && GAME.prefs.hideCtl;
    if (!GAME.started || hidden) { el['controls-bar'].style.display = 'none'; ctlMode = ''; return; }
    var mode = GAME.player.parachuting ? 'chute'
      : (GAME.player.inCar && GAME.player.car && GAME.player.car.spec.plane) ? 'plane'
        : (GAME.player.inCar && GAME.player.car && GAME.player.car.spec.heli) ? 'heli'
          : (GAME.player.inCar && GAME.player.car && GAME.player.car.spec.boat) ? 'boat'
            : GAME.player.inCar ? 'car' : GAME.player.swimming ? 'swim' : 'foot';
    if (mode === ctlMode && el['controls-bar'].style.display === 'block') return;
    ctlMode = mode;
    var wasd = K('KeyW') + K('KeyA') + K('KeyS') + K('KeyD');
    var txt = {
      car: '<b>' + wasd + '</b> dirigir · <b>' + K('Space') + '</b> freio de mão · <b>' + K('KeyQ') + '/' + K('KeyE') + '</b> tiro de carro · <b>' + K('KeyF') + '</b> sair · <b>' + K('KeyG') + '</b> buzina · <b>' + K('Comma') + '/' + K('Period') + '</b> rádio · <b>' + K('KeyP') + '</b> mapa · <b>' + K('Backquote') + '</b> trapaças · <b>' + K('KeyH') + '</b> ocultar',
      foot: '<b>' + wasd + '</b> andar · <b>' + K('ShiftLeft') + '</b> correr · <b>' + K('Space') + '</b> pular · <b>Botão dir.</b> mirar · <b>Botão esq.</b> atirar · <b>1-9</b> · <b>' + K('KeyZ') + '</b> (segure) armas · <b>' + K('KeyF') + '</b> entrar no carro · <b>' + K('KeyP') + '</b> mapa · <b>' + K('Backquote') + '</b> trapaças · <b>' + K('KeyH') + '</b> ocultar',
      heli: '<b>' + K('Space') + '</b> up · <b>' + K('ShiftLeft') + '</b> descer · <b>' + K('KeyW') + '/' + K('KeyS') + '</b> frente · <b>' + K('KeyA') + '/' + K('KeyD') + '</b> guinada · <b>' + K('KeyF') + '</b> sair / pular fora · <b>' + K('KeyP') + '</b> mapa',
      plane: '<b>' + K('KeyW') + '/' + K('KeyS') + '</b> acelerador · <b>' + K('Space') + '</b> subir · <b>' + K('ShiftLeft') + '</b> mergulhar · <b>' + K('KeyA') + '/' + K('KeyD') + '</b> virar · <b>' + K('KeyQ') + '/' + K('KeyE') + '</b> giro em parafuso · <b>' + K('KeyF') + '</b> pular fora',
      chute: '<b>' + wasd + '</b> controle a descida · plane até pousar',
      swim: '<b>' + wasd + '</b> nadar · <b>' + K('ShiftLeft') + '</b> braçada rápida · saia da água em uma praia, píer ou borda baixa · <b>' + K('KeyF') + '</b> subir em um barco · <b>' + K('KeyP') + '</b> mapa',
      boat: '<b>' + K('KeyW') + '/' + K('KeyS') + '</b> acelerador · <b>' + K('KeyA') + '/' + K('KeyD') + '</b> virar · <b>' + K('Space') + '</b> derrapar · <b>' + K('KeyF') + '</b> descer · <b>' + K('KeyG') + '</b> buzina · <b>' + K('Comma') + '/' + K('Period') + '</b> rádio · <b>' + K('KeyP') + '</b> mapa'
    };
    el['controls-bar'].innerHTML = onPad() ? PAD_BAR[mode] : txt[mode];
    el['controls-bar'].style.display = 'block';
  }

  function buildMapBuffer() {
    mapBuffer = document.createElement('canvas');
    mapBuffer.width = MAP_W; mapBuffer.height = MAP_H;
    var g = mapBuffer.getContext('2d');
    function mx(x) { return (x + MAP_OX) * MAP_S; }
    function my(z) { return (z + MAP_OY) * MAP_S; }
    // island: water everywhere, then scan-fill the landmass with a sand rim
    var c = GAME.city;
    g.fillStyle = '#16305a';
    g.fillRect(0, 0, MAP_W, MAP_H);
    // every landmass draws the same way, so a second island needs no second
    // branch here — it is land if some island contains it
    function isLand(x, z) { return !!c.islandAt(x, z); }
    var CELL = 8;
    for (var wx = -520; wx < 1520; wx += CELL) {
      for (var wz = -560; wz < 560; wz += CELL) {
        var cxm = wx + CELL / 2, czm = wz + CELL / 2;
        if (!isLand(cxm, czm)) continue;
        var rim = !isLand(cxm + CELL, czm) || !isLand(cxm - CELL, czm) || !isLand(cxm, czm + CELL) || !isLand(cxm, czm - CELL);
        // relief shading, so the hills read on the map as well as underfoot
        var gy = rim ? 0 : c.groundY(cxm, czm);
        g.fillStyle = rim ? '#8a7a58' : gy > 2
          ? 'rgb(' + Math.round(20 + gy * 1.5) + ',' + Math.round(16 + gy * 2.2) + ',' + Math.round(32 + gy * 0.8) + ')'
          : '#141020';
        g.fillRect(mx(wx), my(wz), CELL * MAP_S + 0.5, CELL * MAP_S + 0.5);
      }
    }
    // east beach band
    g.fillStyle = '#3a3350';
    g.beginPath();
    g.moveTo(mx(368), my(-500));
    for (var z = -500; z <= 500; z += 25) g.lineTo(mx(GAME.city.shoreline(z) - 4), my(z));
    g.lineTo(mx(368), my(500));
    g.closePath();
    g.fill();
    // roads
    g.strokeStyle = '#4a4462';
    g.lineWidth = 5 * MAP_S * 2.4;
    var R = GAME.city.R;
    for (var i = 0; i < R.length; i++) {
      g.beginPath(); g.moveTo(mx(R[i]), my(-480)); g.lineTo(mx(R[i]), my(480)); g.stroke();
      g.beginPath(); g.moveTo(mx(-480), my(R[i])); g.lineTo(mx(350), my(R[i])); g.stroke();
    }
    g.strokeStyle = '#5a5478';
    g.beginPath(); g.moveTo(mx(350), my(-480)); g.lineTo(mx(350), my(480)); g.stroke();
    // Isla Verde: its roads are polylines, so they draw as polylines
    if (GAME.city.isla) {
      var IS = GAME.city.isla;
      g.lineCap = 'round'; g.lineJoin = 'round';
      g.strokeStyle = '#4a4462';
      IS.net.forEach(function (seg) {
        g.lineWidth = Math.max(2, seg.w * MAP_S * 2.0);
        g.beginPath();
        for (var k = 0; k < seg.pts.length; k++) {
          var pt = seg.pts[k];
          if (k) g.lineTo(mx(pt[0]), my(pt[1])); else g.moveTo(mx(pt[0]), my(pt[1]));
        }
        g.stroke();
      });
      // the bridges, in the same pink they are lit in
      g.strokeStyle = '#b8548a'; g.lineWidth = 5;
      IS.spans.forEach(function (sp) {
        g.beginPath();
        for (var k2 = 0; k2 < sp.pts.length; k2++) {
          var q = sp.pts[k2];
          if (k2) g.lineTo(mx(q[0]), my(q[1])); else g.moveTo(mx(q[0]), my(q[1]));
        }
        g.stroke();
      });
      g.lineCap = 'butt'; g.lineJoin = 'miter';
    }
    // piers
    g.strokeStyle = '#6a5a48'; g.lineWidth = 4;
    g.beginPath(); g.moveTo(mx(360), my(250)); g.lineTo(mx(505), my(250)); g.stroke();
    g.beginPath(); g.moveTo(mx(360), my(-180)); g.lineTo(mx(470), my(-180)); g.stroke();
    // airport: fenced apron, a runway strip with a dashed centreline
    var A = GAME.city.airport;
    g.fillStyle = 'rgba(60,66,84,0.55)';
    g.fillRect(mx(A.fx0), my(A.fz0), (A.fx1 - A.fx0) * MAP_S, (A.fz1 - A.fz0) * MAP_S);
    g.strokeStyle = '#7a808e'; g.lineWidth = 1;
    g.strokeRect(mx(A.fx0), my(A.fz0), (A.fx1 - A.fx0) * MAP_S, (A.fz1 - A.fz0) * MAP_S);
    g.fillStyle = '#2a2c34';
    g.fillRect(mx(A.minX), my(A.cz - 13), (A.maxX - A.minX) * MAP_S, 26 * MAP_S);
    g.strokeStyle = '#d8c46a'; g.lineWidth = 1; g.setLineDash([4, 4]);
    g.beginPath(); g.moveTo(mx(A.minX + 8), my(A.cz)); g.lineTo(mx(A.maxX - 8), my(A.cz)); g.stroke();
    g.setLineDash([]);
    // No marker is baked in here — not a POI square, and not the helipad ring
    // that used to be. The big map draws them live as legend-filterable
    // badges; anything burned into this image sits underneath that pass,
    // where the legend's solo/strike can never reach it. The pad ring was the
    // last one left, and it showed: solo any other family and every badge on
    // the map went out except that one, which sat there through all of it.
    // the landmasses name themselves, written on the sea below each one
    g.font = 'italic 700 17px "Segoe UI", Arial, sans-serif';
    g.textAlign = 'center'; g.textBaseline = 'middle';
    g.fillStyle = 'rgba(150,200,240,0.85)';
    g.fillText('ISLA ROSA', mx(-70), my(542));
    if (GAME.city.isla) {
      // just under the island's own southernmost point, wherever that is
      var southZ = -1e9, cxIsla = 0, n = 0;
      for (var la = 0; la < Math.PI * 2; la += 0.05) {
        var q = GAME.city.isla.ringPt(la, 1);
        southZ = Math.max(southZ, q[1]); cxIsla += q[0]; n++;
      }
      g.fillText('ISLA VERDE', mx(cxIsla / n), my(Math.min(southZ + 26, 545)));
    }
  }

  // Where a home you own goes on the radar: a ringed dot on its real
  // position while it is on the radar, and nothing once it is not. It used
  // to become an arrow pinned to the rim pointing home from anywhere on the
  // map — a yellow triangle that never left the radar, however far out you
  // were. The big map still shows every home. Kept out of the drawing code
  // so the decision can be tested without a canvas.
  //
  // The rim is 90 — the canvas is 180 square, drawn from its centre — and the
  // ring needs room, so a home counts as on the radar inside 80.
  var RADAR_RIM = 80;
  function homeMarker(dx, dz, zoom) {
    var rx = dx * MAP_S, rz = dz * MAP_S;
    var rr = Math.sqrt(rx * rx + rz * rz);
    if (rr <= RADAR_RIM / zoom) return { mode: 'dot', x: rx, z: rz, dist: rr };
    return { mode: 'off', dist: rr };
  }

  // The radar's two stamps. They were closures made afresh inside every draw,
  // twenty draws a second; they read the draw's context, centre and zoom from
  // here instead, set at the top of drawMinimap.
  var mmG = null, mmPx = 0, mmPz = 0, mmZoom = 1;
  function blip(x, z, color, size) {
    var g = mmG;
    g.fillStyle = color;
    g.beginPath();
    g.arc((x - mmPx) * MAP_S, (z - mmPz) * MAP_S, size, 0, Math.PI * 2);
    g.fill();
  }
  // Something worth going after (the security van: streetlife.js): a dot in
  // a red ring, pulsing, and held to the rim while it is further off than
  // the radar reaches, so it says which way to go.
  function ringBlip(x, z, color) {
    var g = mmG, lx = (x - mmPx) * MAP_S, lz = (z - mmPz) * MAP_S;
    var rim = 80 / mmZoom, l = Math.sqrt(lx * lx + lz * lz);
    if (l > rim) { lx *= rim / l; lz *= rim / l; }
    g.fillStyle = color;
    g.beginPath(); g.arc(lx, lz, 4.2 / mmZoom, 0, Math.PI * 2); g.fill();
    g.strokeStyle = '#ff3b3b'; g.lineWidth = 1.8 / mmZoom;
    g.beginPath(); g.arc(lx, lz, (6.4 + 1.2 * Math.sin(GAME.time * 5)) / mmZoom, 0, Math.PI * 2); g.stroke();
  }
  // airport + helipad landmarks: a ringed cyan blip so they stand out on the radar
  function landmark(x, z) {
    var g = mmG, lx = (x - mmPx) * MAP_S, lz = (z - mmPz) * MAP_S;
    g.fillStyle = '#8de0ff';
    g.beginPath(); g.arc(lx, lz, 3.4 / mmZoom, 0, Math.PI * 2); g.fill();
    g.strokeStyle = '#ffffff'; g.lineWidth = 1.2 / mmZoom;
    g.beginPath(); g.arc(lx, lz, 5.6 / mmZoom, 0, Math.PI * 2); g.stroke();
  }
  function drawMinimap() {
    var cv = el.minimap, g = cv.getContext('2d');
    var P = GAME.player;
    // (GAME.focus: the car when driving — and the front door from a room)
    var F = GAME.focus();
    var px = F.x;
    var pz = F.z;
    var h = P.inCar && P.car ? P.car.heading : P.heading;
    g.clearRect(0, 0, 180, 180);
    var zoom = P.inCar ? 0.62 : 0.85;
    mmG = g; mmPx = px; mmPz = pz; mmZoom = zoom;
    g.save();
    g.translate(90, 90);
    // heading-up radar: rotate so the player's forward direction points up
    g.rotate(h - Math.PI);
    g.scale(zoom, zoom);
    g.drawImage(mapBuffer, -(px + MAP_OX) * MAP_S, -(pz + MAP_OY) * MAP_S);
    // blips (drawn in the rotated frame so they track the map)
    // a lost tape close by glints on the radar (only then: tapes.js)
    if (GAME.tapes) {
      var tn = GAME.tapes.nearby(px, pz);
      for (var tg = 0; tg < tn.length; tg++) blip(tn[tg].x, tn[tg].z, '#ffd0ea', 2.2 / zoom);
    }
    // weapon / health / armor pickups near the player
    var pk = GAME.world.pickups;
    for (var pu = 0; pu < pk.length; pu++) {
      var pp = pk[pu];
      if (pp.taken || !PICKUP_BLIP[pp.type]) continue;
      if (!catVis(pickupCat(pp.type))) continue;
      if (U.dist2(pp.pos.x, pp.pos.z, px, pz) > 150 * 150) continue;
      blip(pp.pos.x, pp.pos.z, PICKUP_BLIP[pp.type], 2.6 / zoom);
    }
    // nearby shops and property, so the doormats are findable from the radar.
    // Homes you own wear a white ring, shown whenever they are on the radar.
    if (GAME.shops) {
      var sb = GAME.shops.blips();
      for (var sbi = 0; sbi < sb.length; sbi++) {
        var sbp = sb[sbi];
        if (!catVis(sbp.home ? 'home' : 'shops')) continue;
        if (!sbp.home && U.dist2(sbp.x, sbp.z, px, pz) > 170 * 170) continue;
        if (sbp.home) {
          var hm = homeMarker(sbp.x - px, sbp.z - pz, zoom);
          if (hm.mode === 'dot') {
            g.fillStyle = sbp.color;
            g.beginPath(); g.arc(hm.x, hm.z, 4.4 / zoom, 0, Math.PI * 2); g.fill();
            g.strokeStyle = '#ffffff'; g.lineWidth = 1.6 / zoom; g.stroke();
          }
        } else {
          blip(sbp.x, sbp.z, sbp.color, 3.2 / zoom);
        }
      }
    }
    // active mission route (race checkpoints / current delivery stop)
    var mroute = catVis('objective') ? GAME.missions.getRoutePoints() : null;
    if (mroute && mroute.length) {
      g.strokeStyle = 'rgba(255,138,61,.95)';
      g.lineWidth = RADAR_ROUTE_W / zoom;
      g.beginPath();
      g.moveTo(0, 0);
      for (var mr = 0; mr < mroute.length; mr++) g.lineTo((mroute[mr][0] - px) * MAP_S, (mroute[mr][1] - pz) * MAP_S);
      g.stroke();
      var mobj = GAME.missions.getObjectivePoint();
      if (mobj) blip(mobj[0], mobj[1], '#ffe14f', 4.5 / zoom);
    }
    // nav route — same rule as the big map: an empty path strokes nothing,
    // the destination blip alone tells the story
    if (GAME.nav.dest && catVis('dest')) {
      if (GAME.nav.path.length) {
        g.strokeStyle = 'rgba(141,255,216,.95)';
        g.lineWidth = RADAR_ROUTE_W / zoom;
        g.beginPath();
        g.moveTo(0, 0);
        var path = GAME.nav.path;
        for (var np = 0; np < path.length; np++) g.lineTo((path[np].x - px) * MAP_S, (path[np].z - pz) * MAP_S);
        g.lineTo((GAME.nav.dest.x - px) * MAP_S, (GAME.nav.dest.z - pz) * MAP_S);
        g.stroke();
      }
      blip(GAME.nav.dest.x, GAME.nav.dest.z, DEST_HEX, 4.5 / zoom);
    }
    var mb = GAME.missions.getBlips();
    for (var i = 0; i < mb.length; i++) {
      if (mb[i].kind && !catVis(mb[i].kind)) continue;
      blip(mb[i].x, mb[i].z, mb[i].color, mb[i].size);
    }
    // whatever is going on in the street near you (streetlife.js)
    var sb = GAME.streetlife ? GAME.streetlife.blips() : [];
    for (var si = 0; si < sb.length; si++) {
      if (sb[si].ring) ringBlip(sb[si].x, sb[si].z, sb[si].color);
      else blip(sb[si].x, sb[si].z, sb[si].color, sb[si].size);
    }
    // and the strangers with a favour to ask (strangers.js)
    var kb = GAME.strangers ? GAME.strangers.blips() : [];
    for (var ki = 0; ki < kb.length; ki++) blip(kb[ki].x, kb[ki].z, kb[ki].color, kb[ki].size);
    // and the export crane on the harbour (export.js)
    var xb = GAME.exporter && GAME.exporter.blip();
    if (xb) blip(xb.x, xb.z, xb.color, 3.4 / zoom);
    // and both sides' people on the corners near you (gangs.js)
    var gb = GAME.gangs ? GAME.gangs.blips() : [];
    for (var gi = 0; gi < gb.length; gi++) blip(gb[gi].x, gb[gi].z, gb[gi].color, gb[gi].size / zoom);
    // and where Lola's big score goes next (heist.js)
    var hb = GAME.heist ? GAME.heist.blips() : [];
    for (var hi = 0; hi < hb.length; hi++) blip(hb[hi].x, hb[hi].z, hb[hi].color, hb[hi].size);
    // POI dots, live and legend-aware (they used to be baked into the base
    // image, where the legend couldn't touch them)
    var pois = GAME.city.pois, pi;
    if (catVis('hospital')) for (pi = 0; pi < pois.hospitals.length; pi++) blip(pois.hospitals[pi].x, pois.hospitals[pi].z, HOSPITAL_HEX, 3);
    if (catVis('police')) for (pi = 0; pi < pois.stations.length; pi++) blip(pois.stations[pi].x, pois.stations[pi].z, '#5aa0ff', 3);
    if (catVis('respray')) for (pi = 0; pi < pois.resprays.length; pi++) blip(pois.resprays[pi].door.x, pois.resprays[pi].door.z, '#c86bff', 3);
    if (catVis('airport')) landmark(GAME.city.airport.apron.x, GAME.city.airport.apron.z);
    var pads = shownHelipads();
    for (pi = 0; pi < pads.length; pi++) landmark(pads[pi].x, pads[pi].z);
    if (catVis('shops') && GAME.city.islaPois) landmark(GAME.city.islaPois.factory.x, GAME.city.islaPois.factory.z);
    var cars = GAME.world.cars;
    for (var c = 0; c < cars.length; c++) {
      var pc = cars[c];
      // only actively-pursuing cruisers show as blips (not idle/parked ones)
      if (pc.isPolice && !pc.dead && pc.ai && (pc.ai.mode === 'chase' || pc.ai.mode === 'roadblock')) blip(pc.pos.x, pc.pos.z, '#5aa0ff', 3);
      // the car a job has sent after you (missions.js: Rico's men)
      else if (pc.heavy && !pc.dead) blip(pc.pos.x, pc.pos.z, '#ff3b3b', 3);
    }
    var peds = GAME.world.peds;
    for (var pd = 0; pd < peds.length; pd++) {
      if (peds[pd].isCop && !peds[pd].dead) blip(peds[pd].pos.x, peds[pd].pos.z, '#5aa0ff', 2);
      else if (peds[pd].missionFoe && !peds[pd].dead) blip(peds[pd].pos.x, peds[pd].pos.z, '#ff3b3b', 2);
    }
    g.restore();
    // player arrow: fixed, always pointing up (the radar rotates beneath it)
    g.save();
    g.translate(90, 90);
    g.fillStyle = '#ffffff';
    g.strokeStyle = '#ff4fa3';
    g.lineWidth = 1.5;
    g.beginPath();
    g.moveTo(0, -8); g.lineTo(6, 6); g.lineTo(0, 2); g.lineTo(-6, 6);
    g.closePath(); g.fill(); g.stroke();
    g.restore();
    // the radar is heading-up, so north moves — ride an N badge around the
    // rim so there is always a sense of direction at a glance
    var nx2 = 90 - 74 * Math.sin(h), ny2 = 90 + 74 * Math.cos(h);
    g.fillStyle = 'rgba(8,4,18,.85)';
    g.beginPath(); g.arc(nx2, ny2, 8, 0, Math.PI * 2); g.fill();
    g.strokeStyle = 'rgba(255,105,180,.8)'; g.lineWidth = 1.2;
    g.beginPath(); g.arc(nx2, ny2, 8, 0, Math.PI * 2); g.stroke();
    g.fillStyle = '#ffd9f2';
    g.font = '800 10px "Segoe UI", Arial, sans-serif';
    g.textAlign = 'center'; g.textBaseline = 'middle';
    g.fillText('N', nx2, ny2 + 0.5);
  }

  function updateCashText() {
    el.cash.textContent = '$' + Math.floor(shownCash);
  }

  function update(dt) {
    if (!mapBuffer) return;
    stepPager(dt);
    GAME.nav.update(dt);
    if (GAME.frame % 3 === 0) drawMinimap();
    if (GAME.frame % 10 === 0) { refreshControlsBar(); api.refreshFsBtn(); }
    // cash tick-up
    if (shownCash !== targetCash) {
      var diff = targetCash - shownCash;
      var step = Math.max(1, Math.abs(diff) * dt * 4);
      shownCash += Math.sign(diff) * Math.min(Math.abs(diff), step);
      if (Math.abs(targetCash - shownCash) < 1) shownCash = targetCash;
      else if (GAME.frame % 4 === 0) GAME.audio.cashTick();
      updateCashText();
    }
    var P = GAME.player;
    // The town clock: dayPhase 0 is midnight, 0.5 is noon, 24 hours around
    // the wheel — pinned day or night freezes it with the sun. The 150 s day
    // makes a raw minute hand a blur (9.6 game-minutes a second), so it
    // reads in ten-minute steps, ticking about once a real second.
    var cm = Math.floor(GAME.dayPhase * 144) * 10 % 1440;
    if (cm !== lastClock) {
      lastClock = cm;
      el.clock.textContent = (cm < 600 ? '0' : '') + Math.floor(cm / 60) + ':' + (cm % 60 === 0 ? '00' : cm % 60);
    }
    var hw = U.clamp(P.health, 0, 100), aw = U.clamp(P.armor, 0, 100);
    if (hw !== lastHealthW) { lastHealthW = hw; el['health-fill'].style.width = hw + '%'; }
    if (aw !== lastArmorW) { lastArmorW = aw; el['armor-fill'].style.width = aw + '%'; }
    // aircraft wear their condition on the HUD: their damage is otherwise
    // invisible until the explosion, and "wasted out of nowhere" was just a
    // dying airframe nobody could see
    if (vehicleLine === undefined) vehicleLine = document.getElementById('vehicle-line');
    var vl = vehicleLine;
    if (vl) {
      var av = P.inCar && P.car && (P.car.spec.heli || P.car.spec.plane) ? P.car : null;
      var apct = -1, acol = '';
      if (av) {
        var af = U.clamp(av.hp / av.spec.hp, 0, 1);
        apct = Math.round(af * 100);
        acol = af > 0.6 ? '#8dffd8' : af > 0.3 ? '#ffd24a' : '#ff5d7a';
      }
      if (apct !== lastAirPct || acol !== lastAirCol) {
        lastAirPct = apct; lastAirCol = acol;
        if (av) {
          vl.textContent = 'ESTRUTURA ' + apct + '%';
          vl.style.color = acol;
          vl.style.display = 'block';
        } else vl.style.display = 'none';
      }
    }
    stepMessages(dt);
    stepLockHint();
    if (hitT > 0) { hitT -= dt; if (hitT <= 0) $('hit-dir').style.opacity = 0; }
    var P0 = GAME.player, low = P0.state === 'alive' && P0.health > 0 && P0.health < LOW_HEALTH;
    if (low !== lowShown) { lowShown = low; lowT = 0; $('low-health').style.display = low ? 'block' : 'none'; }
    if (low) {
      // ten seconds of pulse, then it fades; a fresh hit lights it again
      if (P0.health < lowHp) lowT = 0;
      lowT += dt;
      var spent = lowT > LOW_PULSE;
      if (spent !== lowSpent) { lowSpent = spent; $('low-health').classList.toggle('spent', spent); }
    } else if (lowSpent) { lowSpent = false; $('low-health').classList.remove('spent'); }
    lowHp = P0.health;
    stepTips(dt);
    if (countT > 0) { countT -= dt; if (countT <= 0) el['count-big'].style.opacity = 0; }
    if (radioT > 0) { radioT -= dt; if (radioT <= 0) el['radio-popup'].style.opacity = 0; }
    zoneT -= dt;
    if (zoneT <= 0) {
      zoneT = 2;
      var zf = GAME.focus();
      var zn = GAME.city.districtName(zf.x, zf.z);
      if (zn !== lastZone) {
        lastZone = zn;
        el['zone-popup'].textContent = zn;
        placeZone();
        el['zone-popup'].style.opacity = 1;
        setTimeout(function () { el['zone-popup'].style.opacity = 0; }, 2600);
      }
    }
  }

  // The district name shares the top centre with a running mission's title
  // and objective, and was drawn straight over them: it goes underneath while
  // one is up (and moves when one starts or ends under it).
  function placeZone() {
    var mh = el['mission-hud'];
    el['zone-popup'].style.top = mh.style.display === 'block' ? (mh.offsetTop + mh.offsetHeight + 6) + 'px' : '';
  }

  // ---------- the pause screen: a menu down the left, a card beside it ----------
  // The menu's entries either do something (RESUME, MAP, LOLA, PHOTOS) or
  // open a section in the card (STATS, SETTINGS, GAME). On the keys, up and
  // down walk the menu, right (or Enter) goes into an open card, and left
  // comes back out; in the card the arrows walk its buttons. Esc resumes.
  var pauseSel = 0, pauseZone = 'tabs', pausePanel = 'pp-stats';
  function visible(list) {
    var out = [];
    for (var i = 0; i < list.length; i++) if (list[i].offsetParent !== null) out.push(list[i]);
    return out;
  }
  function pauseButtons() {
    return visible(pauseZone === 'tabs' ? el['pause-screen'].querySelectorAll('.ptab')
      : $(pausePanel).querySelectorAll('.mbtn'));
  }
  function showPausePanel(id) {
    pausePanel = id;
    var ps = el['pause-screen'].querySelectorAll('.ppanel');
    for (var i = 0; i < ps.length; i++) ps[i].classList.toggle('on', ps[i].id === id);
    var ts = el['pause-screen'].querySelectorAll('.ptab');
    for (var j = 0; j < ts.length; j++) ts[j].classList.toggle('open', ts[j].getAttribute('data-panel') === id);
  }
  function paintPauseSel() {
    var all = el['pause-screen'].querySelectorAll('.mbtn');
    for (var k = 0; k < all.length; k++) all[k].classList.remove('kfocus');
    var bs = pauseButtons();
    if (!bs.length) return;
    pauseSel = (pauseSel % bs.length + bs.length) % bs.length;
    bs[pauseSel].classList.add('kfocus');
    if (pauseZone === 'panel' && bs[pauseSel].scrollIntoView) bs[pauseSel].scrollIntoView({ block: 'nearest' });
  }
  function pauseRowStep(bs, cur, dir) {
    var r0 = bs[cur].getBoundingClientRect(), cx = r0.left + r0.width / 2, cy = r0.top + r0.height / 2;
    var best = cur, bd = 1e9;
    for (var i = 0; i < bs.length; i++) {
      var r = bs[i].getBoundingClientRect(), y = r.top + r.height / 2;
      if ((y - cy) * dir <= 4) continue;
      var d = Math.abs(y - cy) * 3 + Math.abs(r.left + r.width / 2 - cx);
      if (d < bd) { bd = d; best = i; }
    }
    return best;
  }
  function pressPause(b) {
    b.dispatchEvent(new MouseEvent('click', { bubbles: true }));
    if (GAME.paused) paintPauseSel();   // a toggle relabels; keep the light on it
  }
  function enterPanel() {
    pauseZone = 'panel'; pauseSel = 0;
    if (!pauseButtons().length) pauseZone = 'tabs';
    paintPauseSel();
  }
  function pauseKey(code) {
    var bs = pauseButtons();
    if (!bs.length) return false;
    var cur = (pauseSel % bs.length + bs.length) % bs.length, b = bs[cur];
    if (pauseZone === 'tabs') {
      if (code === 'ArrowDown' || code === 'Tab') pauseSel = cur + 1;
      else if (code === 'ArrowUp') pauseSel = cur - 1;
      else if (code === 'ArrowRight' || code === 'Enter' || code === 'Space') {
        var panel = b.getAttribute('data-panel');
        if (panel) { showPausePanel(panel); enterPanel(); return true; }
        if (code === 'ArrowRight') return true;   // RESUME is not a door
        pressPause(b);
        return true;
      } else return false;
      paintPauseSel();
      // walking onto a section opens it, as a tap would
      var nb = pauseButtons()[pauseSel], np = nb && nb.getAttribute('data-panel');
      if (np) showPausePanel(np);
      return true;
    }
    if (code === 'ArrowRight' || code === 'Tab') pauseSel = cur + 1;
    else if (code === 'ArrowLeft') {
      if (cur === 0) {
        // back out to the menu, on the section you came from
        pauseZone = 'tabs';
        var ts = pauseButtons();
        for (var i = 0; i < ts.length; i++) if (ts[i].getAttribute('data-panel') === pausePanel) pauseSel = i;
      } else pauseSel = cur - 1;
    }
    else if (code === 'ArrowDown') pauseSel = pauseRowStep(bs, cur, 1);
    else if (code === 'ArrowUp') pauseSel = pauseRowStep(bs, cur, -1);
    else if (code === 'Enter' || code === 'Space') { pressPause(b); return true; }
    else return false;
    paintPauseSel();
    return true;
  }
  // what you have done, as the STATS card shows it
  function paintPauseStats() {
    var box = $('pause-stats');
    if (!box) return;
    var rows = [], isOpen = !GAME.isla || GAME.isla.isOpen();
    rows.push(['GRANA', '$' + Math.floor(GAME.player.cash).toLocaleString(), 'gold']);
    var done = 0;
    if (GAME.missions) {
      var defs = GAME.missions.DEFS, bests = GAME.bests || {};
      for (var mi = 0; mi < defs.length; mi++) if (bests[defs[mi].id] !== undefined) done++;
      rows.push(['MISSÕES', done + ' / ' + defs.length + (done >= defs.length ? ' ✓' : '')]);
    }
    if (GAME.strangers && GAME.strangers.total) rows.push(['DESCONHECIDOS', GAME.strangers.done + ' / ' + GAME.strangers.total]);
    if (GAME.stunts) {
      var ST = GAME.stunts;
      rows.push(['SALTOS ACROBÁTICOS', ST.found + ' / ' + ST.total + (ST.complete ? ' ✓' : '')]);
      if (isOpen && ST.islaTotal) rows.push(['SALTOS EM ISLA', ST.islaFound + ' / ' + ST.islaTotal + (ST.islaComplete ? ' ✓' : '')]);
    }
    if (GAME.tapes && GAME.tapes.total) rows.push(['FITAS PERDIDAS', GAME.tapes.found + ' / ' + GAME.tapes.total]);
    var homes = (GAME.prefs && GAME.prefs.safehouses) || [];
    rows.push(['IMÓVEIS', String(homes.length)]);
    box.innerHTML = rows.map(function (r) {
      return '<span class="k">' + r[0] + '</span><span class="v' + (r[2] ? ' ' + r[2] : '') + '">' + r[1] + '</span>';
    }).join('');
    // what the mission count is FOR while the bridges are still shut
    var pm = $('pause-missions');
    if (pm) pm.textContent = !GAME.missions ? '' : isOpen ? (done >= GAME.missions.DEFS.length ? 'Todas as missões concluídas.' : '')
      : Math.min(done, 4) + ' de 4 missões para abrir as pontes para Isla Verde.';
    var sj = $('pause-stunts');
    if (sj) sj.textContent = GAME.stunts && GAME.stunts.complete ? 'Todos os saltos acrobáticos encontrados.' : '';
  }

  // ---------- what is hurting you ----------
  // Damage was a red flash of the whole screen, with no way to tell which
  // way to look. Now an arc turns toward whoever did it and fades over a
  // second; and below a quarter of your health the screen's edges pulse
  // until you patch up.
  var hitT = 0, lowShown = false, LOW_HEALTH = 25;
  var lowT = 0, lowHp = 100, lowSpent = false, LOW_PULSE = 10;
  function hitFrom(x, z) {
    var h = $('hit-dir');
    if (!h || !isFinite(x) || !isFinite(z)) return;
    var f = GAME.focus(), dx = x - f.x, dz = z - f.z, d = Math.sqrt(dx * dx + dz * dz);
    if (d < 0.5) return;
    var yaw = GAME.cam.yaw;
    var right = dx * -Math.cos(yaw) + dz * Math.sin(yaw), ahead = dx * Math.sin(yaw) + dz * Math.cos(yaw);
    h.style.transform = 'translate(-50%,-50%) rotate(' + Math.atan2(right, ahead).toFixed(3) + 'rad)';
    h.style.opacity = 1;
    hitT = 1;
  }

  // ---------- the first minute ----------
  // The mouse needed a click nobody mentioned, at the start and again after
  // every pause resumed from the keyboard (Esc carries no gesture the lock
  // can use). Say so whenever it is missing.
  var lockHintOn = false;
  function lockHint(on) {
    if (on === lockHintOn) return;
    lockHintOn = on;
    var h = $('lock-hint');
    if (h) h.style.display = on ? 'block' : 'none';
  }
  function stepLockHint() {
    lockHint(!!GAME.started && !GAME.isTouch && !GAME.input.pointerLocked && GAME.player.state === 'alive');
  }
  // Two tips, once per save, for someone who has not done anything yet: what
  // the coloured rings are, and what four of them open. The welcome line was
  // the only guidance there was.
  var tipT = 0, TIPS = [
    { at: 7, text: function () {
      return 'Os círculos coloridos são missões — corridas, entregas, fúrias e caças a alvos. Pare em um para começar. ' +
        (GAME.isTouch ? 'Toque no radar para ver o mapa.' : 'P abre o mapa.');
    } },
    { at: 17, text: function () {
      return GAME.isla && !GAME.isla.isOpen() ? 'Complete qualquer 4 delas e as pontes para o leste, rumo a Isla Verde, se abrem.' : '';
    } }
  ];
  function stepTips(dt) {
    var pr = GAME.prefs || {};
    if (pr.tipsSeen || !GAME.started) return;
    // Lola's welcome (guide.js) covers both, in her own words and her order
    if (pr.guide) { pr.tipsSeen = true; return; }
    // a save with missions in it already knows all this
    for (var k in (GAME.bests || {})) { GAME.prefs = pr; pr.tipsSeen = true; return; }
    var before = tipT;
    tipT += dt;
    for (var i = 0; i < TIPS.length; i++) {
      if (before < TIPS[i].at && tipT >= TIPS[i].at) {
        var t = TIPS[i].text();
        if (t) api.message(t, 6);
      }
    }
    if (tipT >= TIPS[TIPS.length - 1].at) {
      GAME.prefs = pr;
      pr.tipsSeen = true;
      GAME.save();
    }
  }

  // ---------- the message feed ----------
  // One line used to carry everything, and each message wiped the one before
  // it: "MISSION FAILED" was gone the moment the radio named a station. Now a
  // short stack, newest at the bottom, each line on its own clock; the same
  // message again just restarts the newest one's.
  var MSG_MAX = 3, msgs = [];
  function pushMessage(text, dur) {
    var top = msgs[msgs.length - 1];
    if (top && !top.fading && top.el.textContent === text) { top.t = dur; return; }
    var line = document.createElement('div');
    line.className = 'msg';
    line.textContent = text;
    el['msg-line'].appendChild(line);
    msgs.push({ el: line, t: dur, fading: false });
    while (msgs.length > MSG_MAX) msgs.shift().el.remove();
    for (var i = 0; i < msgs.length; i++) msgs[i].el.classList.toggle('old', i < msgs.length - 1);
  }
  // The pager: who the work is from, and what they have to say about it — a
  // card of its own up in the corner, so a line of story never shoves a
  // MISSION PASSED out of the message stack. One page at a time; the rest
  // wait their turn.
  var pages = [], pageT = 0, paging = false, gapT = 0;
  function nextPage() {
    var p = pages.shift();
    if (!p || !el.pager) { paging = false; if (el.pager) el.pager.classList.remove('on'); return; }
    paging = true;
    pageT = p.dur;
    el['pager-from'].textContent = '📟 ' + p.from;
    el['pager-text'].textContent = p.text;
    // and who it is from, by their face (cast.js)
    var id = GAME.cast && GAME.cast.idFor(p.from);
    if (el['pager-face']) el['pager-face'].innerHTML = id ? GAME.cast.portrait(id) : '';
    // under the radar on a phone, where it moves up into this corner
    el.pager.style.top = GAME.isTouch ? '152px' : '';
    el.pager.classList.add('on');
    if (GAME.audio.pagerBeep) GAME.audio.pagerBeep();
  }
  function pager(from, text, dur) {
    pages.push({ from: from, text: String(text), dur: dur || Math.max(5, Math.min(10, String(text).length * 0.065)) });
    if (!paging && gapT <= 0) nextPage();
  }
  function stepPager(dt) {
    if (paging) {
      pageT -= dt;
      if (pageT <= 0) { el.pager.classList.remove('on'); paging = false; gapT = 0.45; }
      return;
    }
    if (gapT > 0) gapT -= dt;
    if (pages.length && gapT <= 0) nextPage();
  }
  function stepMessages(dt) {
    for (var i = msgs.length - 1; i >= 0; i--) {
      var m = msgs[i];
      m.t -= dt;
      if (m.t <= 0 && !m.fading) { m.fading = true; m.el.classList.add('out'); }
      if (m.t <= -0.35) { m.el.remove(); msgs.splice(i, 1); }
    }
  }

  // ---------- in-game dialog (the game never throws browser popups) ----------
  var dlgOnOk = null;
  function dialog(opts) {
    dlgOnOk = opts.onOk || null;
    $('game-modal-title').textContent = opts.title || '';
    $('game-modal-body').textContent = opts.body || '';
    var ok = $('game-modal-ok'), cancel = $('game-modal-cancel');
    ok.textContent = opts.ok || 'CONFIRMAR';
    ok.className = 'mbtn' + (opts.danger ? ' danger' : '');
    cancel.style.display = opts.cancel === false ? 'none' : '';
    $('game-modal').style.display = 'flex';
  }
  function closeDialog(confirmed) {
    $('game-modal').style.display = 'none';
    var fn = confirmed ? dlgOnOk : null;
    dlgOnOk = null;
    if (fn) fn();
  }

  var api = {
    init: init,
    update: update,
    dialog: dialog,
    dialogOpen: function () { return !!$('game-modal') && $('game-modal').style.display === 'flex'; },
    dialogKey: function (code) {
      if (code === 'Enter' || code === 'KeyE') closeDialog(true);
      else if (code === 'Escape') closeDialog(false);
    },
    toggleMap: function (force) {
      if (!GAME.started) return;
      var open = force !== undefined ? force : !GAME.mapOpen;
      GAME.mapOpen = open;
      el['map-screen'].style.display = open ? 'flex' : 'none';
      // the sim loop halts while the map is open; syncOverlayMusic below
      // silences every voice the halted tick would otherwise leave held
      if (open) {
        mapCentreOnYou = mapZoom > 1;
        // on a pad the cursor starts on you; with a mouse there is none
        var you = GAME.focus();
        mapCur = GAME.controls && GAME.controls.usingPad() ? { x: you.x, z: you.z } : null;
        mapHint();
        drawBigMap();
      } else {
        mapCur = null;
        el.bigmap.width = el.bigmap.height = 0;
        if (!GAME.paused) GAME.audio.resume(); // don't leave the context suspended
      }
      // the map is a mouse screen: hand the cursor back without touching
      // fullscreen (Esc would drop both, which is why we never make the
      // player reach for it)
      if (open) GAME.releasePointer();
      else GAME.regainPointer();
      if (GAME.syncOverlayMusic) GAME.syncOverlayMusic();
      api.refreshFsBtn();
    },
    mapClear: function () { GAME.nav.clear(); if (GAME.mapOpen) drawBigMap(); },
    pauseKey: pauseKey,
    // the help cards alone (touch.js, on a switch between thumbs and keys)
    keyHelp: paintKeyHelp,
    // after a rebind: the bar and both help cards say the new keys
    keysChanged: function () {
      ctlMode = ''; refreshControlsBar(); paintKeyHelp();
      if (api.paintHintBar) api.paintHintBar();
      if (!GAME.started && el['press-enter'] && !el['press-enter'].classList.contains('loading')) titleText();
      if (GAME.mapOpen) {
        mapHint();
        // a mouse back in hand: the pad's cursor goes
        if (mapCur && !(GAME.controls && GAME.controls.usingPad())) { mapCur = null; drawBigMap(); }
      }
    },
    lockHint: lockHint,
    hitFrom: hitFrom,
    // +/- (keys and buttons): about the middle of the map
    mapZoom: function (f) {
      if (!GAME.mapOpen) return;
      if (mapCur) zoomMapAt((mapCur.x + MAP_OX) * MAP_S * mapScale - mapPanX, (mapCur.z + MAP_OY) * MAP_S * mapScale - mapPanY, f);
      else zoomMapAt(el.bigmap.width / 2, el.bigmap.height / 2, f);
    },
    mapPad: mapPad,
    mapPick: mapPick,
    mapSoloStep: stepSolo,
    get mapSolo() { return mapSolo; },
    get mapCursor() { return mapCur ? { x: mapCur.x, z: mapCur.z } : null; },
    get mapZoomLevel() { return mapZoom; },
    redrawMap: function () { if (GAME.mapOpen) drawBigMap(); },
    toggleControlsBar: function () {
      GAME.prefs = GAME.prefs || {};
      GAME.prefs.hideCtl = !GAME.prefs.hideCtl;
      GAME.save();
      ctlMode = '';
      refreshControlsBar();
      if (api.paintHintBar) api.paintHintBar();
      return !GAME.prefs.hideCtl;
    },
    cashChanged: function () { targetCash = GAME.player.cash; },
    wantedChanged: function (n) {
      var spans = el['wanted-stars'].children;
      for (var i = 0; i < spans.length; i++) spans[i].className = i < n ? 'lit' : '';
      // Both police.js paths already funnel through here, so this is the one
      // place that sees every change — but neither of them passes the level
      // you were ON, and the direction is the whole message. Keep it here.
      if (n > wantedShown) GAME.haptics.wantedUp(n);
      // the first star, and the first time it is three: what they mean
      if (n > wantedShown && GAME.lola && GAME.started) GAME.lola.first(n >= 3 ? 'stars3' : 'star');
      else if (n === 0 && wantedShown > 0) GAME.haptics.wantedClear();
      wantedShown = n;
    },
    setWeapon: function (name, ammo, iconSvg) {
      if (!el['weapon-line']) return; // may fire before the HUD is wired up
      el['weapon-line'].textContent = name + (ammo === '' ? '' : '  ·  ' + ammo);
      // and what it looks like, beside it (arsenal.js draws them)
      var wi = $('weapon-icon');
      if (wi && iconSvg !== undefined && wi.getAttribute('data-w') !== name) { wi.innerHTML = iconSvg; wi.setAttribute('data-w', name); }
    },
    message: function (text, dur) { pushMessage(String(text), dur || 2.5); },
    // Letterbox for a moment that plays itself (the glass lift): black bars
    // in, the HUD and the thumbs out, and a tap anywhere to skip it.
    cine: function (on, onSkip, opts) {
      document.body.classList.toggle('cine', !!on);
      var c = $('cine'), sk = $('cine-skip'), ph = $('cine-photo');
      // a ride (the lift, the wheel) keeps the camera: a button of its own on
      // the bars, since the thumbs are put away and a tap anywhere else skips
      var photo = !!(on && opts && opts.photo);
      if (sk) sk.textContent = (photo && !GAME.isTouch ? 'C · FOTO     ' : '') + (GAME.isTouch ? 'TOQUE PARA PULAR' : 'ESPAÇO OU CLIQUE PARA PULAR');
      if (ph) {
        ph.style.display = photo ? 'block' : 'none';
        ph.onpointerdown = photo ? function (e) { e.preventDefault(); e.stopPropagation(); if (GAME.photo) GAME.photo.snap(); } : null;
      }
      if (c) c.onpointerdown = on && onSkip ? function (e) { e.preventDefault(); onSkip(); } : null;
    },
    pager: pager,
    enterHint: function (text) {
      var e = el['enter-hint'];
      if (!e) return;
      if (text) e.textContent = text;
      e.style.opacity = text ? 1 : 0;
    },
    get pagerText() { return paging && el['pager-text'] ? el['pager-text'].textContent : ''; },
    get pagerFrom() { return paging && el['pager-from'] ? el['pager-from'].textContent : ''; },
    get pagerFace() { return paging && el['pager-face'] ? el['pager-face'].innerHTML : ''; },
    // the huge centre numeral for mission countdowns. Callers repeat it every
    // frame while the count runs; it lets go of the screen on its own once
    // they stop (which is how "GO!" gets its moment and then clears itself)
    bigCount: function (text) {
      var e = el['count-big'];
      text = String(text);
      if (e.textContent !== text) e.textContent = text;
      e.style.opacity = 1;
      countT = 0.8;
    },
    radioPopup: function (name) {
      el['radio-popup'].textContent = '♪ ' + name;
      // where it is on the dial and what it plays, and its jingle (dj.js)
      if (GAME.dj) GAME.dj.tuned(name);
      el['radio-popup'].style.opacity = 1;
      radioT = 2.6;
    },
    damageFlash: function () {
      GAME.haptics.hurt();
      dmgFlash.style.opacity = 1;
      setTimeout(function () { dmgFlash.style.opacity = 0; }, 120);
    },
    missionStart: function (title, obj) {
      el['mission-hud'].style.display = 'block';
      el['mission-title'].textContent = title;
      el['mission-obj'].textContent = obj;
      el['mission-timer'].textContent = '';
      placeZone();
    },
    missionObjective: function (obj) { el['mission-obj'].textContent = obj; },
    missionTimer: function (t, countdown) {
      // (null: no clock on this one any more)
      if (t === null) { el['mission-timer'].textContent = ''; return; }
      var s = Math.max(0, t);
      var mm = Math.floor(s / 60), ss = Math.floor(s % 60);
      el['mission-timer'].textContent = mm + ':' + (ss < 10 ? '0' : '') + ss;
      el['mission-timer'].style.color = countdown && s < 12 ? '#ff5d7a' : '#8dffd8';
    },
    missionEnd: function () { el['mission-hud'].style.display = 'none'; placeZone(); },
    // the corner fullscreen control — available everywhere (menus, portrait
    // overlay and in-game) and hidden only once you're actually fullscreen.
    refreshFsBtn: function () {
      var e = $('fs-btn');
      if (!e) return;
      // always on hand until you're actually fullscreen (or playing from the
      // home screen, which is), then it's redundant
      e.style.display = (GAME.fullscreenEl && GAME.fullscreenEl()) || (GAME.isStandalone && GAME.isStandalone()) ? 'none' : 'flex';
      // and the pause screen's switch, which says which it is (a home-screen
      // app is full screen already, and has no use for it)
      var pf = $('pause-fs');
      if (pf) {
        pf.style.display = GAME.isStandalone && GAME.isStandalone() ? 'none' : '';
        pf.textContent = GAME.fullscreenEl && GAME.fullscreenEl() ? '⛶ TELA CHEIA: LIGADA' : '⛶ TELA CHEIA: DESLIGADA';
      }
    },
    // AUTO runs the day/night cycle; DAY / NIGHT pin it
    refreshTimeBtn: function (mode) {
      var e = $('pause-day');
      if (!e) return;
      e.textContent = mode === 'day' ? '☀ HORA: DIA' : mode === 'night' ? '🌙 HORA: NOITE' : '🕓 HORA: AUTO';
    },
    // names the POI you're near ('' hides it)
    setPoiHint: function (text) {
      var e = el['poi-hint'];
      if (!e) return;
      // asked every tick, and nearly always with what it already shows
      if (text === lastPoiHint) return;
      lastPoiHint = text;
      if (text) { e.textContent = text; e.style.opacity = 1; }
      else e.style.opacity = 0;
    },
    showBig: function (kind, sub) {
      var scr = el[kind + '-screen'];
      scr.style.display = 'flex';
      scr.querySelector('.big-sub').textContent = sub || '';
      var hint = scr.querySelector('.big-hint');
      if (hint) hint.textContent = GAME.isTouch ? 'TOQUE PARA CONTINUAR' : 'APERTE ' + K('KeyR') + ' PARA CONTINUAR';
    },
    hideBig: function () {
      el['wasted-screen'].style.display = 'none';
      el['busted-screen'].style.display = 'none';
    },
    fade: function (cb) {
      el['fade-layer'].style.opacity = 1;
      setTimeout(function () {
        try { cb && cb(); } finally {
          setTimeout(function () { el['fade-layer'].style.opacity = 0; }, 150);
        }
      }, 550);
    },
    // the raw dimmer, for rituals that keep their own time (mission starts
    // count the blackout in game ticks, so pausing pauses it)
    fadeSet: function (v) { el['fade-layer'].style.opacity = v; },
    titleReady: function () {
      var pe = el['press-enter'];
      pe.classList.remove('loading');
      titleText();
    },
    hideTitle: function () {
      el['title-screen'].style.display = 'none';
      document.getElementById('hud').style.display = 'block';
      api.refreshFsBtn();
    },
    setPaused: function (p) {
      el['pause-screen'].style.display = p ? 'flex' : 'none';
      if (api.paintAbandon) api.paintAbandon(true);
      if (p) { pauseZone = 'tabs'; pauseSel = 0; showPausePanel('pp-stats'); paintPauseSel(); }
      // a phone has no Esc and no arrow keys to mention (and a touchscreen
      // laptop can go back to its mouse between pauses)
      var ph = $('pause-hint');
      if (p && ph) {
        if (ph.__mouse === undefined) ph.__mouse = ph.innerHTML;
        if (GAME.isTouch) ph.textContent = 'Toque em CONTINUAR, ou em qualquer lugar fora do menu, para seguir';
        else ph.innerHTML = ph.__mouse;
      }
      paintPauseStats();
      var pl = $('pause-place');
      if (pl && p) { var zf = GAME.focus(); pl.textContent = (GAME.city.districtName(zf.x, zf.z) || '').toUpperCase(); }
      api.refreshFsBtn();
    },
    toggleCRT: function () {
      var on = el['crt-layer'].style.display !== 'block';
      el['crt-layer'].style.display = on ? 'block' : 'none';
      return on;
    },
    // headless hook: where a home you own lands on the radar, and as what
    testHomeMarker: homeMarker,
    testIslaLabels: islaDistrictLabels,
    testHelipads: shownHelipads,
    testToggleCat: toggleCat,
    // How much marker-cyan the BAKED base image carries around a world point.
    // The base is painted once and sits underneath the live pass, so whatever
    // is burned into it is beyond the legend's reach — which is the whole
    // reason markers are not drawn here.
    testBaseInk: function (wx, wz, r) {
      if (!mapBuffer) return -1;
      var bx = Math.round((wx + MAP_OX) * MAP_S), by = Math.round((wz + MAP_OY) * MAP_S);
      var d = mapBuffer.getContext('2d').getImageData(bx - r, by - r, r * 2, r * 2).data, n = 0;
      for (var i = 0; i < d.length; i += 4) {
        if (d[i] > 100 && d[i] < 180 && d[i + 1] > 190 && d[i + 2] > 220) n++;
      }
      return n;
    }
  };
  return api;
})();

// destination routing along the road graph
GAME.nav = (function () {
  var dest = null, path = [], recompT = 0;

  // Dijkstra over edge length along the road-node graph; [{x,z}...] start->goal.
  // Hop-count BFS minimized the wrong thing once the island joined: its lane
  // links run ~34 m against the mainland's ~100 m blocks, so "fewest edges"
  // biased routes onto fewer-but-longer mainland legs. Metres win now. The
  // graph is a few hundred nodes, so the heapless closest-first scan is
  // comfortably inside budget.
  //
  // The search's working state lives in typed arrays, one slot per road node
  // (a node's id is its index), reused by every call and told apart by a
  // generation stamp. A route is asked for every second along a race line,
  // every 1.5 s by the map and every 2.5 s by each rival, and each ask used
  // to build three maps and an open list afresh, then splice the open list
  // once per node it settled.
  var pDist = null, pPrev = null, pSeen = null, pDone = null, pGen = 0, pOpen = [];
  function roadPath(x0, z0, x1, z1) {
    var start = GAME.city.nearestNode(x0, z0);
    var goal = GAME.city.nearestNode(x1, z1);
    if (!start || !goal) return [];
    // a closed bridge doesn't route: while the gates are down the spans are
    // off the graph, so a cross-channel destination degrades to a stub at
    // the far end instead of a confident line through the police barrier
    var gated = GAME.isla && !GAME.isla.isOpen();
    var nodes = GAME.city.nodes;
    if (!pDist || pDist.length < nodes.length) {
      pDist = new Float64Array(nodes.length); pPrev = new Int32Array(nodes.length);
      pSeen = new Uint32Array(nodes.length); pDone = new Uint32Array(nodes.length); pGen = 0;
    }
    // (the open list is sized by a count of its own, never by its length:
    // truncating a JS array to nothing drops its storage, and it would be
    // grown again on every call)
    var g = ++pGen, open = pOpen, on = 0;
    open[on++] = start;
    pSeen[start.id] = g; pDist[start.id] = 0; pPrev[start.id] = -1;
    while (on) {
      var bi = 0;
      for (var i = 1; i < on; i++) if (pDist[open[i].id] < pDist[open[bi].id]) bi = i;
      var n = open[bi];
      // taken out in place, keeping the rest in order (as splice did), so
      // among equally short routes the same one wins as before
      for (var k = bi; k < on - 1; k++) open[k] = open[k + 1];
      on--;
      var nk = n.id;
      if (pDone[nk] === g) continue;
      pDone[nk] = g;
      if (n === goal) break;
      var nbs = GAME.city.neighbors(n);
      for (var j = 0; j < nbs.length; j++) {
        var b = nbs[j];
        if (gated && b.span) continue;
        var bk = b.id;
        if (pDone[bk] === g) continue;
        var d = pDist[nk] + U.dist(n.x, n.z, b.x, b.z);
        if (pSeen[bk] !== g || d < pDist[bk]) {
          pSeen[bk] = g; pDist[bk] = d; pPrev[bk] = nk;
          open[on++] = b;
        }
      }
    }
    // an unreached goal is no route at all: the degraded walk-back used to
    // hand back a single far-end stub, and the map drew the player-to-stub
    // connector as a confident schematic line straight across the water
    if (pSeen[goal.id] !== g) return [];
    var out = [], cur = goal.id;
    while (cur >= 0) { out.push({ x: nodes[cur].x, z: nodes[cur].z }); cur = pPrev[cur]; }
    out.reverse();
    // The search runs junction to junction, and the junction nearest a place
    // is as often past it as short of it: the line ran on by the destination
    // to the next corner and came back for it, a U-turn at the lights nobody
    // makes. The same at the start, back to the corner behind you first.
    // A place that lies along the last block is reached on it; a start that
    // lies along the first block sets off on it.
    if (out.length >= 2 && along(out[out.length - 1], out[out.length - 2], x1, z1)) out.pop();
    if (out.length >= 2 && along(out[0], out[1], x0, z0)) out.shift();
    // down to one corner, with you and the place on the same street the same
    // side of it: nothing to turn at, straight there
    if (out.length === 1) {
      var n0 = out[0], ax = x0 - n0.x, az = z0 - n0.z, bx = x1 - n0.x, bz = z1 - n0.z;
      var la = Math.sqrt(ax * ax + az * az), lb = Math.sqrt(bx * bx + bz * bz);
      if (la > 1 && lb > 1 && (ax * bx + az * bz) / (la * lb) > 0.8) out[0] = { x: x1, z: z1 };
    }
    return out;
  }
  // p lies along the block from corner n toward corner a: between them, and
  // on (or by) that road rather than a street over
  function along(n, a, px, pz) {
    var sx = a.x - n.x, sz = a.z - n.z, l2 = sx * sx + sz * sz;
    if (l2 < 1) return false;
    var t = ((px - n.x) * sx + (pz - n.z) * sz) / l2;
    if (t <= 0 || t > 1) return false;
    var ox = px - (n.x + sx * t), oz = pz - (n.z + sz * t);
    return ox * ox + oz * oz < 18 * 18;
  }

  function computePath() {
    if (!dest) { path = []; return; }
    var PF = GAME.focus();
    var px = PF.x;
    var pz = PF.z;
    // route to the road nearest the destination, then a short hop off the road,
    // so the drawn line stays on the streets instead of cutting through blocks
    var rp = GAME.city.nearestRoadPoint(dest.x, dest.z);
    dest.rx = rp.x; dest.rz = rp.z;
    path = roadPath(px, pz, rp.x, rp.z);
    // no route, no line — the destination marker alone tells the story
    if (path.length) path.push({ x: rp.x, z: rp.z });
  }

  return {
    get dest() { return dest; },
    get path() { return path; },
    roadPath: roadPath,
    setDest: function (x, z) {
      dest = { x: x, z: z };
      computePath();
      GAME.hud.message('Destino definido — siga a rota.', 2);
    },
    clear: function () { dest = null; path = []; },
    update: function (dt) {
      if (!dest) return;
      recompT -= dt;
      if (recompT <= 0) { recompT = 1.5; computePath(); }
      var P = GAME.player;
      var PF = GAME.focus();
      var px = PF.x;
      var pz = PF.z;
      // Arrived means near, not on top of. A map click often lands mid-block,
      // somewhere no road passes — so pulling up on the kerb beside it counts,
      // and a car counts from further out than a person walking the last bit.
      var R2 = P.inCar ? 26 * 26 : 12 * 12;
      var dNow = U.dist2(px, pz, dest.x, dest.z);
      var dRoad = dest.rx !== undefined ? U.dist2(px, pz, dest.rx, dest.rz) : 1e18;
      if (dNow < R2 || (dRoad < R2 && dNow < 55 * 55)) {
        dest = null; path = [];
        GAME.hud.message('Você chegou.', 2.5);
        GAME.audio.pickup();
        GAME.haptics.checkpoint();
      }
    }
  };
})();

// The radio's personality. Every station on the dial is somewhere on it, a
// sound and a voice: a frequency, what it plays, a DJ, and a jingle of its
// own when you tune in. Every minute or so the songs dip and the DJ talks,
// or an ad comes on — 1986's finest — in a caption under the station's
// name and a voice that is all pitch and no words, the way the people in
// the story talk (cast.js). It is all on the music's side: MUSIC: OFF, the
// car door and mute take it with the songs.
GAME.dj = (function () {
  var enabled = true;
  // the stations, by the name audio.js gives them
  var ID = {
    'WAVE 84': { freq: '84.3 FM', genre: 'NEW WAVE E SYNTH-POP', dj: 'JOHNNY WAVE', color: '#38e8ff',
      jingle: [64, 67, 71, 76], wave: 'sawtooth',
      voice: { base: 180, wave: 'square', cps: 40, spread: 9, formant: 1300, q: 1.6 },
      lines: [
        'Aqui é a WAVE 84, o som do amanhã, hoje. O amanhã é basicamente laquê.',
        'Se o seu carro não tem toca-fitas, não sei o que dizer. Arrume um carro novo. Roube um, não me importo.',
        'Alguém ligou dizendo que sintetizador não é instrumento de verdade. Alguém está errado.',
        'Johnny Wave falando, ao vivo de uma cabine sem janelas e com muitas opiniões.',
        'O trânsito na orla está parado até depois do Neon Tide. De novo. Talvez ir a pé. Ha. Ninguém anda a pé.',
        'Curiosidade: esta próxima foi gravada inteirinha em um computador doméstico. O futuro é estranho, Costa Rosa.'
      ] },
    'RIVIERA FM': { freq: '96.1 FM', genre: 'DISCO, BOOGIE E POP', dj: 'COCO RIVIERA', color: '#ffe14f',
      jingle: [72, 76, 79, 84, 79], wave: 'triangle',
      voice: { base: 300, wave: 'triangle', cps: 38, spread: 8, formant: 1600, q: 1.7 },
      lines: [
        'Riviera FM, queridos! Abaixe a capota, aumente o volume e deixe as preocupações no porta-luvas.',
        'A disco não morreu. A disco se mudou para Costa Rosa e comprou um barco.',
        'Aqui é a Coco com um recado para o cavalheiro de terno branco: a gente te viu, e a gente gostou.',
        'Dia quente hoje. Dia quente amanhã. É sempre um dia quente. É por isso que você mora aqui.',
        'Dançar é só andar com ritmo. Então dance até a lojinha da esquina, querido.',
        'Se você está ouvindo isto, não está dançando forte o bastante.'
      ] },
    'NIGHTFALL': { freq: '101.9 FM', genre: 'SLOW JAMS E MADRUGADAS', dj: 'VELVET DEE', color: '#c86bff',
      jingle: [57, 64, 67, 72], wave: 'sine',
      voice: { base: 140, wave: 'sine', cps: 26, spread: 5, formant: 900, q: 1.4 },
      lines: [
        'Nightfall. Cento e um vírgula nove. Baixe as luzes, baixe a voz, baixe as expectativas.',
        'Esta vai para todo mundo dirigindo sozinho esta noite. Você não está sozinho. Eu estou aqui. No seu painel.',
        'Velvet Dee, te fazendo companhia até o sol nascer e estragar tudo.',
        'Dizem que o amor é um campo de batalha. Nesta cidade é mais uma perseguição de carro.',
        'Devagar, querido. A música é lenta. A noite é lenta. A polícia, não.',
        'Se alguém partiu seu coração, ligue para a rádio. Se alguém quebrou seu para-brisa, ligue para outra pessoa.'
      ] },
    'TAPE DECK FM': { freq: '88.8 PIRATA', genre: 'ITALO DO PÍER', dj: 'CAPTAIN CASSETTE', color: '#7dff6a',
      jingle: [69, 72, 76, 81, 76, 81], wave: 'square',
      voice: { base: 210, wave: 'sawtooth', cps: 44, spread: 11, formant: 1450, q: 1.5 },
      lines: [
        'Capitão Cassete, de volta ao ar na ponta do píer! Me tiraram do ar, você achou minhas fitas. Respeito.',
        'Esta transmissão não é licenciada. Esta transmissão não é legal. Esta transmissão é BOA.',
        'Cada fita que você pegou no chão é uma música que fiz numa garagem. Valeu, garoto.',
        'Se a guarda costeira perguntar, você nunca ouviu esta estação.',
        'Italo disco: é como a disco normal, só que anda mais rápido e não usa cinto de segurança.'
      ] }
  };
  // the ads, on any station
  var ADS = [
    'Gull Downs: onde todo cavalo é vencedor até a corrida começar. Gull Downs, no Lucky Gull.',
    'Seu cabelo está volumoso o bastante? O de alguém está? Mousse Américaine. Para cabelo que entra na sala antes de você.',
    'Vulture GT. De zero a cem em \"nem pergunte\". Gran Rosa Motors, no boulevard.',
    'Sorvete Sunny Scoops: feito em Isla Verde, congelado até o osso, totalmente legal. Sunny Scoops!',
    'Foi vítima de um crime? O advogado Stan Pike dá resultado. Resultado não garantido. Stan não é advogado.',
    'Costa Rosa Savings & Loan. Seu dinheiro está seguro com a gente. Temos muita, muita certeza. Pare de perguntar.',
    'O novo Telefone de Bolso — só quatro quilos! Faça ligações de qualquer lugar onde você consiga carregar quatro quilos.',
    'THREADS em Centro Alto: pastel não é cor, é estilo de vida. Jaquetas de linho pela metade do preço.'
  ];
  var talkT = 40, seg = null, caption = null, deal = {};

  function $(id) { return document.getElementById(id); }
  function titleCase(t) { return String(t).toLowerCase().replace(/\b[a-z]/g, function (c) { return c.toUpperCase(); }); }
  function idOf(name) { return ID[name] || null; }
  // where it is on the dial, under its name, as you tune in — and its jingle
  function tuned(name) {
    var id = idOf(name), box = $('radio-popup');
    if (box) {
      box.innerHTML = '';
      box.appendChild(document.createTextNode('♪ ' + name));
      if (id) {
        var sub = document.createElement('div');
        sub.className = 'rsub';
        // (and who is on: a DJ's name in a caption meant nothing to anybody
        // who had not been told it was the radio talking)
        sub.textContent = id.freq + '  ·  ' + id.genre + '  ·  com o DJ ' + titleCase(id.dj);
        sub.style.color = id.color;
        box.appendChild(sub);
      }
    }
    stopTalk();
    talkT = 20 + GAME.soundRandom() * 25;
    if (enabled && id && GAME.audio && GAME.audio.radio && GAME.audio.radio.jingle) GAME.audio.radio.jingle(id.jingle, id.wave);
  }
  // the next of a list, round it, never the same twice running
  function next(key, list) {
    var i = deal[key] === undefined ? Math.floor(GAME.soundRandom() * list.length) : (deal[key] + 1) % list.length;
    deal[key] = i;
    return list[i];
  }
  // a minute or so on: the DJ, or an ad
  function segment() {
    var R = GAME.audio && GAME.audio.radio;
    if (!R || !R.audible) return null;
    var id = idOf(R.name);
    if (!id) return null;
    // (an ad is for cruising: never in the middle of a job, a race, a favour
    // or a heist — Gull Downs' horses came on in the middle of a first
    // delivery. The DJ can still say a word; the ads wait.)
    var ad = roaming() && GAME.soundRandom() < 0.4;
    var text = ad ? next('ads', ADS) : next(R.name, id.lines);
    var who = ad ? 'AD' : id.dj;
    var dur = Math.min(9, 2.5 + text.length * 0.045);
    seg = { text: text, who: who, t: 0, dur: dur, i: 0, voice: ad ? ID['RIVIERA FM'].voice : id.voice, letters: text.replace(/[^A-Za-z]/g, '') };
    R.duck(0.35, dur);
    var c = $('radio-talk');
    if (c) {
      c.innerHTML = '';
      var w = document.createElement('b');
      // which station, and whether it is its DJ talking or an advert
      w.textContent = '📻 ' + R.name + (ad ? ' · PUBLICIDADE: ' : ' · DJ ' + titleCase(who) + ': ');
      w.style.color = id.color;
      c.appendChild(w);
      c.appendChild(document.createTextNode(text));
      c.classList.add('on');
    }
    if (GAME.track) GAME.track(ad ? 'radio-ad' : 'radio-dj');
    return seg;
  }
  function roaming() {
    var G = GAME;
    return !((G.missions && G.missions.active) || (G.strangers && G.strangers.busy) || (G.heist && G.heist.busy) ||
      (G.rc && G.rc.running) || (G.robbery && G.robbery.busy) || (G.guide && G.guide.step) || G.player.interior);
  }
  function stopTalk() {
    seg = null;
    var c = $('radio-talk');
    if (c) c.classList.remove('on');
  }
  function update(dt) {
    if (!enabled || !GAME.started) return;
    var P = GAME.player, R = GAME.audio && GAME.audio.radio;
    var on = P.inCar && P.state === 'alive' && R && R.audible;
    if (!on) { if (seg) stopTalk(); return; }
    if (seg) {
      // (a job started half way through an ad: the ad is over)
      if (seg.who === 'AD' && !roaming()) { stopTalk(); R.duck(1, 0.3); return; }
      seg.t += dt;
      var v = seg.voice, want = Math.floor(seg.t * v.cps / 2);
      while (seg.i < want && seg.i * 2 < seg.letters.length) { R.talk(v, seg.letters.charAt(seg.i * 2)); seg.i++; }
      if (seg.t >= seg.dur) { stopTalk(); talkT = 45 + GAME.soundRandom() * 35; }
      return;
    }
    talkT -= dt;
    if (talkT <= 0) { talkT = 50; segment(); }
  }

  return {
    update: update,
    tuned: tuned,
    segment: segment,
    get talking() { return seg ? { who: seg.who, text: seg.text } : null; },
    identity: idOf,
    roaming: roaming,
    get enabled() { return enabled; },
    set enabled(v) { enabled = !!v; if (!enabled) stopTalk(); },
    ADS: ADS
  };
})();

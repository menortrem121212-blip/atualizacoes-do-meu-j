/* Town Vehicles add-on: visual models only; original handling, collisions and missions remain intact. */
(function () {
  // ID exclusivo por arquivo/modelo visual. A ordem abaixo é a ordem oficial:
  // primeiro arquivo = ID 1, segundo = ID 2, e assim por diante.
  // Nunca use apenas o tipo genérico (sedan/van/etc.) para salvar a escala de GLBs.
  var files = [
    ['red-wedge-sports-car.glb','sports',1],['low-poly-monster-truck.glb','monster',2],
    ['pastel-ice-cream-truck.glb','van',3],['open-wheel-racer.glb','sports',4],
    ['low-poly-garbage-truck.glb','van',5],['low-poly-camper-rv.glb','van',6],
    ['low-poly-speedboat.glb','boat',7],['blue-pickup-truck.glb','pickup',8],
    ['low-poly-tow-truck.glb','van',9],['family-suv.glb','sedan',10],
    ['low-poly-golf-cart.glb','buggy',11],['pearl-white-minivan.glb','van',12],
    ['lime-dirt-bike.glb','motorcycle',13],['orange-go-kart.glb','buggy',14],
    ['mint-motor-scooter.glb','motorcycle',15],['baby-blue-convertible.glb','sports',16],
    ['armoured-cash-van.glb','van',17],['low-poly-hatchback.glb','sedan',18],
    ['yellow-rescue-helicopter.glb','helicopter',19],['silver-family-sedan.glb','sedan',20],
    ['low-poly-delivery-van.glb','van',21],['stretch-limousine.glb','limo',22],
    ['pastel-mini-ev.glb','sedan',23],['food-delivery-scooter.glb','motorcycle',24]
  ];
  var models = {}, byType = {}, ready = false;
  function cloneModel(template) {
    var c = template.clone(true);
    c.traverse(function(o){ if(o.isMesh){o.castShadow=true;o.receiveShadow=true;} });
    return c;
  }
  function fit(model, car) {
    // Ajusta cada eixo separadamente para que o GLB ocupe a mesma caixa
    // física do veículo original (largura e comprimento em metros do jogo).
    model.updateMatrixWorld(true);
    var b = new THREE.Box3().setFromObject(model);
    var size = b.getSize(new THREE.Vector3());
    var spec = car.spec || {};
    var targetL = spec.l || 4.4;
    // Visual GLBs were being fitted to the narrow collision width (1.9–2.1 m),
    // making every imported vehicle look pinched from the rear. Keep physics
    // untouched and give the rendered model a realistic lateral envelope.
    var targetW = (spec.w || 1.9) * 1.28 * 1.33; // +33% sobre a correção anterior (largura visual total: 1.7024x)
    var targetH = Math.max(1.15, (spec.cabinH || 0) + (spec.bodyH || 0) + 0.55);
    var groundY = model.position.y;
    if (size.x > 0.0001 && size.y > 0.0001 && size.z > 0.0001) {
      model.scale.set(
        model.scale.x * targetW / size.x,
        model.scale.y * targetH / size.y,
        model.scale.z * targetL / size.z
      );
      model.updateMatrixWorld(true);
      b.setFromObject(model);
      // Mantém os pneus/base no chão sem deslocar o veículo para Y=0.
      model.position.y += groundY - b.min.y;
    }
    return model;
  }
  function apply(car, template, force) {
    if(!car || !car.mesh || !template || (car._townModelApplied && !force)) return;
    var old=car.mesh, fresh=cloneModel(template);
    fresh.position.copy(old.position);
    fresh.rotation.copy(old.rotation);
    fresh.scale.set(1,1,1);
    fit(fresh,car);
    if(old.userData && old.userData.rotor) fresh.userData.rotor=old.userData.rotor;
    if(GAME.scene){ GAME.scene.remove(old); GAME.scene.add(fresh); }
    car.mesh=fresh; car.pos=fresh.position; car._townModelApplied=true;
    if(old.parent) old.parent.remove(old);
    // A replacement GLB has a different baseline scale. Keep its physics spec
    // per instance and let the editor reapply the saved model-wide dimensions.
    car.editorBase=null;
    if(GAME.vehicleEditorApplySavedDimensions) GAME.vehicleEditorApplySavedDimensions(car);
  }
  function choose(car) {
    var list=byType[car.type];
    if(!list || !list.length) return;
    var index=car._townVariant;
    if(index===undefined) index=Math.floor(Math.random()*list.length);
    car._townVariant=index;
    car._townModelKey=list[index]; // filename retained for compatibility/debugging
    var entry=files.find(function(f){return f[0]===list[index];});
    car._townModelId=entry ? entry[2] : null; // stable numeric ID unique to this exact GLB
    if(models[list[index]]) apply(car,models[list[index]]);
  }
  function setModel(car, file) {
    var entry=files.find(function(f){return f[0]===file;});
    if(!car || !entry || car.type!==entry[1]) return false;
    car._townNoModel=false; car._townForcedModel=file; car._townModelKey=file; car._townModelId=entry[2];
    car._townVariant=(byType[entry[1]]||[]).indexOf(file);
    if(models[file]) apply(car,models[file],true); else car._townPendingFile=file;
    return true;
  }
  GAME.townVehicles = {
    list:function(){return files.map(function(f){return {file:f[0],type:f[1],id:f[2],name:f[0].replace(/\.glb$/i,'').replace(/[-_]+/g,' ').replace(/\b\w/g,function(c){return c.toUpperCase();}),format:'glb'};});},
    setModel:setModel,
    isReady:function(){return ready;}
  };
  function loadAll() {
    if(!GAME.carConcept || !GAME.carConcept.parseGLB) return;
    var jobs=files.map(function(entry){
      return fetch('media/town-vehicles/'+entry[0]).then(function(r){
        if(!r.ok) throw new Error('Falha ao carregar '+entry[0]);
        return r.arrayBuffer();
      }).then(function(buf){
        var model=GAME.carConcept.parseGLB(buf);
        models[entry[0]]=model;
        (byType[entry[1]]||(byType[entry[1]]=[])).push(entry[0]);
      }).catch(function(e){ if(window.console) console.warn('Town vehicle:',e); });
    });
    Promise.all(jobs).then(function(){
      ready=true;
      if(GAME.world && GAME.world.cars) GAME.world.cars.forEach(function(car){
        if(car && car._townPendingFile && models[car._townPendingFile]) { var file=car._townPendingFile; car._townPendingFile=null; setModel(car,file); }
        else if(car && !car._townNoModel && !car._townForcedModel) choose(car);
      });
    });
  }
  function install() {
    if(!GAME.vehicles || !GAME.vehicles.spawnCar || GAME.vehicles._townWrapped) return false;
    var original=GAME.vehicles.spawnCar;
    GAME.vehicles.spawnCar=function(type){
      var car=original.apply(this,arguments), opts=arguments[4]||{};
      if(car && opts.noTownModel) car._townNoModel=true;
      if(ready && car && !car._townNoModel) choose(car);
      else if(car && !ready) car._townWaiting=true;
      return car;
    };
    GAME.vehicles._townWrapped=true;
    loadAll();
    return true;
  }
  var tries=0, timer=setInterval(function(){
    tries++;
    if(install() || tries>100) clearInterval(timer);
  },100);
})();

/* Individual building editor: each ordinary procedural building has its own
   mesh, stable map ID and collision box. Dimension multipliers are isolated. */
(function () {
  'use strict';
  var root = document.getElementById('building-editor');
  if (!root || !window.GAME || !GAME.city) return;
  var $ = function (id) { return document.getElementById(id); };
  var active = false, selected = null, lastHit = null, lastAt = 0;

  // Controles próprios do editor de prédios: mover e redimensionar o painel.
  (function bindBuildingMenuTools(){
    var card = $('building-editor-card');
    var move = $('be-move-menu');
    var slider = $('be-menu-size');
    var output = $('be-menu-size-value');
    if (!card || !move || !slider || !output) return;

    slider.addEventListener('pointerdown', function(e){ e.stopPropagation(); });
    slider.addEventListener('input', function(){
      var value = Number(slider.value);
      card.style.zoom = String(value / 100);
      output.textContent = value + '%';
    });

    var drag = null;
    move.addEventListener('pointerdown', function(e){
      if (e.button !== undefined && e.button !== 0) return;
      var rect = root.getBoundingClientRect();
      drag = { id:e.pointerId, x:e.clientX, y:e.clientY, left:rect.left, top:rect.top };
      root.style.position = 'fixed';
      root.style.transform = 'none';
      root.style.margin = '0';
      root.style.left = rect.left + 'px';
      root.style.top = rect.top + 'px';
      root.style.right = 'auto';
      root.style.bottom = 'auto';
      root.style.width = Math.min(rect.width, window.innerWidth - 12) + 'px';
      try { move.setPointerCapture(e.pointerId); } catch (_) {}
      e.preventDefault();
      e.stopPropagation();
    });
    move.addEventListener('pointermove', function(e){
      if (!drag || e.pointerId !== drag.id) return;
      var rect = root.getBoundingClientRect();
      root.style.left = Math.max(0, Math.min(window.innerWidth - rect.width, drag.left + e.clientX - drag.x)) + 'px';
      root.style.top = Math.max(0, Math.min(window.innerHeight - rect.height, drag.top + e.clientY - drag.y)) + 'px';
    });
    function stop(e){ if (drag && (e.pointerId === undefined || e.pointerId === drag.id)) drag = null; }
    move.addEventListener('pointerup', stop);
    move.addEventListener('pointercancel', stop);
  })();
  var ray = new THREE.Raycaster(), pointer = new THREE.Vector2();
  var controls = $('be-controls'), status = $('be-status'), dims = {};
  try { dims = JSON.parse(localStorage.getItem('neonMayhemBuildingDimsV3') || '{}') || {}; } catch (_) { dims = {}; }
  function persistDims() {
    try {
      localStorage.setItem('neonMayhemBuildingDimsV3', JSON.stringify(dims));
      return true;
    } catch (e) {
      if (status) status.textContent = 'Não foi possível gravar no armazenamento deste navegador.';
      return false;
    }
  }

  function vals() { return { w: +$('be-width').value, d: +$('be-length').value, h: +$('be-height').value }; }
  function labels(v) {
    $('be-width-value').textContent = v.w.toFixed(2) + '×';
    $('be-length-value').textContent = v.d.toFixed(2) + '×';
    $('be-height-value').textContent = v.h.toFixed(2) + '×';
  }
  function show(v) { $('be-width').value = v.w; $('be-length').value = v.d; $('be-height').value = v.h; labels(v); }
  function apply(rec, v) {
    if (!rec || !rec.mesh || !rec.solid) return false;
    rec.mesh.scale.set(v.w, v.h, v.d);
    rec.mesh.updateMatrix(); rec.mesh.updateMatrixWorld(true);
    if (rec.mesh.geometry) { rec.mesh.geometry.computeBoundingBox(); rec.mesh.geometry.computeBoundingSphere(); }
    GAME.city.hash.remove(rec.solid);
    rec.solid.minX = rec.x - rec.base.w * v.w / 2;
    rec.solid.maxX = rec.x + rec.base.w * v.w / 2;
    rec.solid.minZ = rec.z - rec.base.d * v.d / 2;
    rec.solid.maxZ = rec.z + rec.base.d * v.d / 2;
    rec.solid.h = rec.base.h * v.h;
    GAME.city.hash.insert(rec.solid);
    rec.dims = { w: v.w, d: v.d, h: v.h };
    return true;
  }
  function select(rec) {
    if (!rec || !rec.mesh) return;
    selected = rec;
    var v = dims[rec.id] || rec.dims || { w: 1, d: 1, h: 1 };
    show(v); controls.hidden = false; apply(rec, v);
    status.textContent = 'Selecionado: ' + rec.id + ' — ajuste largura, comprimento e altura.';
  }
  function hit(e) {
    var canvas = GAME.renderer && GAME.renderer.domElement, camera = GAME.cameraObj;
    if (!canvas || !camera) return null;
    var r = canvas.getBoundingClientRect();
    if (!r.width || !r.height || e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom) return null;
    pointer.set(((e.clientX-r.left)/r.width)*2-1, -((e.clientY-r.top)/r.height)*2+1);
    camera.updateMatrixWorld(true); GAME.scene && GAME.scene.updateMatrixWorld(true);
    ray.setFromCamera(pointer, camera);
    var list = GAME.city.editableBuildings.filter(function (b) { return b.mesh && b.mesh.visible; }).map(function (b) { return b.mesh; });
    var hits = ray.intersectObjects(list, false);
    if (!hits.length) return null;
    for (var i=0;i<GAME.city.editableBuildings.length;i++) if (GAME.city.editableBuildings[i].mesh === hits[0].object) return GAME.city.editableBuildings[i];
    return null;
  }
  function canvasTap(e) {
    if (!active || e.button !== undefined && e.button !== 0) return;
    var canvas = GAME.renderer && GAME.renderer.domElement;
    if (!canvas) return;
    var rect = canvas.getBoundingClientRect();
    if (e.clientX < rect.left || e.clientX > rect.right || e.clientY < rect.top || e.clientY > rect.bottom) return;
    var rec = hit(e), now = Date.now();
    if (!rec) { lastHit = null; return; }
    if (rec === lastHit && now-lastAt < 850) { select(rec); lastHit = null; e.preventDefault(); }
    else { lastHit = rec; lastAt = now; status.textContent = 'Prédio ' + rec.id + ' identificado. Toque novamente para editar.'; }
  }
  function update() { var v=vals(); labels(v); if (selected) { apply(selected,v); dims[selected.id]=v; persistDims(); } }
  $('be-toggle').addEventListener('click', function () {
    active = !active; $('be-toggle').textContent = active ? 'DESATIVAR' : 'ATIVAR';
    status.textContent = active ? 'Editor ativo: dê dois toques no mesmo prédio. ' + GAME.city.editableBuildings.length + ' prédios disponíveis.' : 'Editor desativado.';
    if (!active) { selected=null; controls.hidden=true; }
  });
  ['be-width','be-length','be-height'].forEach(function(id) {
    $(id).addEventListener('input', update); $(id).addEventListener('change', update);
    $(id).addEventListener('pointerdown', function(e){e.stopPropagation();});
  });
  $('be-save').addEventListener('click', function () {
    if (!selected) return;
    var v=vals(); apply(selected,v); dims[selected.id]=v;
    if (!persistDims()) return;
    status.textContent='✓ ' + selected.id + ' salvo neste aparelho. A edição será restaurada ao reabrir o jogo.';
  });
  $('be-cancel').addEventListener('click', function () { if (!selected) return; var v=dims[selected.id] || {w:1,d:1,h:1}; show(v); apply(selected,v); status.textContent='Valores salvos restaurados.'; });
  $('be-reset').addEventListener('click', function () { if (!selected) return; var v={w:1,d:1,h:1}; delete dims[selected.id]; persistDims(); show(v);apply(selected,v);status.textContent='Dimensões originais restauradas para ' + selected.id + '.'; });
  $('be-close').addEventListener('click', function(e){e.preventDefault();e.stopPropagation();root.classList.remove('open');root.setAttribute('aria-hidden','true');active=false;$('be-toggle').textContent='ATIVAR';if(GAME.hud&&GAME.hud.setPaused)GAME.hud.setPaused(false);});
  $('pause-building-editor').addEventListener('click', function(e){e.preventDefault();e.stopPropagation();if(GAME.paused&&GAME.togglePause)GAME.togglePause();root.classList.add('open');root.setAttribute('aria-hidden','false');active=false;$('be-toggle').textContent='ATIVAR';controls.hidden=true;status.textContent='Ative o editor e dê dois toques no mesmo prédio.';});
  document.addEventListener('pointerup',canvasTap,true);
  // Persist edits even if the player leaves the editor or closes the page.
  window.addEventListener('pagehide', persistDims);
  document.addEventListener('visibilitychange', function(){ if (document.visibilityState === 'hidden') persistDims(); });
  // Apply each saved transform to its exact, coordinate-derived building ID.
  GAME.city.editableBuildings.forEach(function(rec){ if(dims[rec.id]) apply(rec,dims[rec.id]); });
})();

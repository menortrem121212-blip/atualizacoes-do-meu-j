// Cheats: every code the game knows, in a list to pick from.
//
// Typed straight into the game they would trip over the controls — half the
// alphabet already does something (P is the map, N the night, M the sound) —
// so they are a list of cards instead: on the pause screen, behind the `
// key, and on a touchscreen the joystick in the row beside the radar
// (touch.js). Picking one is the whole of it, with a mouse, a finger or a
// pad, and the list closes and the game carries on. On
// a keyboard, typing narrows the list, so the code words still work. And on
// a pad each one has a combo of eight presses that works in the middle of
// play, without opening anything.
//
// Most of them do a thing once. The rest switch a way the town works on,
// and picking one again switches it back off: what they switch is
// GAME.cheatOn (utils.js), read where each one bites — the cars' flight,
// paint and wheels and the traffic's manners in vehicles.js, the crowd's
// guns and tempers in peds.js and below. None of it is saved: a new visit
// starts with the town as it was.
GAME.cheats = (function () {
  var used = 0, off = false;
  function P() { return GAME.player; }
  function msg(t) { GAME.hud.message(t, 3); }
  // a switch: on, or (typed again) off, and whatever has to happen either way
  function toggle(key, onSaid, offSaid, then) {
    return function () {
      var on = GAME.cheatOn[key] = !GAME.cheatOn[key];
      off = !on;
      if (then) then(on);
      return on ? onSaid : offSaid;
    };
  }
  // one paint for every car on the street, or (typed again) their own back
  var PINK = 0xff5fae, BLACK = 0x141418;
  function paint(color, said) {
    return function () {
      var on = GAME.cheatOn.paint !== color;
      GAME.cheatOn.paint = on ? color : null;
      off = !on;
      GAME.vehicles.paintAll(GAME.cheatOn.paint);
      return on ? said : 'O trânsito volta às suas cores';
    };
  }
  // the whole game faster or slower, or (typed again) back to time
  function speed(k, said) {
    return function () {
      var on = GAME.gameSpeed !== k;
      GAME.gameSpeed = on ? k : 1;
      off = !on;
      return on ? said : 'Velocidade normal';
    };
  }
  // a sky, pinned — or, picked again with that sky already pinned, the
  // weather left to come and go on its own again (AUTO)
  function weather(mode, said) {
    return function () {
      var on = GAME.weather.mode !== mode;
      GAME.weather.setMode(on ? mode : 'auto');
      off = !on;
      return on ? said : 'O clima vai e volta de novo';
    };
  }
  // your build, or (typed again) your own
  function shape(kind, said) {
    return function () {
      var on = build !== kind;
      setBuild(on ? kind : null);
      off = !on;
      return on ? said : 'De volta ao seu velho eu';
    };
  }
  function arm(list) {
    list.forEach(function (w) { GAME.combat.giveWeapon(w[0], w[1]); });
    GAME.combat.selectWeapon(list[list.length - 1][0]);
  }
  // a vehicle of your own, beside you
  function ride(type) {
    var p = P(), f = GAME.focus(), h = p.inCar && p.car ? p.car.heading : p.heading;
    var x = f.x + Math.sin(h + Math.PI / 2) * 5, z = f.z + Math.cos(h + Math.PI / 2) * 5;
    if (GAME.city.isInWater(x, z)) { x = f.x + Math.sin(h) * 10; z = f.z + Math.cos(h) * 10; }
    return GAME.vehicles.spawnCar(type, x, z, h, {});
  }
  var CODES = {
    FLYMODE: toggle('freeFly', 'Voo livre e invisibilidade ativados', 'Voo livre desativado', function (on) {
      var pl = P();
      if (pl && pl.mesh) pl.mesh.visible = !on;
      if (!on && GAME.cam) GAME.cam.flightPitch = null;
    }),
    ASPIRINE: function () { P().health = 100; return 'Vida restaurada'; },
    PRECIOUSPROTECTION: function () { P().armor = 100; return 'Colete'; },
    THUGSTOOLS: function () { arm([['bat'], ['molotov', 10], ['pistol', 100], ['shotgun', 50], ['smg', 200], ['rifle', 50]]); return 'Armas — o kit do bandido'; },
    PROFESSIONALTOOLS: function () { arm([['knife'], ['grenade', 10], ['pistol', 100], ['shotgun', 50], ['smg', 200], ['rifle', 50], ['sniper', 30]]); return 'Armas — o kit do profissional'; },
    NUTTERTOOLS: function () { arm([['chainsaw'], ['grenade', 10], ['pistol', 100], ['shotgun', 50], ['smg', 200], ['sniper', 30], ['rocket', 10]]); return 'Armas — o kit do maluco'; },
    LEAVEMEALONE: function () { GAME.police.clearWanted(); return 'Nível de procurado zerado'; },
    YOUWONTTAKEMEALIVE: function () { GAME.police.setWanted(Math.min(GAME.police.MAX_STARS || 6, GAME.police.wanted + 2)); return 'Nível de procurado aumentou'; },
    PANZER: function () { return ride('tank') ? 'Tanque' : null; },
    GETTHEREFAST: function () { return ride('sports') ? 'Um carro rápido' : null; },
    GETTHEREAMAZINGLYFAST: function () { return ride('superbike') ? 'Uma moto muito rápida' : null; },
    ROCKANDROLLCAR: function () { return ride('limo') ? 'Limusine' : null; },
    RUBBISHCAR: function () { return ride('van') ? 'Uma van' : null; },
    BETTERTHANWALKING: function () { return ride('buggy') ? 'Um buggy' : null; },
    BIGBANG: function () {
      var f = GAME.focus(), n = 0;
      GAME.world.cars.slice().forEach(function (c) {
        if (c.dead || c === P().car || c.spec.heli || c.spec.plane || c.spec.boat) return;
        if (U.dist2(c.pos.x, c.pos.z, f.x, f.z) > 90 * 90) return;
        GAME.vehicles.explodeCar(c, 'fire', true); n++;
      });
      return n ? 'Tudo por perto explode' : 'Nada por perto para explodir';
    },
    ICANTTAKEITANYMORE: function () { if (GAME.godMode) return null; P().health = 0; GAME.playerWasted('cheat'); return 'Adeus, mundo cruel'; },
    ALOVELYDAY: weather('clear', 'Ensolarado'),
    APLEASANTDAY: weather('clear', 'Tempo bom'),
    ABITDRIEG: weather('overcast', 'Nublado'),
    CATSANDDOGS: weather('rain', 'Chuva'),
    CANTSEEATHING: weather('fog', 'Neblina'),
    LIFEISPASSINGMEBY: function () { GAME.dayPhase = (GAME.dayPhase + 0.25) % 1; return 'Seis horas depois'; },
    // ---- switches: typed again, each one is off ----
    COMEFLYWITHME: toggle('flyCars', 'Carros voam — pé na tábua para decolar', 'Carros ficam no chão'),
    SEAWAYS: toggle('seaWays', 'Carros andam na água', 'O mar está molhado de novo'),
    AIRSHIP: toggle('flyBoats', 'Barcos voam — acelere tudo para decolar', 'Barcos ficam na água'),
    WHEELSAREALLINEED: toggle('wheelsOnly', 'Só as rodas aparecem', 'A lataria voltou',
      function () { GAME.vehicles.dressAll(); }),
    LOADSOFLITTLETHINGS: toggle('bigWheels', 'Rodas gigantes', 'Rodas de volta ao tamanho',
      function () { GAME.vehicles.dressAll(); }),
    MIAMITRAFFIC: toggle('madTraffic', 'Trânsito agressivo', 'O trânsito se acalma'),
    AHAIRDRESSERSCAR: paint(PINK, 'Trânsito rosa'),
    IWANTITPAINTEDBLACK: paint(BLACK, 'Trânsito preto'),
    NOBODYLIKESME: toggle('hateYou', 'Todo mundo te odeia', 'A cidade te perdoa'),
    OURGODGIVENRIGHTTOBEARARMS: toggle('armed', 'Todo mundo armado', 'Armas guardadas',
      function (on) { if (on) scan(); else disarm(); }),
    FIGHTFIGHTFIGHT: toggle('riot', 'Tumulto!', 'O tumulto acabou'),
    HOPINGIRL: toggle('hopIn', 'Pessoas entram no seu carro', 'Chega de passageiros'),
    STILLLIKEDRESSINGUP: function () { return redress() ? 'Um visual novo' : null; },
    DEEPFRIEDMARSBARS: shape('fat', 'Você engordou'),
    PROGRAMMER: shape('thin', 'Magrelo'),
    ONSPEED: speed(1.5, 'Jogo mais rápido'),
    BOOOOOORING: speed(0.5, 'Câmera lenta')
  };
  // One cheat code for every vehicle in VEHICLES, not just the original six.
  Object.keys(VEHICLES).forEach(function (type) {
    CODES['SPAWN' + type.toUpperCase()] = function () {
      return ride(type) ? VEHICLES[type].label + ' criado ao seu lado' : null;
    };
  });

  CODES.MAYHEMTRAFFIC = CODES.MIAMITRAFFIC;   // the same, by its other name
  // Enter a code; what it did, or null for nothing
  function enter(text) {
    var code = String(text || '').toUpperCase().replace(/[^A-Z]/g, '');
    var fn = CODES[code];
    if (!fn || !GAME.started || P().state !== 'alive') return null;
    off = false;
    var said = fn();
    if (!said) return null;
    used++;
    GAME.prefs = GAME.prefs || {};
    GAME.prefs.cheats = (GAME.prefs.cheats || 0) + 1;
    GAME.audio.sting('win');
    msg((off ? 'TRAPAÇA DESLIGADA — ' : 'TRAPAÇA ATIVADA — ') + said);
    if (GAME.track) GAME.track('cheat-' + code.toLowerCase());
    return said;
  }

  // ---------- what you look like ----------
  // STILLLIKEDRESSINGUP: a shirt, trousers and a cut off the shops' own
  // racks, at random, and kept as if you had bought them
  function redress() {
    var W = GAME.shops && GAME.shops.wardrobe;
    if (!W || !GAME.prefs) return false;
    var o = GAME.prefs.outfit || (GAME.prefs.outfit = {});
    function other(list, now) {
      var pick = list[Math.floor(Math.random() * list.length)];
      for (var i = 0; i < 6 && pick.id === now; i++) pick = list[Math.floor(Math.random() * list.length)];
      return pick.id;
    }
    o.shirt = other(W.SHIRTS, o.shirt);
    o.pants = other(W.PANTS, o.pants);
    o.hairStyle = other(W.HAIRSTYLES, o.hairStyle);
    o.hairColor = other(W.HAIRCOLORS, o.hairColor);
    GAME.shops.applyOutfit();
    if (GAME.save) GAME.save();
    return true;
  }
  // DEEPFRIEDMARSBARS and PROGRAMMER: the same figure, built heavier or
  // slighter — the body and the limbs' thickness, never their length, so
  // every pose and every seat still fits
  var BUILDS = {
    normal: { torso: [1, 1, 1], arm: [1, 1], armX: 0.3, leg: [1, 1], legX: 0.13 },
    fat: { torso: [1.5, 1.04, 1.9], arm: [1.35, 1.35], armX: 0.42, leg: [1.45, 1.45], legX: 0.17 },
    thin: { torso: [0.7, 1, 0.72], arm: [0.55, 0.55], armX: 0.23, leg: [0.6, 0.6], legX: 0.1 }
  };
  var build = null;
  function setBuild(kind) {
    build = kind;
    var mesh = P().mesh, j = mesh && mesh.userData.joints;
    if (!j) return;
    var b = BUILDS[kind || 'normal'];
    j.torso.scale.set(b.torso[0], b.torso[1], b.torso[2]);
    j.armL.scale.set(b.arm[0], 1, b.arm[1]); j.armR.scale.set(b.arm[0], 1, b.arm[1]);
    j.armL.position.x = -b.armX; j.armR.position.x = b.armX;
    j.legL.scale.set(b.leg[0], 1, b.leg[1]); j.legR.scale.set(b.leg[0], 1, b.leg[1]);
    j.legL.position.x = -b.legX; j.legR.position.x = b.legX;
  }

  // ---------- the crowd ----------
  // Every half second: who is carrying (OURGODGIVENRIGHTTOBEARARMS), who
  // comes for you (NOBODYLIKESME), and who squares up to whoever is nearest
  // (FIGHTFIGHTFIGHT). Not the law, and not anybody a job has a part for.
  var scanT = 0;
  function armPed(p) {
    var ud = p.mesh.userData;
    if (ud.cheatGun) return;
    if (!p.carrying) { p.carrying = true; ud.cheatCarry = true; }
    // a pistol in the right hand, barrel down the arm: down by the side
    // walking, at the target when he draws (peds.js raises the arm)
    var gun = new THREE.Mesh(sharedBoxGeo(0.07, 0.26, 0.13), sharedLambert(0x1a1a20));
    gun.position.set(0, -0.68, 0.03);
    ud.joints.armR.add(gun);
    ud.cheatGun = gun;
  }
  function disarm() {
    GAME.world.peds.forEach(function (p) {
      var ud = p.mesh.userData;
      if (!ud.cheatGun) return;
      ud.joints.armR.remove(ud.cheatGun);
      ud.cheatGun = null;
      if (ud.cheatCarry) { p.carrying = undefined; ud.cheatCarry = false; }
    });
  }
  function about(p) {
    return !p.dead && !p.gone && !p.isCop && !p.jobPed && !p.boss && p.state !== 'inside' && p.state !== 'enter';
  }
  function scan() {
    var on = GAME.cheatOn, Pl = P(), f = GAME.focus(), peds = GAME.world.peds;
    for (var i = 0; i < peds.length; i++) {
      var p = peds[i];
      if (!about(p)) continue;
      if (on.armed) armPed(p);
      if (hop && hop.ped === p) continue;
      var calm = p.state === 'walk' || p.state === 'idle' || p.state === 'flee';
      var d2 = U.dist2(p.pos.x, p.pos.z, f.x, f.z);
      if (on.hateYou && calm && Pl.state === 'alive' && d2 < 32 * 32 && Math.abs(p.pos.y - f.y) < 3) {
        GAME.peds.startFight(p, { kind: 'player' }, 20);
        continue;
      }
      if (on.riot && (p.state === 'walk' || p.state === 'idle') && d2 < 90 * 90) {
        var best = null, bd = 25 * 25;
        for (var k = 0; k < peds.length; k++) {
          var q = peds[k];
          if (q === p || !about(q) || (hop && hop.ped === q) || Math.abs(q.pos.y - p.pos.y) > 2) continue;
          var e2 = U.dist2(p.pos.x, p.pos.z, q.pos.x, q.pos.z);
          // somebody not already in a fight first, if there is anybody
          if (q.state === 'attack') e2 += 400;
          if (e2 < bd) { bd = e2; best = q; }
        }
        if (best && GAME.peds.startFight(p, { kind: 'ped', ped: best }, 20) && best.state !== 'attack') {
          GAME.peds.startFight(best, { kind: 'ped', ped: p }, 20);
        }
      }
    }
  }

  // ---------- HOPINGIRL ----------
  // Pull up and stop, and somebody off the pavement walks over and gets in
  // beside you. They ride along until you next stop for a moment, and get
  // out there. One at a time, never on a job, never on two wheels or the
  // water or in the air.
  var hop = null, hopCd = 0;
  var HOP_IN = ['\"Se importa se eu pegar uma carona?\"', '\"Aonde você for está bom para mim.\"', '\"Pisa fundo, estou atrasado.\"', '\"Belo carro. Vamos nessa.\"'];
  var HOP_OUT = ['\"Aqui está ótimo. Valeu a carona!\"', '\"Mesmo horário amanhã?\"', '\"Você dirige igual à minha mãe.\"', '\"Nunca mais. Valeu, mas não.\"'];
  function seats(car) {
    var s = car.spec;
    return !s.bike && !s.boat && !s.heli && !s.plane && !s.rc && !s.tank && !car.dead;
  }
  function doorOf(car) {
    // the passenger's side: the other side from the one you get out of
    var side = car.heading + Math.PI / 2, step = car.spec.w / 2 + 0.9;
    return { x: car.pos.x + Math.sin(side) * step, z: car.pos.z + Math.cos(side) * step };
  }
  function stepHop(dt) {
    var Pl = P(), car = Pl.inCar ? Pl.car : null;
    hopCd -= dt;
    if (hop && hop.ped) {
      // on the way over: the car has to wait for them
      var ped = hop.ped, c = hop.car, door = doorOf(c);
      if (ped.dead || ped.gone || c !== car || c.dead || Math.abs(c.speed) > 2.5 || !GAME.cheatOn.hopIn || ped.state !== 'enter') {
        if (!ped.dead && !ped.gone && ped.state === 'enter') { ped.enterX = NaN; ped.state = 'walk'; ped.wpT = 0; }
        hop = null; hopCd = 4;
        return;
      }
      ped.enterX = door.x; ped.enterZ = door.z;
      if (U.dist2(ped.pos.x, ped.pos.z, door.x, door.z) < 2 * 2) {
        hop.look = ped.look;
        GAME.peds.removePed(ped);
        hop.ped = null; hop.t = 0; hop.stopT = 0;
        GAME.audio.pickup();
        GAME.hud.message(HOP_IN[Math.floor(Math.random() * HOP_IN.length)], 2.5);
      }
      return;
    }
    if (hop) {
      // aboard: out at the next stop, or when you get out yourself
      var cc = hop.car;
      hop.t += dt;
      hop.stopT = Math.abs(cc.speed) < 1 && !cc.air ? hop.stopT + dt : 0;
      var gone = cc !== car || cc.dead || cc.gone || cc.sinking;
      if (gone || (hop.t > 8 && hop.stopT > 1.2)) {
        var at = doorOf(cc);
        if (!cc.gone && !cc.sinking && !GAME.city.isInWater(at.x, at.z) && Math.abs(cc.pos.y - GAME.city.groundY(at.x, at.z, cc.pos.y)) < 2) {
          var out = GAME.peds.spawnPed(at.x, at.z, { look: hop.look });
          if (out) { out.heading = cc.heading - Math.PI / 2; out.wpT = 0; }
          if (!gone) GAME.hud.message(HOP_OUT[Math.floor(Math.random() * HOP_OUT.length)], 2.5);
        }
        hop = null; hopCd = 6;
      }
      return;
    }
    // somebody to come over
    if (!GAME.cheatOn.hopIn || hopCd > 0 || !car || !seats(car) || Math.abs(car.speed) > 1 || car.air || GAME.onJob()) return;
    var best = null, bd = 18 * 18, peds = GAME.world.peds;
    for (var i = 0; i < peds.length; i++) {
      var p = peds[i];
      if (!about(p) || (p.state !== 'walk' && p.state !== 'idle') || Math.abs(p.pos.y - car.pos.y) > 2) continue;
      var d2 = U.dist2(p.pos.x, p.pos.z, car.pos.x, car.pos.z);
      if (d2 < bd) { bd = d2; best = p; }
    }
    if (!best) { hopCd = 1; return; }
    var dd = doorOf(car);
    GAME.peds.walkInto(best, dd.x, dd.z, 12);
    hop = { car: car, ped: best, look: null, t: 0, stopT: 0 };
  }

  function update(dt) {
    var on = GAME.cheatOn;
    if (on.hateYou || on.armed || on.riot) {
      scanT -= dt;
      if (scanT <= 0) { scanT = 0.5; scan(); }
    }
    if (on.hopIn || hop) stepHop(dt);
  }

  // ---------- the list ----------
  // Every code as a card: what it is, what it does, its word and its combo
  // on a pad. `on` says whether a switch is on (a sky is one too: picked
  // again it goes back to AUTO).
  // A pad combo is eight presses of LB, RB, A, B and the D-pad's ↑ ← →
  // (the buttons that do least in play — never the triggers, X, Y or ↓),
  // no button three times running, each one different from the rest.
  function sw(key) { return function () { return !!GAME.cheatOn[key]; }; }
  function sky(m) { return function () { return GAME.weather.mode === m; }; }
  var GROUPS = [['flight', 'VOO LIVRE'], ['you', 'VOCÊ'], ['arms', 'ARMAS'], ['law', 'A LEI'], ['ride', 'ALGO PARA DIRIGIR'],
    ['cars', 'CARROS E BARCOS'], ['crowd', 'A MULTIDÃO'], ['sky', 'O CÉU E O RELÓGIO']];
  var CATALOG = [
    { code: 'FLYMODE', g: 'flight', icon: '🪽', name: 'Voo livre / Invisibilidade', what: 'Você fica invisível. Analógico esquerdo: move; analógico direito: olha em 360°. O voo segue a direção da câmera. PULAR sobe e CORRER desce.', pad: '', on: sw('freeFly') },
    { code: 'ASPIRINE', g: 'you', icon: '❤️', name: 'Vida', what: 'Vida cheia de novo.', pad: 'UP LEFT B A A RB UP RIGHT' },
    { code: 'PRECIOUSPROTECTION', g: 'you', icon: '🛡️', name: 'Colete', what: 'Um colete completo.', pad: 'LEFT B UP RIGHT LEFT B UP LB' },
    { code: 'STILLLIKEDRESSINGUP', g: 'you', icon: '👕', name: 'Visual novo', what: 'Uma roupa e um corte aleatórios das araras, para ficar.', pad: 'UP LEFT RIGHT UP RIGHT B RIGHT B' },
    { code: 'DEEPFRIEDMARSBARS', g: 'you', icon: '🍔', name: 'Gordo', what: 'Você engordou. Use de novo para voltar ao seu velho eu.', pad: 'A A UP UP RIGHT LB RB LEFT', on: function () { return build === 'fat'; } },
    { code: 'PROGRAMMER', g: 'you', icon: '💻', name: 'Magrelo', what: 'Magro como um palito. Use de novo para voltar ao seu velho eu.', pad: 'A UP UP RIGHT UP A LEFT RB', on: function () { return build === 'thin'; } },
    { code: 'ICANTTAKEITANYMORE', g: 'you', icon: '💀', name: 'Eliminado', what: 'Acaba com tudo, aqui e agora.', pad: 'RIGHT RIGHT LB B UP A RIGHT RB', grim: true },
    { code: 'THUGSTOOLS', g: 'arms', icon: '🏏', name: 'O kit do bandido', what: 'Taco, molotovs, pistola, espingarda, submetralhadora e fuzil.', pad: 'LEFT B UP A UP B UP B' },
    { code: 'PROFESSIONALTOOLS', g: 'arms', icon: '🔪', name: 'O kit do profissional', what: 'Faca, granadas, pistola, espingarda, submetralhadora, fuzil e fuzil de precisão.', pad: 'B A LB LB UP B UP LEFT' },
    { code: 'NUTTERTOOLS', g: 'arms', icon: '🚀', name: 'O kit do maluco', what: 'Motosserra, granadas, pistola, espingarda, submetralhadora, fuzil de precisão e foguetes.', pad: 'B RB B UP B RIGHT RIGHT LB' },
    { code: 'LEAVEMEALONE', g: 'law', icon: '😇', name: 'Some com as estrelas', what: 'Nível de procurado zerado.', pad: 'LB A LEFT RIGHT A A LB RB' },
    { code: 'YOUWONTTAKEMEALIVE', g: 'law', icon: '🚨', name: 'Mais duas estrelas', what: 'Nível de procurado aumentou em dois.', pad: 'LB A UP B A B LEFT RB' },
    { code: 'PANZER', g: 'ride', icon: '💣', name: 'Tanque', what: 'Um tanque ao seu lado.', pad: 'B LEFT B RIGHT RIGHT RB UP UP' },
    { code: 'GETTHEREFAST', g: 'ride', icon: '🏎️', name: 'Carro rápido', what: 'Um esportivo ao seu lado.', pad: 'RIGHT LEFT LB LB RB B LEFT A' },
    { code: 'GETTHEREAMAZINGLYFAST', g: 'ride', icon: '🏍️', name: 'Moto muito rápida', what: 'Uma superbike ao seu lado.', pad: 'LEFT UP RIGHT LEFT UP LB RIGHT RIGHT' },
    { code: 'ROCKANDROLLCAR', g: 'ride', icon: '🎸', name: 'Limusine', what: 'Uma limusine ao seu lado.', pad: 'LEFT LB B UP UP RIGHT LEFT UP' },
    { code: 'RUBBISHCAR', g: 'ride', icon: '🚐', name: 'Van', what: 'Uma van ao seu lado.', pad: 'B UP LB LEFT LEFT UP A RB' },
    { code: 'BETTERTHANWALKING', g: 'ride', icon: '🏖️', name: 'Buggy', what: 'Um buggy das dunas ao seu lado.', pad: 'LEFT RIGHT RB RB A LEFT RB LB' },
    { code: 'COMEFLYWITHME', g: 'cars', icon: '🛫', name: 'Carros voadores', what: 'Pise fundo acima de 70 km/h e decole; puxe para subir, empurre para mergulhar.', pad: 'RIGHT UP RIGHT B A RB A RB', on: sw('flyCars') },
    { code: 'SEAWAYS', g: 'cars', icon: '🌊', name: 'Carros na água', what: 'Ande pelo mar em vez de afundar.', pad: 'LEFT B RIGHT A LB UP LEFT LB', on: sw('seaWays') },
    { code: 'AIRSHIP', g: 'cars', icon: '🚤', name: 'Barcos voadores', what: 'Acelere tudo na água e o barco decola.', pad: 'LB LB RB LEFT LB LB RIGHT LEFT', on: sw('flyBoats') },
    { code: 'WHEELSAREALLINEED', g: 'cars', icon: '⭕', name: 'Só rodas', what: 'Todo carro reduzido às rodas.', pad: 'UP B B RIGHT RB RB B A', on: sw('wheelsOnly') },
    { code: 'LOADSOFLITTLETHINGS', g: 'cars', icon: '🚙', name: 'Rodas gigantes', what: 'Rodas quase duas vezes maiores.', pad: 'LB UP LB LEFT RB B RB RB', on: sw('bigWheels') },
    { code: 'AHAIRDRESSERSCAR', g: 'cars', icon: '💗', name: 'Trânsito rosa', what: 'Todo carro rosa.', pad: 'LB A RIGHT LB LB RIGHT A UP', on: function () { return GAME.cheatOn.paint === PINK; } },
    { code: 'IWANTITPAINTEDBLACK', g: 'cars', icon: '🖤', name: 'Trânsito preto', what: 'Todo carro preto.', pad: 'LEFT B UP B UP RIGHT RB UP', on: function () { return GAME.cheatOn.paint === BLACK; } },
    { code: 'MIAMITRAFFIC', also: 'MAYHEMTRAFFIC', g: 'cars', icon: '😤', name: 'Trânsito agressivo', what: 'Mais rápido, buzinando, desviando de tudo, sem frear para ninguém.', pad: 'B LB RB B RB UP LB LB', on: sw('madTraffic') },
    { code: 'BIGBANG', g: 'cars', icon: '💥', name: 'Big bang', what: 'Todo carro por perto explode.', pad: 'B RIGHT RIGHT A B LB LEFT RIGHT' },
    { code: 'NOBODYLIKESME', g: 'crowd', icon: '😠', name: 'Todo mundo te odeia', what: 'Todo mundo por perto vem para cima de você.', pad: 'A RB RIGHT LB LB LEFT A B', on: sw('hateYou') },
    { code: 'OURGODGIVENRIGHTTOBEARARMS', g: 'crowd', icon: '🔫', name: 'Todo mundo armado', what: 'Uma pistola em cada mão.', pad: 'LEFT LB A RIGHT RIGHT LEFT B B', on: sw('armed') },
    { code: 'FIGHTFIGHTFIGHT', g: 'crowd', icon: '👊', name: 'Tumulto', what: 'Todo mundo parte para cima de quem estiver mais perto.', pad: 'RIGHT B RB UP LEFT LEFT LB UP', on: sw('riot') },
    { code: 'HOPINGIRL', g: 'crowd', icon: '🚕', name: 'Caronas', what: 'Pare, e alguém vem andando e entra.', pad: 'A LEFT RIGHT LB LEFT A B UP', on: sw('hopIn') },
    { code: 'ALOVELYDAY', g: 'sky', icon: '☀️', name: 'Ensolarado', what: 'Céu limpo.', pad: 'RIGHT UP UP A RB RIGHT B RIGHT', on: sky('clear') },
    { code: 'APLEASANTDAY', g: 'sky', icon: '🌤️', name: 'Tempo bom', what: 'Céu limpo.', pad: 'RIGHT LEFT RB B UP RB RB UP', on: sky('clear') },
    { code: 'ABITDRIEG', g: 'sky', icon: '☁️', name: 'Nublado', what: 'Uma tampa cinza de nuvens, sem chuva.', pad: 'UP LB B A A RIGHT LB LB', on: sky('overcast') },
    { code: 'CATSANDDOGS', g: 'sky', icon: '🌧️', name: 'Chuva', what: 'Um toró.', pad: 'A UP LEFT A LEFT A A RB', on: sky('rain') },
    { code: 'CANTSEEATHING', g: 'sky', icon: '🌫️', name: 'Neblina', what: 'Um banco de neblina entra vindo do mar.', pad: 'UP RIGHT UP LB A RB A LB', on: sky('fog') },
    { code: 'LIFEISPASSINGMEBY', g: 'sky', icon: '🕒', name: 'Seis horas depois', what: 'O relógio avança um quarto de dia.', pad: 'RIGHT LB RIGHT RB LEFT B A B' },
    { code: 'ONSPEED', g: 'sky', icon: '⏩', name: 'Jogo rápido', what: 'Tudo uma vez e meia mais rápido.', pad: 'LEFT RIGHT UP A RB LEFT UP A', on: function () { return GAME.gameSpeed === 1.5; } },
    { code: 'BOOOOOORING', g: 'sky', icon: '🐢', name: 'Câmera lenta', what: 'Tudo na metade da velocidade.', pad: 'RIGHT RB RB LB RIGHT UP LEFT RIGHT', on: function () { return GAME.gameSpeed === 0.5; } }
  ];

  // Spawn every vehicle defined by the game, including showroom and special vehicles.
  // These are selectable from the cheat menu without needing to buy or unlock them.
  Object.keys(VEHICLES).forEach(function (type) {
    var spec = VEHICLES[type];
    CATALOG.push({
      code: 'SPAWN' + type.toUpperCase(),
      g: 'ride',
      icon: spec.plane ? '✈️' : spec.heli ? '🚁' : spec.boat ? (spec.jetski ? '🛟' : '🚤') :
        spec.bike ? '🏍️' : spec.tank ? '🛡️' : '🚗',
      name: spec.label,
      isNew: type === 'carconcept',
      what: 'Criar este veículo ao seu lado, gratuitamente.',
      pad: ''
    });
  });

  var PAD_GLYPH = { A: 'Ⓐ', B: 'Ⓑ', LB: 'LB', RB: 'RB', UP: '↑', LEFT: '←', RIGHT: '→' };
  function padText(combo) { return combo.split(' ').map(function (t) { return PAD_GLYPH[t]; }).join(' '); }

  // ---------- combos on a pad, in play ----------
  // controls.js hands over every button pressed while no menu is up; the
  // last eight, close enough together, are looked up. Anything else pressed
  // in between (a trigger, X, Y) neither counts nor breaks the run.
  var PAD_TOKEN = { 0: 'A', 1: 'B', 4: 'LB', 5: 'RB', 12: 'UP', 14: 'LEFT', 15: 'RIGHT' };
  var BY_COMBO = {}, presses = [], lastPress = -1e9, COMBO_GAP = 1.5;
  CATALOG.forEach(function (c) { BY_COMBO[c.pad] = c.code; });
  function padPress(b) {
    var t = PAD_TOKEN[b];
    if (!t) return null;
    var now = performance.now() / 1000;
    if (now - lastPress > COMBO_GAP) presses.length = 0;
    lastPress = now;
    presses.push(t);
    if (presses.length > 8) presses.shift();
    var code = presses.length === 8 ? BY_COMBO[presses.join(' ')] : null;
    if (!code) return null;
    presses.length = 0;
    return enter(code);
  }

  // ---------- the box ----------
  function $(id) { return document.getElementById(id); }
  var cards = [], shown = [], sel = 0, find = '', fromPause = false;
  function makeList() {
    var list = $('cheat-list');
    if (!list || cards.length) return;
    GROUPS.forEach(function (gr) {
      // Veículos ficam exclusivamente no seletor atualizado; não duplicar
      // comandos antigos de carros, motos, barcos ou puxar veículos no menu.
      if (gr[0] === 'ride' || gr[0] === 'cars') return;
      var sec = document.createElement('div');
      sec.className = 'cgroup';
      sec.innerHTML = '<h4>' + gr[1] + '</h4><div class="cgrid"></div>';
      var grid = sec.lastChild;
      CATALOG.forEach(function (c) {
        if (c.g !== gr[0] || c.code.indexOf('SPAWN') === 0) return;
        var el = document.createElement('div');
        el.className = 'ccard' + (c.grim ? ' grim' : '') + (c.isNew ? ' is-new' : '');
        el.innerHTML = '<div class="ci">' + c.icon + '</div><div class="cb"><div class="cn">' + c.name + (c.isNew ? '<span class="cnew">NOVO</span>' : '') + '</div>' +
          '<div class="cw">' + c.what + '</div><div class="cc">' + c.code + (c.also ? ' · ' + c.also : '') + '</div>' +
          (c.pad ? '<div class="cp">🎮 ' + padText(c.pad) + '</div>' : '') + '</div><div class="con">ON</div>';
        el.addEventListener('click', function (e) { e.stopPropagation(); pick(c.code); });
        grid.appendChild(el);
        cards.push({ c: c, el: el, sec: sec });
      });
      list.appendChild(sec);
    });
    var edit = document.createElement('button');
    edit.type = 'button';
    edit.textContent = '⚙️  Edit 1 pessoa';
    edit.style.cssText = 'display:block;width:100%;margin:18px 0 8px;padding:16px;border:1px solid #8ca7ce;border-radius:12px;background:#26364d;color:#fff;font-weight:800;font-size:16px';
    edit.addEventListener('click', function(e) { e.stopPropagation(); openFirstPersonEditor(); });
    list.appendChild(edit);
    var pull = document.createElement('button');
    pull.type = 'button';
    pull.textContent = '🚘  PUXAR VEÍCULOS';
    pull.style.cssText = 'display:block;width:100%;margin:8px 0 18px;padding:16px;border:1px solid #57c7ff;border-radius:12px;background:#12334a;color:#fff;font-weight:900;font-size:16px';
    pull.addEventListener('click', function(e) { e.stopPropagation(); openVehiclePicker(); });
    list.appendChild(pull);
  }

  // Full-screen vehicle picker: one live 3D vehicle is shown in front of the
  // player at a time. Previous previews are removed, and the chosen vehicle
  // remains in the world when the picker closes.
  var vehiclePicker = null, pickerTypes = [], pickerIndex = 0, pickerCar = null;
  function buildVehiclePicker() {
    if (vehiclePicker) return vehiclePicker;
    vehiclePicker = document.createElement('div');
    vehiclePicker.id = 'vehicle-picker-live';
    vehiclePicker.style.cssText = 'position:fixed;inset:0;z-index:10060;display:none;align-items:center;justify-content:center;padding:8px;box-sizing:border-box;background:rgba(0,0,0,.03);font:800 14px system-ui;color:white;pointer-events:auto;touch-action:none';
    vehiclePicker.innerHTML = '<div id="vp-panel" style="width:min(520px,100%);padding:10px;border:1px solid rgba(101,207,255,.55);border-radius:16px;background:rgba(8,17,29,.22);text-align:center;box-shadow:0 4px 16px #0003;backdrop-filter:blur(2px);touch-action:none">' +
      '<div data-vp-drag="1" style="font-size:19px;margin-bottom:5px;padding:4px;cursor:move;touch-action:none">☷ 🚘 PUXAR VEÍCULOS (MOVER)</div><div id="vp-name" style="font-size:16px;color:#8de0ff">Veículo</div><div id="vp-count" style="margin:6px;color:#d4e6f4">1/1</div>' +
      '<div style="display:grid;grid-template-columns:1fr 1fr;gap:9px;margin-top:10px"><button id="vp-prev" style="padding:13px;border:1px solid #ffffff55;border-radius:10px;background:#17253655;color:white;font-weight:900">◀ ANTERIOR</button><button id="vp-next" style="padding:13px;border:1px solid #ffffff55;border-radius:10px;background:#17253655;color:white;font-weight:900">PRÓXIMO ▶</button></div>' +
      '<button id="vp-use" style="width:100%;padding:14px;margin-top:9px;border:1px solid #3ce0a0;border-radius:10px;background:#126346;color:white;font-weight:900">ESCOLHER ESTE VEÍCULO</button>' +
      '<button id="vp-close" style="width:100%;padding:10px;margin-top:7px;border:1px solid #ffffff44;border-radius:10px;background:#37425255;color:white;font-weight:800">FECHAR</button></div>';
    document.body.appendChild(vehiclePicker);
    (function enablePickerDrag(){
      var panel=vehiclePicker.querySelector('#vp-panel'), handle=vehiclePicker.querySelector('[data-vp-drag]');
      var sizeRow=document.createElement('div'); sizeRow.style.cssText='display:flex;align-items:center;gap:8px;margin:4px 0 8px;padding:3px 6px;background:rgba(0,0,0,.12);border-radius:8px';
      sizeRow.innerHTML='<span style="white-space:nowrap;font-size:11px">TAMANHO</span><input aria-label="Tamanho do menu puxar veículos" type="range" min="70" max="140" value="100" step="5" style="width:100%;min-width:70px;touch-action:pan-x"><output style="min-width:35px;font-size:11px">100%</output>';
      handle.after(sizeRow); var sizeInput=sizeRow.querySelector('input'), sizeOut=sizeRow.querySelector('output');
      sizeInput.addEventListener('pointerdown',function(e){e.stopPropagation();}); sizeInput.addEventListener('input',function(){var v=Number(sizeInput.value);panel.style.zoom=(v/100);sizeOut.textContent=v+'%';});
      var drag=null;
      handle.addEventListener('pointerdown',function(e){ if(e.target.closest('button,input')) return; var r=panel.getBoundingClientRect(); drag={x:e.clientX,y:e.clientY,left:r.left,top:r.top}; panel.style.position='fixed'; panel.style.margin='0'; panel.style.left=r.left+'px'; panel.style.top=r.top+'px'; panel.style.width=r.width+'px'; panel.style.transform='none'; handle.setPointerCapture(e.pointerId); e.preventDefault(); });
      handle.addEventListener('pointermove',function(e){if(!drag)return; var x=Math.max(0,Math.min(innerWidth-panel.offsetWidth,drag.left+e.clientX-drag.x)); var y=Math.max(0,Math.min(innerHeight-panel.offsetHeight,drag.top+e.clientY-drag.y)); panel.style.left=x+'px';panel.style.top=y+'px';});
      function end(){drag=null;} handle.addEventListener('pointerup',end);handle.addEventListener('pointercancel',end);
      panel.querySelectorAll('button').forEach(function(b){b.style.backgroundColor='rgba(20,38,55,.38)';b.style.backdropFilter='blur(1px)';});
    })();
    vehiclePicker.querySelector('#vp-prev').addEventListener('click', function(){ showVehicleAt(pickerIndex - 1); });
    vehiclePicker.querySelector('#vp-next').addEventListener('click', function(){ showVehicleAt(pickerIndex + 1); });
    vehiclePicker.querySelector('#vp-use').addEventListener('click', function(){
      if (pickerCar) { pickerCar._vehiclePickerChosen = true; pickerCar = null; }
      vehiclePicker.style.display = 'none';
    });
    vehiclePicker.querySelector('#vp-close').addEventListener('click', closeVehiclePicker);
    return vehiclePicker;
  }
  function removePickerCar() {
    if (pickerCar && GAME.vehicles && GAME.vehicles.removeCar) {
      try { GAME.vehicles.removeCar(pickerCar); } catch (_) {}
    }
    pickerCar = null;
  }
  function showVehicleAt(index) {
    if (!pickerTypes.length) return;
    pickerIndex = (index + pickerTypes.length) % pickerTypes.length;
    removePickerCar();
    var entry = pickerTypes[pickerIndex], type = entry.type, p = P(), f = GAME.focus();
    var h = p.inCar && p.car ? p.car.heading : p.heading;
    // Put the preview directly in front of the player, aligned with the
    // player's forward heading (the old +PI/2 offset placed it at the side).
    // Keep a moderate distance so the full vehicle stays inside the camera view.
    var distance = 6;
    var x = f.x + Math.sin(h) * distance;
    var z = f.z + Math.cos(h) * distance;
    if (GAME.city.isInWater(x,z)) {
      distance = 4.5;
      x = f.x + Math.sin(h) * distance;
      z = f.z + Math.cos(h) * distance;
    }
    // Keep the vehicle in front of the player, but rotate its heading by 90° so the camera sees its SIDE, not its rear/front.
    var sideHeading = h + Math.PI / 2;
    try { pickerCar = GAME.vehicles.spawnCar(type, x, z, sideHeading, { noTownModel: true }); } catch (_) { pickerCar = null; }
    if (pickerCar && entry.format === 'glb' && GAME.townVehicles) GAME.townVehicles.setModel(pickerCar, entry.file);
    if (pickerCar && entry.format === 'native') pickerCar._nativeVehicleId = entry.id;
    vehiclePicker.querySelector('#vp-name').textContent = 'ID ' + entry.id + ' · ' + entry.name;
    vehiclePicker.querySelector('#vp-count').textContent = (pickerIndex + 1) + '/' + pickerTypes.length;
  }
  function openVehiclePicker() {
    close(true);
    buildVehiclePicker();
    // Catálogo unificado: IDs 1–24 são os arquivos GLB; IDs seguintes são
    // todos os tipos nativos. A lista não depende da ordem de carregamento assíncrono.
    pickerTypes = [];
    if (GAME.townVehicles && GAME.townVehicles.list) GAME.townVehicles.list().forEach(function(m){
      pickerTypes.push({id:m.id, name:m.name, type:m.type, format:'glb', file:m.file});
    });
    Object.keys(VEHICLES).forEach(function(t, i){
      var spec=VEHICLES[t]; if(!spec) return;
      pickerTypes.push({id:25+i, name:spec.label||t, type:t, format:'native'});
    });
    pickerTypes.sort(function(a,b){return a.id-b.id;});
    if (!pickerTypes.length) return;
    vehiclePicker.style.display = 'flex';
    showVehicleAt(0);
  }
  function closeVehiclePicker() {
    if (vehiclePicker) vehiclePicker.style.display = 'none';
    // If closed without choosing, clean up the temporary preview.
    removePickerCar();
  }

  function openFirstPersonEditor() {
    var panel = document.getElementById('fp-edit-panel');
    if (!panel) {
      panel = document.createElement('div');
      panel.id = 'fp-edit-panel';
      panel.style.cssText = 'position:fixed;left:12px;top:90px;z-index:10050;width:208px;max-width:calc(100vw - 24px);display:none;background:rgba(18,23,32,.94);color:#fff;border:1px solid #71809a;border-radius:13px;padding:9px;font:600 13px system-ui;box-shadow:0 8px 28px #0009;touch-action:none;user-select:none;-webkit-user-select:none';
      panel.innerHTML =
        '<div data-fp-drag="1" style="display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:8px;padding:3px 2px 8px;border-bottom:1px solid #566174;cursor:move;touch-action:none">' +
          '<strong style="font-size:13px;pointer-events:none">☷ Editar câmera</strong>' +
          '<button type="button" data-fp="close" style="padding:5px 8px;border:0;border-radius:7px;background:#39465b;color:#fff;font-weight:800">✕</button>' +
        '</div>' +
        '<div style="display:grid;grid-template-columns:1fr 1fr;gap:6px">' +
          '<button type="button" data-fp="up" style="padding:10px 4px;border:0;border-radius:8px;font-weight:800">＋ Cima</button>' +
          '<button type="button" data-fp="down" style="padding:10px 4px;border:0;border-radius:8px;font-weight:800">－ Baixo</button>' +
          '<button type="button" data-fp="left" style="padding:10px 4px;border:0;border-radius:8px;font-weight:800">← Esquerda</button>' +
          '<button type="button" data-fp="right" style="padding:10px 4px;border:0;border-radius:8px;font-weight:800">→ Direita</button>' +
          '<button type="button" data-fp="reset" style="grid-column:1 / -1;padding:8px 4px;border:0;border-radius:8px;background:#39465b;color:#fff;font-weight:800">Centralizar</button>' +
        '</div>' +
        '<div style="margin-top:12px;padding-top:10px;border-top:1px solid #566174">' +
          '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px"><strong>Zoom 1ª pessoa</strong><output data-fp-value>0</output></div>' +
          '<input data-fp-zoom type="range" min="-100" max="100" step="1" value="0" aria-label="Zoom da câmera" style="display:block;width:100%;height:34px;margin:4px 0;accent-color:#70c8ff;touch-action:pan-y;pointer-events:auto;cursor:ew-resize;position:relative;z-index:2">' +
          '<div style="display:flex;justify-content:space-between;font-size:11px;color:#c3ccda"><span>← trás</span><span>0</span><span>frente →</span></div>' +
        '</div>';
      document.body.appendChild(panel);
      var zoomSlider = panel.querySelector('[data-fp-zoom]');
      var zoomValue = panel.querySelector('[data-fp-value]');
      function applyCameraZoom() {
        var value = Number(zoomSlider.value) || 0;
        // Relative offset on top of the pinch zoom (cam.zoom, untouched here);
        // 0 keeps the current framing exactly. Positive = forward, negative = back.
        GAME.cam.fpZoom = value * 0.02;   // metres along the view: +100 = 2 m forward, -100 = 2 m back
        zoomValue.textContent = value > 0 ? '+' + value : String(value);
      }
      // Do not let the world/touch joystick consume range input gestures.
      ['pointerdown','pointermove','pointerup','pointercancel','touchstart','touchmove','touchend','mousedown','click'].forEach(function(type) {
        zoomSlider.addEventListener(type, function(e) { e.stopPropagation(); }, { passive: type.indexOf('touch') === 0 });
      });
      zoomSlider.addEventListener('input', applyCameraZoom);
      zoomSlider.addEventListener('change', applyCameraZoom);
      // Explicit pointer mapping makes the range reliable on Android WebViews
      // that otherwise route a drag to the game's virtual joystick.
      var zoomDragging = false;
      function setZoomFromPointer(e) {
        var r = zoomSlider.getBoundingClientRect();
        var t = U.clamp((e.clientX - r.left) / Math.max(1, r.width), 0, 1);
        zoomSlider.value = String(Math.round(-100 + t * 200));
        applyCameraZoom();
      }
      zoomSlider.addEventListener('pointerdown', function(e) {
        zoomDragging = true;
        if (zoomSlider.setPointerCapture) zoomSlider.setPointerCapture(e.pointerId);
        setZoomFromPointer(e);
        e.preventDefault();
      });
      zoomSlider.addEventListener('pointermove', function(e) {
        if (!zoomDragging) return;
        setZoomFromPointer(e);
        e.preventDefault();
      });
      function endZoomDrag() { zoomDragging = false; }
      zoomSlider.addEventListener('pointerup', endZoomDrag);
      zoomSlider.addEventListener('pointercancel', endZoomDrag);
      panel.addEventListener('click', function(e) {
        var btn = e.target && e.target.closest ? e.target.closest('[data-fp]') : null;
        if (!btn) return;
        var action = btn.getAttribute('data-fp');
        var cam = GAME.cam;
        var step = 0.12;
        if (action === 'up') cam.fpEditY = U.clamp((cam.fpEditY || 0) + step, -1.5, 1.5);
        else if (action === 'down') cam.fpEditY = U.clamp((cam.fpEditY || 0) - step, -1.5, 1.5);
        else if (action === 'left') cam.fpEditX = U.clamp((cam.fpEditX || 0) + step, -1.5, 1.5);
        else if (action === 'right') cam.fpEditX = U.clamp((cam.fpEditX || 0) - step, -1.5, 1.5);
        else if (action === 'reset') { cam.fpEditX = 0; cam.fpEditY = 0; }
        else if (action === 'close') { panel.style.display = 'none'; return; }
      });
      // Drag only by the title strip, so the adjustment buttons remain easy to tap.
      var fpSizeRow=document.createElement('div'); fpSizeRow.style.cssText='display:flex;align-items:center;gap:7px;margin:0 0 8px;padding:3px 5px;background:rgba(0,0,0,.12);border-radius:7px'; fpSizeRow.innerHTML='<span style="font-size:10px;white-space:nowrap">TAMANHO</span><input aria-label="Tamanho do menu flutuante" type="range" min="70" max="140" value="100" step="5" style="width:100%;min-width:60px;touch-action:pan-x"><output style="font-size:10px;min-width:32px">100%</output>'; panel.querySelector('[data-fp-drag]').after(fpSizeRow); var fpSize=fpSizeRow.querySelector('input'),fpOut=fpSizeRow.querySelector('output'); fpSize.addEventListener('pointerdown',function(e){e.stopPropagation();}); fpSize.addEventListener('input',function(){var v=Number(fpSize.value);panel.style.zoom=v/100;fpOut.textContent=v+'%';});
      var drag = panel.querySelector('[data-fp-drag]'), moving = false, sx = 0, sy = 0, ox = 0, oy = 0;
      drag.addEventListener('pointerdown', function(e) {
        if (e.target && e.target.closest && e.target.closest('button')) return;
        moving = true; sx = e.clientX; sy = e.clientY;
        var r = panel.getBoundingClientRect(); ox = r.left; oy = r.top;
        if (drag.setPointerCapture) drag.setPointerCapture(e.pointerId);
        e.preventDefault();
      });
      drag.addEventListener('pointermove', function(e) {
        if (!moving) return;
        var maxX = Math.max(0, window.innerWidth - panel.offsetWidth);
        var maxY = Math.max(0, window.innerHeight - panel.offsetHeight);
        panel.style.left = U.clamp(ox + e.clientX - sx, 0, maxX) + 'px';
        panel.style.top = U.clamp(oy + e.clientY - sy, 0, maxY) + 'px';
      });
      function stopDrag() { moving = false; }
      drag.addEventListener('pointerup', stopDrag);
      drag.addEventListener('pointercancel', stopDrag);
    }
    // Close the cheat screen and unpause before showing the editor over the live game.
    close(true);
    panel.style.display = 'block';
  }
  function words(c) { return c.code + ' ' + (c.also || '') + ' ' + c.name.toUpperCase().replace(/[^A-Z]/g, ''); }
  function refilter() {
    shown = [];
    cards.forEach(function (k) {
      var hit = !find || words(k.c).indexOf(find) >= 0;
      k.el.classList.toggle('hide', !hit);
      if (hit) shown.push(k);
    });
    Array.prototype.forEach.call($('cheat-list').querySelectorAll('.cgroup'), function (sec) {
      sec.classList.toggle('hide', !shown.some(function (k) { return k.sec === sec; }));
    });
    $('cheat-find').textContent = find ? 'BUSCAR: ' + find + (shown.length ? '' : ' — não existe código assim') : '';
    sel = 0;
    paintSel();
  }
  function paintSel() {
    cards.forEach(function (k) { k.el.classList.remove('sel'); });
    var k = shown[sel];
    if (!k) return;
    k.el.classList.add('sel');
    if (k.el.scrollIntoView) k.el.scrollIntoView({ block: 'nearest' });
  }
  function paintOn() { cards.forEach(function (k) { k.el.classList.toggle('on', !!(k.c.on && k.c.on())); }); }
  // round the cards by where they stand: left and right through the list,
  // up and down to the card nearest above or below
  function move(dir) {
    if (!shown.length) return;
    if (dir === 'ArrowLeft') sel = Math.max(0, sel - 1);
    else if (dir === 'ArrowRight') sel = Math.min(shown.length - 1, sel + 1);
    else {
      var down = dir === 'ArrowDown', cur = shown[sel].el.getBoundingClientRect(), best = -1, bd = Infinity;
      for (var i = 0; i < shown.length; i++) {
        var r = shown[i].el.getBoundingClientRect(), dy = down ? r.top - cur.top : cur.top - r.top;
        if (dy < 4) continue;
        var score = dy * 1000 + Math.abs(r.left - cur.left);
        if (score < bd) { bd = score; best = i; }
      }
      if (best >= 0) sel = best;
    }
    paintSel();
  }
  function onPad() { return !!(GAME.controls && GAME.controls.usingPad && GAME.controls.usingPad()); }
  function keyLabel() { return GAME.controls ? GAME.controls.label('Backquote') : '`'; }
  function open() {
    if (GAME.cheatOpen || !GAME.started || P().state !== 'alive') return false;
    if (GAME.mapOpen || GAME.shopOpen || GAME.shareOpen || GAME.lolaOpen || GAME.sceneOpen) return false;
    if (GAME.hud.dialogOpen && GAME.hud.dialogOpen()) return false;
    var box = $('cheat-box');
    if (!box) return false;
    makeList();
    // the game holds still under it: it is the pause screen, out of sight
    fromPause = !!GAME.paused;
    if (!GAME.paused) GAME.togglePause();
    document.body.classList.add('cheats-up');
    GAME.cheatOpen = true;
    box.style.display = 'flex';
    $('cheat-sub').textContent = 'Escolha um e ele funciona na hora. Um interruptor mostra ON: escolha de novo para desligar.';
    $('cheat-keys').textContent = GAME.isTouch ? 'Toque em um para usar.'
      : onPad() ? 'D-pad para escolher · Ⓐ usar · Ⓑ voltar. Durante o jogo, o combo 🎮 de uma trapaça funciona sozinho.'
        : 'Clique em um, ou setas e Enter · digite para buscar · Esc fecha · ' + keyLabel() + ' abre isto durante o jogo';
    find = '';
    paintOn();
    refilter();
    $('cheat-list').scrollTop = 0;
    if (GAME.track) GAME.track('cheats-opened');
    return true;
  }
  // Away, and back to the game — or, opened from the pause screen and left
  // without picking anything, back to the pause screen
  function close(resume) {
    if (!GAME.cheatOpen) return;
    GAME.cheatOpen = false;
    $('cheat-box').style.display = 'none';
    document.body.classList.remove('cheats-up');
    if ((resume || !fromPause) && GAME.paused) GAME.togglePause();
  }
  function pick(code) {
    if (!GAME.cheatOpen) return null;
    var said = enter(code);
    close(true);
    if (!said) msg('Agora não.');
    return said;
  }
  // the keyboard, straight from the keys (utils.js): typed letters narrow
  // the list, the arrows walk it, Enter picks
  function keyEvent(e) {
    var c = e.code;
    if (c === 'Escape') { if (find) { find = ''; refilter(); } else close(false); return; }
    if (GAME.controls && GAME.controls.map(c) === 'Backquote') { close(false); return; }
    if (c === 'Enter' || c === 'NumpadEnter' || c === 'Space') { if (shown[sel]) pick(shown[sel].c.code); return; }
    if (c === 'Backspace') { find = find.slice(0, -1); refilter(); return; }
    if (/^Arrow/.test(c)) { move(c); return; }
    if (/^Key[A-Z]$/.test(c) && !e.ctrlKey && !e.metaKey && !e.altKey && find.length < 32) { find += c.slice(3); refilter(); }
  }
  // a pad's buttons, as the menu keys they stand for (controls.js)
  function padKey(code) {
    if (code === 'Escape') close(false);
    else if (code === 'Enter') { if (shown[sel]) pick(shown[sel].c.code); }
    else if (/^Arrow/.test(code)) move(code);
  }
  function init() {
    var box = $('cheat-box');
    if (!box) return;
    // a click on the dark round the card is a way out, as Esc is
    box.addEventListener('click', function (e) { if (e.target === box) close(false); });
    $('cheat-card').addEventListener('click', function (e) { e.stopPropagation(); });
    $('cheat-close').addEventListener('click', function (e) { e.stopPropagation(); close(false); });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();

  return {
    enter: enter,
    open: open,
    close: close,
    update: update,
    keyEvent: keyEvent,
    padKey: padKey,
    padPress: padPress,
    get isOpen() { return !!GAME.cheatOpen; },
    // the list as it stands: every card's code, and which are showing,
    // picked out and on
    catalog: function () { return CATALOG.map(function (c) { return { code: c.code, also: c.also || null, name: c.name, group: c.g, pad: c.pad }; }); },
    shown: function () { return shown.map(function (k) { return k.c.code; }); },
    get selected() { return shown[sel] ? shown[sel].c.code : null; },
    onCodes: function () { return cards.filter(function (k) { return k.el.classList.contains('on'); }).map(function (k) { return k.c.code; }); },
    pick: pick,
    get used() { return used; },
    codes: function () { return Object.keys(CODES); },
    // what is switched on, by name (and the build and the clock)
    active: function () {
      var on = GAME.cheatOn, out = Object.keys(on).filter(function (k) { return on[k] !== false && on[k] !== null; });
      if (build) out.push(build);
      if (GAME.gameSpeed !== 1) out.push('speed');
      return out;
    },
    get build() { return build; },
    get passenger() { return hop ? { aboard: !hop.ped, ped: hop.ped, car: hop.car, look: hop.look } : null; },
    // headless: every switch off, every look back
    testReset: function () {
      Object.keys(GAME.cheatOn).forEach(function (k) { GAME.cheatOn[k] = k === 'paint' ? null : false; });
      GAME.vehicles.paintAll(null);
      GAME.vehicles.dressAll();
      disarm();
      setBuild(null);
      GAME.gameSpeed = 1;
      if (hop && hop.ped && !hop.ped.gone) { hop.ped.enterX = NaN; hop.ped.state = 'walk'; }
      hop = null; hopCd = 0;
      presses.length = 0;
    }
  };
})();

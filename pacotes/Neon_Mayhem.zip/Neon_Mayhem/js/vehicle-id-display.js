/* Live vehicle labels: compact ID + model name, toggled from Game Settings. */
(function () {
  'use strict';
  var button = document.getElementById('pause-show-vehicle-ids');
  if (!button || !window.THREE) return;
  var enabled = false, layer = document.createElement('div');
  layer.id = 'vehicle-id-label-layer';
  layer.style.cssText = 'position:fixed;inset:0;z-index:55;pointer-events:none;overflow:hidden;display:none;';
  document.body.appendChild(layer);
  var labels = new Map();
  var names = {
    1:'Red Wedge',2:'Monster Truck',3:'Ice Cream Truck',4:'Open-Wheel Racer',
    5:'Garbage Truck',6:'Camper RV',7:'Speedboat',8:'Pickup Truck',
    9:'Tow Truck',10:'Family SUV',11:'Golf Cart',12:'Minivan',
    13:'Dirt Bike',14:'Go-Kart',15:'Motor Scooter',16:'Convertible',
    17:'Armored Van',18:'Hatchback',19:'Rescue Helicopter',20:'Family Sedan',
    21:'Delivery Van',22:'Limousine',23:'Mini EV',24:'Delivery Scooter'
  };
  button.addEventListener('click', function (e) {
    e.preventDefault(); e.stopPropagation(); enabled = !enabled;
    layer.style.display = enabled ? 'block' : 'none';
    button.textContent = '🏷️ MOSTRAR ID: ' + (enabled ? 'LIGADO' : 'DESLIGADO');
    if (!enabled) { labels.forEach(function (el) { el.remove(); }); labels.clear(); }
  });
  function labelFor(car) {
    var el = labels.get(car);
    if (!el) {
      el = document.createElement('div');
      el.style.cssText = 'position:absolute;transform:translate(-50%,-100%);white-space:nowrap;padding:2px 6px;border:1px solid rgba(115,220,255,.8);border-radius:6px;background:rgba(5,15,27,.82);color:#eafaff;font:700 10px/1.25 Arial,sans-serif;letter-spacing:.15px;text-shadow:0 1px 2px #000;box-shadow:0 2px 8px #0005;';
      layer.appendChild(el); labels.set(car, el);
    }
    var spec = (window.VEHICLES && window.VEHICLES[car.type]) || {};
    var id = car._townModelId != null ? car._townModelId : (car._nativeVehicleId != null ? car._nativeVehicleId : (spec.vehicleId != null ? spec.vehicleId : '—'));
    var modelName = names[id] || spec.label || ((car.type || 'Veículo').replace(/[-_]/g, ' '));
    el.textContent = 'ID ' + (id != null ? id : '—') + ' · ' + modelName;
    return el;
  }
  var point = new THREE.Vector3();
  function update() {
    requestAnimationFrame(update);
    if (!enabled) return;
    var game = window.GAME;
    var cars = game && game.world && game.world.cars;
    var camera = game && game.cameraObj;
    var renderer = game && game.renderer;
    if (!cars || !camera || !renderer) return;
    var rect = renderer.domElement.getBoundingClientRect();
    var seen = new Set();
    cars.forEach(function (car) {
      if (!car || car.gone || !car.mesh) return;
      var el = labelFor(car); seen.add(car);
      var box = new THREE.Box3().setFromObject(car.mesh);
      if (box.isEmpty()) return;
      point.set((box.min.x + box.max.x) / 2, box.max.y + 0.22, (box.min.z + box.max.z) / 2);
      point.project(camera);
      var visible = point.z > -1 && point.z < 1 && point.x >= -1.15 && point.x <= 1.15 && point.y >= -1.15 && point.y <= 1.15;
      el.style.display = visible ? 'block' : 'none';
      if (visible) {
        el.style.left = (rect.left + (point.x * .5 + .5) * rect.width) + 'px';
        el.style.top = (rect.top + (-point.y * .5 + .5) * rect.height) + 'px';
      }
    });
    labels.forEach(function (el, car) { if (!seen.has(car)) { el.remove(); labels.delete(car); } });
  }
  requestAnimationFrame(update);
})();

/* Full-project GitHub package backup/restore. Restores every file into an app-side
   IndexedDB overlay; the APK itself is not modified or reinstalled. */
(function(){
 'use strict';
 var OWNER='menortrem121212-blip',REPO='atualizacoes-do-meu-j',BRANCH='main',PACKAGE='pacotes/Neon_Mayhem.zip';
 var API='https://api.github.com/repos/'+OWNER+'/'+REPO+'/contents/';
 var RAW='https://raw.githubusercontent.com/'+OWNER+'/'+REPO+'/'+BRANCH+'/'+PACKAGE;
 var DB='neonMayhemFullPackage',STORE='files',busy=false,uiReady=false;
 var panel,statusEl,tokenInput;
 function db(){return new Promise(function(ok,no){var r=indexedDB.open(DB,1);r.onupgradeneeded=function(){if(!r.result.objectStoreNames.contains(STORE))r.result.createObjectStore(STORE);};r.onsuccess=function(){ok(r.result);};r.onerror=function(){no(r.error);};});}
 function get(k){return db().then(function(d){return new Promise(function(ok,no){var r=d.transaction(STORE,'readonly').objectStore(STORE).get(k);r.onsuccess=function(){d.close();ok(r.result||null);};r.onerror=function(){d.close();no(r.error);};});});}
 function putAll(entries){return db().then(function(d){return new Promise(function(ok,no){var tx=d.transaction(STORE,'readwrite'),s=tx.objectStore(STORE);s.clear();entries.forEach(function(e){s.put(new Blob([e.data]),e.path);});tx.oncomplete=function(){d.close();ok();};tx.onerror=function(){d.close();no(tx.error);};});});}
 function status(s){if(statusEl)statusEl.textContent=s;}
 function crc32(a){var c=~0;for(var i=0;i<a.length;i++){c^=a[i];for(var j=0;j<8;j++)c=(c>>>1)^((c&1)?0xedb88320:0);}return (c^~0)>>>0;}
 function u16(n){return [n&255,(n>>>8)&255];} function u32(n){return [n&255,(n>>>8)&255,(n>>>16)&255,(n>>>24)&255];}
 function concat(parts){var n=parts.reduce(function(s,p){return s+p.length;},0),o=new Uint8Array(n),at=0;parts.forEach(function(p){o.set(p,at);at+=p.length;});return o;}
 function makeZip(files){var locals=[],centrals=[],offset=0;files.forEach(function(f){var name=new TextEncoder().encode('Neon_Mayhem/'+f.path),data=new Uint8Array(f.data),crc=crc32(data),lh=new Uint8Array([80,75,3,4].concat(u16(20),u16(0x800),u16(0),u16(0),u16(0),u32(crc),u32(data.length),u32(data.length),u16(name.length),u16(0),Array.from(name)));locals.push(lh,data);var ch=new Uint8Array([80,75,1,2].concat(u16(20),u16(20),u16(0x800),u16(0),u16(0),u16(0),u32(crc),u32(data.length),u32(data.length),u16(name.length),u16(0),u16(0),u16(0),u16(0),u32(0),u32(offset),Array.from(name)));centrals.push(ch);offset+=lh.length+data.length;});var central=concat(centrals),end=new Uint8Array([80,75,5,6].concat(u16(0),u16(0),u16(files.length),u16(files.length),u32(central.length),u32(offset),u16(0)));return new Blob(locals.concat([central,end]),{type:'application/zip'});}
 function parseZip(buf){var a=new Uint8Array(buf),v=new DataView(buf),eocd=-1;for(var p=a.length-22;p>=Math.max(0,a.length-65558);p--){if(v.getUint32(p,true)===0x06054b50){eocd=p;break;}}if(eocd<0)throw Error('ZIP inválido: final do pacote não encontrado.');var count=v.getUint16(eocd+10,true),pos=v.getUint32(eocd+16,true),out=[],chain=Promise.resolve();for(var i=0;i<count;i++){if(v.getUint32(pos,true)!==0x02014b50)throw Error('ZIP inválido: índice de arquivos corrompido.');var method=v.getUint16(pos+10,true),csize=v.getUint32(pos+20,true),nlen=v.getUint16(pos+28,true),elen=v.getUint16(pos+30,true),clen=v.getUint16(pos+32,true),local=v.getUint32(pos+42,true),name=new TextDecoder().decode(a.slice(pos+46,pos+46+nlen));pos+=46+nlen+elen+clen;if(name.endsWith('/'))continue;var clean=name.replace(/^Neon_Mayhem\//,'');if(clean.indexOf('..')>=0||clean.startsWith('/'))throw Error('O pacote contém caminho inválido.');var dataStart=local+30+v.getUint16(local+26,true)+v.getUint16(local+28,true),compressed=a.slice(dataStart,dataStart+csize);(function(path,m,bytes){chain=chain.then(function(){if(m===0){out.push({path:path,data:bytes});return;}if(m!==8)throw Error('Método ZIP não suportado no arquivo '+path);if(typeof DecompressionStream==='undefined')throw Error('Este Android não oferece descompactação ZIP compatível. Atualize o Android System WebView.');return new Response(new Blob([bytes]).stream().pipeThrough(new DecompressionStream('deflate-raw'))).arrayBuffer().then(function(x){out.push({path:path,data:new Uint8Array(x)});});});})(clean,method,compressed);}return chain.then(function(){return out;});}
 function b64bytes(bytes){var s='',step=0x8000;for(var i=0;i<bytes.length;i+=step)s+=String.fromCharCode.apply(null,bytes.subarray(i,Math.min(i+step,bytes.length)));return btoa(s);}
 function api(path,token,method,body){return fetch(API+path+'?t='+Date.now(),{method:method,headers:{'Accept':'application/vnd.github+json','Authorization':'Bearer '+token,'X-GitHub-Api-Version':'2022-11-28'},body:body?JSON.stringify(body):undefined,cache:'no-store'}).then(function(r){return r.text().then(function(t){var d={};try{d=t?JSON.parse(t):{};}catch(_){}if(!r.ok)throw Error((d.message||'GitHub HTTP '+r.status)+' ('+r.status+')');return d;});});}
 function getToken(){var t=tokenInput&&tokenInput.value.trim();if(!t)throw Error('Cole seu token do GitHub.');return t;}
 function fileList(){return [
  "SAVES/predios.json",
  "SAVES/mundo.json",
  "SAVES/LEIA-ME.txt",
  "SAVES/carros.json",
  "index.html",
  "docs/CONTROLS.md",
  "docs/FEATURES.md",
  ".gitignore",
  "media/town-vehicles/food-delivery-scooter.glb",
  "media/town-vehicles/mint-motor-scooter.glb",
  "media/town-vehicles/low-poly-garbage-truck.glb",
  "media/town-vehicles/lime-dirt-bike.glb",
  "media/town-vehicles/pearl-white-minivan.glb",
  "media/town-vehicles/low-poly-camper-rv.glb",
  "media/town-vehicles/red-wedge-sports-car.glb",
  "media/town-vehicles/low-poly-hatchback.glb",
  "media/town-vehicles/armoured-cash-van.glb",
  "media/town-vehicles/low-poly-tow-truck.glb",
  "media/town-vehicles/low-poly-monster-truck.glb",
  "media/town-vehicles/blue-pickup-truck.glb",
  "media/town-vehicles/baby-blue-convertible.glb",
  "media/town-vehicles/orange-go-kart.glb",
  "media/town-vehicles/family-suv.glb",
  "media/town-vehicles/low-poly-delivery-van.glb",
  "media/town-vehicles/low-poly-golf-cart.glb",
  "media/town-vehicles/yellow-rescue-helicopter.glb",
  "media/town-vehicles/stretch-limousine.glb",
  "media/town-vehicles/pastel-mini-ev.glb",
  "media/town-vehicles/open-wheel-racer.glb",
  "media/town-vehicles/low-poly-speedboat.glb",
  "media/town-vehicles/pastel-ice-cream-truck.glb",
  "media/town-vehicles/ASSET-LICENSE.txt",
  "media/town-vehicles/silver-family-sedan.glb",
  "media/vehicles/CarConcept.glb",
  "media/shots/centro-alto.jpg",
  "media/shots/chase.jpg",
  "media/shots/speedboat.jpg",
  "media/shots/isla-verde.jpg",
  "media/shots/showroom.jpg",
  "media/shots/casino.jpg",
  "media/social-card.png",
  "js/cast.js",
  "js/export.js",
  "js/analytics.js",
  "js/vehicle-id-display.js",
  "js/ambience.js",
  "js/player.js",
  "js/cheats.js",
  "js/sealife.js",
  "js/controls.js",
  "js/vehicles.js",
  "js/heist.js",
  "js/rc.js",
  "js/updates.js",
  "js/vehicle-editor.js",
  "js/carconcept.js",
  "js/aircraft.js",
  "js/combat.js",
  "js/interiors.js",
  "js/scenes.js",
  "js/building-editor.js",
  "js/strangers.js",
  "js/peds.js",
  "js/police.js",
  "js/landmarks.js",
  "js/tapes.js",
  "js/audio.js",
  "js/haptics.js",
  "js/dj.js",
  "js/touch.js",
  "js/streetlife.js",
  "js/save-files.js",
  "js/herald.js",
  "js/business.js",
  "js/city.js",
  "js/shops.js",
  "js/robbery.js",
  "js/utils.js",
  "js/derby.js",
  "js/chaos.js",
  "js/share.js",
  "js/lib/three.min.js",
  "js/isla.js",
  "js/guide.js",
  "js/arsenal.js",
  "js/missions.js",
  "js/photo.js",
  "js/main.js",
  "js/lola.js",
  "js/townvehicles.js",
  "js/gangs.js",
  "js/hud.js",
  "js/weather.js",
  "js/army.js",
  "test/regressions.js",
  "test/smoke.js",
  "README.md",
  "THREE.LICENSE",
  ".github/workflows/smoke.yml",
  "LICENSE"];}
 function send(){if(busy)return;var token;try{token=getToken();}catch(e){status(e.message);return;}busy=true;status('Montando backup de TODOS os arquivos do jogo...');var list=fileList(),files=[];var chain=Promise.resolve();list.forEach(function(path){chain=chain.then(function(){return fetch(path,{cache:'no-store'}).then(function(r){if(!r.ok)throw Error('Não consegui ler '+path+' (HTTP '+r.status+').');return r.arrayBuffer();}).then(function(b){files.push({path:path,data:new Uint8Array(b)});});});});chain.then(function(){status('Compactando '+files.length+' arquivos do jogo completo...');return makeZip(files).arrayBuffer();}).then(function(buf){var bytes=new Uint8Array(buf),content=b64bytes(bytes);status('Enviando pacote completo ('+(bytes.length/1048576).toFixed(1)+' MB) para o GitHub...');return api(PACKAGE,token,'GET').catch(function(e){if(String(e.message).indexOf('404')>=0)return {};throw e;}).then(function(old){var body={message:'Backup COMPLETO Neon Mayhem',content:content,branch:BRANCH};if(old.sha)body.sha=old.sha;return api(PACKAGE,token,'PUT',body);});}).then(function(){status('Backup COMPLETO enviado! Todos os arquivos do jogo foram incluídos.');}).catch(function(e){status('Falha no envio: '+e.message);}).then(function(){busy=false;});}
 function download(){if(busy)return;busy=true;status('Baixando o pacote COMPLETO do GitHub...');fetch(RAW+'?t='+Date.now(),{cache:'no-store'}).then(function(r){if(!r.ok)throw Error('Não encontrei o pacote no GitHub (HTTP '+r.status+'). Envie um backup primeiro.');return r.arrayBuffer();}).then(parseZip).then(function(entries){if(!entries.length)throw Error('O pacote está vazio.');var hasIndex=entries.some(function(e){return e.path==='index.html';});if(!hasIndex)throw Error('Pacote inválido: index.html não encontrado.');status('Restaurando '+entries.length+' arquivos: mapa, veículos, prédios, códigos, modelos, sons e demais recursos...');return putAll(entries).then(function(){status('Pacote inteiro restaurado no armazenamento do jogo. Reiniciando com a versão baixada...');setTimeout(function(){sessionStorage.removeItem('nm_full_package_booted');location.reload();},700);});}).catch(function(e){status('Falha ao baixar/restaurar: '+e.message);}).then(function(){busy=false;});}
 function ui(){if(uiReady)return true;var p=document.getElementById('pp-game');if(!p)return false;uiReady=true;var g=document.createElement('div');g.className='pgroup';g.innerHTML='<h4>BACKUP DO JOGO COMPLETO</h4><div style="display:flex;gap:7px"><span class="mbtn" id="nm-full-send" style="flex:1;text-align:center">⬆️ ENVIAR TUDO</span><span class="mbtn" id="nm-full-download" style="flex:1;text-align:center">⬇️ BAIXAR TUDO</span></div><label style="display:block;margin-top:9px;font-size:11px;color:#b9dce5">Token GitHub (necessário somente para enviar)</label><input id="nm-full-token" type="password" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="Cole seu token aqui" style="box-sizing:border-box;width:100%;margin-top:5px;padding:9px;border-radius:7px;border:1px solid #52717c;background:#101b22;color:#fff"><div id="nm-full-status" style="font-size:12px;color:#9df3ff;margin-top:7px;line-height:1.5">ENVIAR TUDO publica o projeto inteiro. BAIXAR TUDO substitui a versão carregada pelo pacote completo do GitHub, sem reinstalar o APK.</div>';p.insertBefore(g,p.firstChild);statusEl=g.querySelector('#nm-full-status');tokenInput=g.querySelector('#nm-full-token');g.querySelector('#nm-full-send').onclick=function(e){e.stopPropagation();send();};g.querySelector('#nm-full-download').onclick=function(e){e.stopPropagation();download();};return true;}
 var tries=0,timer=setInterval(function(){if(ui()||++tries>100)clearInterval(timer);},150);
 window.GAME=window.GAME||{};GAME.FULL_PACKAGE={send:send,download:download};
})();

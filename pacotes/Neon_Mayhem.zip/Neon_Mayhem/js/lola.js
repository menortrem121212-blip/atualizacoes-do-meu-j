// Lola, as the voice in your ear and not only the one with work for you.
//
// The first time something happens that the game never explains — a cassette
// picked up off the pavement, a ramp that pays, a star, a boat — nobody said
// what it was or why it mattered. Now Lola pages it, once: the first tape,
// the first jump, the first star, the first time in each kind of vehicle, the
// first shift on offer, the first night in hospital. Each line is said once
// for the life of the save, and TIPS on the pause screen turns them off for
// anybody who knows the town already.
GAME.lola = (function () {
  function K(code) { return GAME.controls ? GAME.controls.label(code) : code.replace(/^Key/, ''); }
  function onPad() { return !!(GAME.controls && GAME.controls.usingPad && GAME.controls.usingPad()); }
  function touch() { return !!GAME.isTouch; }
  // the lines, written as she talks; a function where it names a control
  var TIPS = {
    tape: 'Isso é uma fita perdida. Um DJ pirata transmitia da ponta do píer até tirarem ele do ar, e as fitas dele se espalharam por aí — são trinta, nas duas ilhas. Cada uma paga; o radar brilha quando você está perto. Ache todas e ele volta ao ar.',
    stunt: 'Salto acrobático inédito! Cada rampa da cidade paga na primeira vez que você a vence — quanto mais rápido, melhor. Ache todas e vale a pena.',
    islaJump: 'Isla Verde tem seus próprios dez saltos, com uma contagem separada — e um prêmio próprio quando você completar todos.',
    star: 'Você chamou a atenção da polícia. Saia de vista e fique na moita que passa. Tinta nova em uma oficina tira uma ou duas estrelas, e o sargento da delegacia pode sumir com a papelada — por um preço.',
    stars3: 'Três estrelas: agora eles sabem seu rosto, então tinta não engana mais. Quebre a linha de visão e fique na moita, ou fale com o sargento. Uma noite em casa também ajuda.',
    wasted: 'Você vai sobreviver. O hospital fica com sua grana, mas suas armas somem. Se tiver um imóvel, você acorda lá, com tudo.',
    busted: 'Preso. Eles levam uma multa e seu equipamento. Da próxima vez, some com as estrelas antes de te encurralarem — carro parado do lado de uma viatura é carro de onde te algemam.',
    boat: 'Um barco! Nenhuma viatura te segue na água — mas a patrulha do porto tem lanchas próprias. A baía também tem trabalho: procure os círculos perto dos píeres.',
    heli: function () { return touch() ? 'Agora você está voando. UP e DN sobem e descem. O teto é uns duzentos metros — e a polícia vem atrás aqui em cima com um helicóptero próprio.'
      : 'Agora você está voando. ' + K('Space') + ' sobe, ' + K('ShiftLeft') + ' desce. O teto é uns duzentos metros — e a polícia vem atrás aqui em cima com um helicóptero próprio.'; },
    plane: function () { return 'A pista é por ali. Pegue velocidade, puxe para cima e, se tudo der errado, ' + (touch() ? 'EXIT' : K('KeyF')) + ' tira você de lá com um paraquedas.'; },
    swim: 'Nadando? Não dá para segurar arma na água. Saia pela areia, por um píer, ou qualquer lugar baixo o bastante para se agarrar.',
    respray: 'Tinta nova, vida nova — até duas estrelas vão embora com a cor antiga. De três para cima eles sabem seu rosto, e tinta não ajuda.',
    job: function () { return 'Esse carro tem trabalho nele. ' + (touch() ? 'Aperte JOB' : 'Aperte ' + K('KeyJ')) + ' para começar um turno — toda corrida paga, e cada nível exige um pouco mais de você.'; },
    shop: 'As lojas são de entrar: fique no tapete brilhante na porta. Armas, roupas, carros, um lugar para morar — se você tiver o dinheiro.',
    home: 'Seu próprio lugar. Durma para pular oito horas e esfriar a polícia, e se você cair por perto, acorda aqui em vez de no hospital.',
    casino: 'O Lucky Gull. A roleta é honesta, quase sempre, os cavalos correm nas telas da direita, e o bar te remenda. Gaste o que você pode perder.',
    derby: 'Gull Downs! Escolha um cavalo e uma aposta. As odds estão no quadro: um 4/1 paga quatro vezes sua aposta mais seu dinheiro de volta, e os azarões pagam muito porque quase sempre perdem. Depois é só assistir.',
    wardrobe: 'Tudo o que você tem fica pendurado aqui, e trocar de roupa é de graça. Compre algo na THREADS e aparece em todo lugar que você tem.',
    robbery: 'Assaltando uma loja? Mantenha a arma nele e não pisque — o caixa esvazia enquanto você aguenta. O alarme disparou no segundo em que as mãos dele se mexeram, então tenha uma saída.',
    business: 'Um negócio seu. O caixa enche ao longo do dia — três dias dele, não mais — e fica lá até você vir esvaziar no balcão. Deixe demais e alguém de máscara esvazia para você.',
    photo: function () { return 'Belo tiro. Suas fotos ficam guardadas no álbum — ' + (touch() ? 'PAUSE' : 'Esc') + ', depois FOTOS — e você pode baixar as que gostar.'; }
  };

  function prefs() { GAME.prefs = GAME.prefs || {}; return GAME.prefs; }
  function seen() { var p = prefs(); return p.lolaSeen || (p.lolaSeen = {}); }
  function tipsOn() { return !prefs().tipsOff; }

  // The first time `key` comes up: say it (if tips are on) and remember it
  // was said either way, so switching tips back on later does not bring a
  // backlog of everything that happened while they were off.
  function first(key) {
    var line = TIPS[key];
    if (!line) return false;
    var s = seen();
    if (s[key]) return false;
    s[key] = true;
    if (GAME.save) GAME.save();
    if (!tipsOn() || !GAME.hud || !GAME.hud.pager) return false;
    GAME.hud.pager('LOLA', typeof line === 'function' ? line() : line);
    if (GAME.track) GAME.track('tip-' + key);
    return true;
  }
  function setTips(on) {
    prefs().tipsOff = !on;
    if (GAME.save) GAME.save();
  }

  // ---------- call her ----------
  // Lola as an assistant you can ask, not only a pager that goes off: L (or
  // ASK LOLA on the pause screen, which is how a phone reaches her) and she
  // asks what she can do for you — what to do next, how to lose the law,
  // where the money is, the way to a shop or home, what a thing is, how you
  // are doing, the controls. Where an answer is a place, she marks it on
  // your map. The game holds still while you talk, as it does on the map.
  var view = null, sel = 0, opts = [];
  function $(id) { return document.getElementById(id); }
  function F() { return GAME.focus(); }
  function dist(x, z) { var f = F(); return Math.hypot(x - f.x, z - f.z); }
  function far(x, z) {
    var d = dist(x, z);
    return d < 1000 ? Math.round(d / 10) * 10 + ' m' : (d / 1000).toFixed(1) + ' km';
  }
  // which way, as the map has it: north is up the map (-z), east is right (+x)
  function way(x, z) {
    var f = F(), a = Math.atan2(x - f.x, -(z - f.z)) * 180 / Math.PI;
    return ['north', 'north-east', 'east', 'south-east', 'south', 'south-west', 'west', 'north-west'][Math.round(((a + 360) % 360) / 45) % 8];
  }
  function there(x, z) { return far(x, z) + ' ' + way(x, z) + ' de você'; }
  function islaOpen() { return !GAME.isla || GAME.isla.isOpen(); }
  function onIsla(x, z) { return !!(GAME.isla && GAME.isla.contains && GAME.isla.contains(x, z)); }
  function reachable(x, z) { return islaOpen() || !onIsla(x, z); }
  function nearest(list, xz) {
    var best = null, bd = 1e18;
    list.forEach(function (it) {
      var p = xz(it);
      if (!p || !reachable(p.x, p.z)) return;
      var d = dist(p.x, p.z);
      if (d < bd) { bd = d; best = { it: it, x: p.x, z: p.z }; }
    });
    return best;
  }
  function locs(kind) { return GAME.shops && GAME.shops.locations ? GAME.shops.locations().filter(function (l) { return l.kind === kind && l.at; }) : []; }
  function mark(x, z, what) {
    return { label: '📍 MARQUE NO MEU MAPA', fn: function () {
      if (GAME.nav) GAME.nav.setDest(x, z);
      close();
      if (GAME.hud && GAME.hud.pager) GAME.hud.pager('LOLA', 'Marcado: ' + what + '. Siga a linha no seu radar.');
    } };
  }

  // -- the answers --
  function nextThing() {
    var M = GAME.missions, a = M && M.active;
    if (!a && GAME.guide && GAME.guide.step) return { say: GAME.guide.now() };
    if (a) {
      return { say: 'Você está em ' + a.def.name + ' agora: ' + (M.objectiveText() || 'ir até o fim') +
        '. Termine — ou use ' + (touch() || onPad() ? 'ABANDONAR na tela de pausa' : K('KeyX') + ' twice') + ' se quiser sair.' };
    }
    var bests = GAME.bests || {};
    var left = M ? M.DEFS.filter(function (d) { return bests[d.id] === undefined && (!d.isla || islaOpen()); }) : [];
    var n = nearest(left, function (d) { return d.start; });
    if (n) {
      var d = n.it, kind = { race: 'uma corrida', courier: 'uma entrega', takedown: 'uma caça ao alvo', rampage: 'uma fúria' }[d.type] || 'um trabalho';
      var won = M.DEFS.filter(function (dd) { return bests[dd.id] !== undefined; }).length, more = Math.max(1, 4 - won);
      var shut = !islaOpen() ? ' Vença ' + (more === 1 ? 'mais um' : more + ' more') + ' dos meus trabalhos e as pontes para Isla Verde se abrem.' : '';
      return { say: d.name + ' — ' + kind + ', ' + there(n.x, n.z) + '. É o que está mais perto na minha lista e você ainda não fez.' + shut,
        acts: [mark(n.x, n.z, d.name)] };
    }
    var ST = GAME.stunts, T = GAME.tapes;
    if (ST && ST.found < ST.total) return { say: 'Todos os trabalhos da minha lista estão feitos — boa. Ainda há saltos acrobáticos que você não fez (' + ST.found + ' of ' + ST.total + '), e o radar brilha perto de uma fita perdida.' };
    return { say: 'Sinceramente? Você fez tudo. Vá gastar um pouco desse dinheiro — o cassino do píer adoraria te ver.' };
  }
  function theLaw() {
    var w = GAME.police.wanted, acts = [];
    if (w <= 0) return { say: 'Você está limpo. Continue assim — e lembre que uma viatura parada do seu lado pode te algemar dentro de um carro.' };
    var rs = nearest(GAME.city.pois.resprays || [], function (r) { return r.door; });
    var desk = nearest(locs('bribe'), function (l) { return l.at; });
    var home = nearest(locs('safehouse').filter(function (l) { return GAME.shops.owns(l.sh.id); }), function (l) { return l.at; });
    var say;
    if (w <= 2) {
      say = (w === 1 ? 'Uma estrela.' : 'Duas estrelas.') + ' Quebre a linha de visão e fique na moita que passa. Ou tinta nova: ' +
        (rs ? 'a oficina mais próxima é ' + there(rs.x, rs.z) + '.' : 'qualquer oficina serve.');
      if (rs) acts.push(mark(rs.x, rs.z, 'a oficina de pintura'));
    } else {
      say = w + ' estrelas — eles sabem seu rosto, então tinta não engana. Saia de vista e fique na moita, ou fale com o sargento da delegacia' +
        (desk ? ' na delegacia ' + there(desk.x, desk.z) : '') + ' — ele some com papelada, por um preço.' +
        (home ? ' Ou vá para casa dormir: a sua é ' + there(home.x, home.z) + '.' : '');
      if (desk) acts.push(mark(desk.x, desk.z, 'o sargento da delegacia'));
    }
    if (home && w <= 2) say += ' Seu lugar é ' + there(home.x, home.z) + ' — ninguém enxerga lá dentro.';
    if (home) acts.push({ label: '🏠 MARQUE MEU LUGAR', fn: mark(home.x, home.z, home.it.sh.name).fn });
    return { say: say, acts: acts };
  }
  function money() {
    var bests = GAME.bests || {}, M = GAME.missions, ST = GAME.stunts, T = GAME.tapes;
    var left = M ? M.DEFS.filter(function (d) { return bests[d.id] === undefined && (!d.isla || islaOpen()); }).length : 0;
    var lines = [];
    lines.push('Os bicos pagam em toda corrida: entre em um táxi, uma ambulância ou uma viatura e aperte ' + (touch() ? 'JOB' : K('KeyJ')) + '.' + (islaOpen() ? ' O carrinho de sorvete em Isla Verde também tem rodadas — a buzina toca as musiquinhas.' : ''));
    if (left) lines.push(left + ' dos meus trabalhos ainda estão esperando você, e a primeira vitória em cada um paga melhor.');
    if (ST && ST.found < ST.total) lines.push((ST.total - ST.found) + ' saltos acrobáticos ainda pagam o dinheiro da primeira vez.');
    if (T && T.found < T.total) lines.push((T.total - T.found) + ' fitas perdidas estão por aí, cada uma vale alguma coisa.');
    var B = GAME.business;
    if (B && B.count < B.total) lines.push('Ou deixe o dinheiro vir até você: compre um negócio — o barbeiro, a THREADS, uma loja de ferragens, o bar do Lucky Gull, a VERDE CABS do outro lado do canal — e o caixa enche todo dia.');
    else if (B && B.count) lines.push('Seus negócios estão rendendo dinheiro para você — vá esvaziar os caixas.');
    lines.push('E tem o Lucky Gull, se você estiver com sorte.');
    return { say: lines.join(' ') };
  }
  var PLACES = [
    ['hardware', '🔫 ARMAS E COLETES', 'a loja de armas'], ['dress', '👕 ROUPAS', 'THREADS'], ['barber', '💈 UM CORTE DE CABELO', 'o barbeiro'],
    ['showroom', '🏎 UM CARRO NOVO', 'o showroom'], ['home', '🏠 MEU LUGAR', 'seu lugar'], ['casino', '🎰 O CASSINO', 'o Lucky Gull'],
    ['hospital', '➕ UM HOSPITAL', 'o hospital'], ['bribe', '🚔 O SARGENTO DA DELEGACIA', 'a mesa da delegacia']
  ];
  function placeOf(kind) {
    if (kind === 'hospital') return nearest(GAME.city.pois.hospitals || [], function (h) { return h; });
    if (kind === 'home') {
      var owned = locs('safehouse').filter(function (l) { return GAME.shops.owns(l.sh.id); });
      return nearest(owned.length ? owned : locs('safehouse'), function (l) { return l.at; });
    }
    return nearest(locs(kind), function (l) { return l.at; });
  }
  function takeMe() {
    return { say: 'Aonde? Eu marco no seu mapa.', list: PLACES.map(function (p) {
      return { label: p[1], fn: function () {
        var n = placeOf(p[0]);
        if (!n) { answer({ say: 'Nada assim que eu consiga te levar agora.' }); return; }
        var name = p[0] === 'home' && n.it.sh ? (GAME.shops.owns(n.it.sh.id) ? n.it.sh.name : n.it.sh.name + ' (à venda)') : n.it.name || p[2];
        answer({ say: (name || p[2]) + ' is ' + there(n.x, n.z) + '.', acts: [mark(n.x, n.z, name || p[2])] });
      } };
    }) };
  }
  var TOPICS = [['tape', 'Fitas perdidas'], ['stunt', 'Saltos acrobáticos'], ['star', 'A polícia'], ['job', 'Bicos em veículos'],
    ['shop', 'Lojas'], ['home', 'Um lugar seu'], ['wardrobe', 'Seu guarda-roupa'], ['casino', 'O cassino'], ['derby', 'Os cavalos'],
    ['boat', 'Barcos'], ['heli', 'Helicópteros'], ['plane', 'Aviões'], ['swim', 'Nadando'], ['respray', 'Repinturas'], ['photo', 'Sua câmera']];
  function explain() {
    return { say: 'Pode perguntar. Sobre o que você quer saber?', list: TOPICS.map(function (t) {
      return { label: t[1].toUpperCase(), fn: function () { answer({ say: lineOf(t[0]) }); } };
    }) };
  }
  function lineOf(k) { var l = TIPS[k]; return typeof l === 'function' ? l() : l; }

  // ---------- Costa Rosa, as she tells it ----------
  // Where and when you are, whose streets these are, who else is in town:
  // on a first run she tells it face to face before she offers to show you
  // around (introScene, guide.js), and TELL ME ABOUT COSTA ROSA has it to
  // read any time after. Each part says where the story has got to.
  function beat(id) { return !!(GAME.bests && GAME.bests[id] !== undefined); }
  var WORLD = [
    ['🙋 QUEM É VOCÊ, LOLA?', function () {
      return 'Lola. Cheguei nesta cidade com uma mala em 79, e agora a Ocean Strip é minha — os bares, as casas noturnas, o calçadão e os carros rápidos que sobem e descem por ela. ' +
        'Quem quer algo feito na orla vem até mim mais cedo ou mais tarde. Você quer trabalho, eu tenho trabalho: os círculos no seu mapa são meus serviços. Meu pessoal veste rosa.';
    }],
    ['🌴 COSTA ROSA, 1986', function () {
      return 'Costa Rosa, 1986. Neon, palmeiras e dinheiro sobre o qual ninguém faz perguntas demais. Duas ilhas: Isla Rosa, onde você está — a praia, a cidade, o porto — ' +
        'e Isla Verde, do outro lado do canal. Os dias são quentes, as noites mais ainda, o rádio nunca para, e todo mundo aqui está atrás de uma vantagem. Inclusive eu.';
    }],
    ['🏙 OS BAIRROS', function () {
      return 'Quatro deles em Isla Rosa. A OCEAN STRIP, na praia: o calçadão, os píeres, o cassino Lucky Gull, a roda-gigante, a casa noturna Neon Tide e o Savings & Loan. ' +
        'CENTRO ALTO, no centro: as torres, a Rosa Pictures e a torre do heliponto. PUERTO VIEJO, o porto: as docas, os guindastes, os galpões, o guindaste de exportação e o aeroporto mais adiante. ' +
        'E LAS COLINAS, morro acima: o hospital, o barbeiro, o estádio, as casas bonitas — e a Villa Salazar, bem no alto.';
    }],
    ['🌉 ISLA VERDE', function () {
      var dorado = beat('hit2') ? 'agora é nossa' : 'o quintal do Rico';
      if (!islaOpen()) return 'Do outro lado da água. As duas pontes estão fechadas, e o ar sobre o canal também — o Rico tem amigos na prefeitura. ' +
        'Complete quatro dos meus trabalhos, ou ache todos os saltos acrobáticos desta ilha, e elas abrem. Lá são morros e curvas fechadas: PUERTO DORADO, o porto da ilha, e ' + dorado + '; ' +
        'ALTA VERDE, no alto do morro; e MIRADOR, com o farol, o observatório e a marina.';
      return 'As pontes estão abertas. PUERTO DORADO é o porto da ilha — ' + dorado + '. ALTA VERDE fica no morro, só zigue-zague; MIRADOR tem o farol, o observatório e a marina. ' +
        'Mais dez saltos acrobáticos lá, e algumas pessoas que precisam de uma mãozinha.';
    }],
    ['🎨 AS GANGUES', function () {
      if (beat('hit2')) return 'Havia dois lados nesta cidade. A gangue do Rico Salazar — ameixa e preto, sedãs pretos — e a minha, em rosa e branco. O Rico caiu na própria marina, e a gangue dele foi junto. ' +
        'As duas ilhas são nossas agora. Meu pessoal está do seu lado: deixe eles em paz e eles te deixam em paz.';
      var harbour = beat('hit1') ? 'Ele mandava no porto, Puerto Viejo, até o contador dele perder o livro-caixa — agora é nosso' : 'Ele controla o porto, Puerto Viejo';
      return 'Dois lados nesta cidade. A gangue do Rico SALAZAR: ameixa e preto, sedãs pretos, muita arma. ' + harbour + ', e Puerto Dorado na ilha — e ele quer a orla. ' +
        'Meu pessoal veste rosa e branco e dirige esportivos rosa; estão do seu lado. Cruze o Rico ' + (beat('rampage1') ? '— e você cruzou — ' : 'enough ') + 'e os rapazes dele atiram à primeira vista nas ruas dele. Aprenda as cores.';
    }],
    ['🚓 A POLÍCIA', function () {
      return 'A PD de Costa Rosa. Faça algo idiota onde dá para ver e você ganha estrelas — e quanto mais estrelas, mais eles mandam: viaturas, depois bloqueios e espetos, depois um helicóptero, e lá no topo o exército. ' +
        'Despiste: saia de vista e deixe esfriar, passe por uma oficina de pintura, ou passe algo para o sargento de uma delegacia. Se for preso, ou eliminado, você acorda sem as armas. O taco, não.';
    }]
  ];
  function costaRosa() {
    return { say: 'Puxe uma cadeira. O que você quer saber?', list: WORLD.map(function (w) {
      return { label: w[0], fn: function () { answer({ say: w[1](), list: [{ label: '↩ MAIS SOBRE COSTA ROSA', fn: function () { answer(costaRosa()); } }] }); } };
    }) };
  }
  // the first run: hers, face to face, where you stand — then `then` (her
  // offer to show you around). False when there is no scene to be had.
  function introScene(then) {
    if (!GAME.scenes) return false;
    var lines = [
      ['lola', 'Bem-vindo a Costa Rosa, garoto. Eu sou a Lola — a Ocean Strip é minha. Os bares, as casas noturnas e os carros rápidos que sobem e descem por ela.'],
      ['you', 'Acabei de descer do ônibus. Onde estou, exatamente?'],
      ['lola', 'Costa Rosa, 1986. Neon, palmeiras e dinheiro sobre o qual ninguém faz perguntas. Duas ilhas — esta, Isla Rosa, e Isla Verde do outro lado da água.'],
      ['lola', 'As pontes para Isla Verde estão fechadas, e isso é coisa do Rico Salazar. A ilha é dele. O porto também — por enquanto.'],
      ['you', 'Quem é o Rico Salazar?'],
      ['lola', 'O outro lado desta cidade. A gangue dele veste ameixa e preto e dirige sedãs pretos. Meu pessoal veste rosa. Aprenda as cores.'],
      ['lola', 'E a polícia: estrelas em você, e eles vêm. Despiste, passe por uma oficina de pintura, ou suborne o sargento de uma delegacia.'],
      ['lola', 'Qualquer coisa disso de novo, quando quiser — é só perguntar. Está em COSTA ROSA.']
    ];
    return GAME.scenes.play({ id: 'lola-intro', shots: [{ set: 'here', cast: ['lola', 'you'], lines: lines }] }, function () { if (then) then(); });
  }
  function howAmI() {
    var bests = GAME.bests || {}, M = GAME.missions, ST = GAME.stunts, T = GAME.tapes, P = GAME.player, done = 0;
    if (M) M.DEFS.forEach(function (d) { if (bests[d.id] !== undefined) done++; });
    var homes = GAME.shops ? locs('safehouse').filter(function (l) { return GAME.shops.owns(l.sh.id); }).length : 0;
    var g = GAME.shops && GAME.shops.garage ? GAME.shops.garage().length : 0;
    var pct = Math.round(100 * (done + (ST ? ST.found + (ST.islaFound || 0) : 0) + (T ? T.found : 0)) /
      Math.max(1, (M ? M.DEFS.length : 0) + (ST ? ST.total + (ST.islaTotal || 0) : 0) + (T ? T.total : 0)));
    return { say: 'Trabalhos na minha lista: ' + done + ' of ' + (M ? M.DEFS.length : 0) + '. Saltos acrobáticos: ' + (ST ? ST.found + ' of ' + ST.total : '—') +
      (ST && ST.islaTotal && islaOpen() ? ', e ' + ST.islaFound + ' of ' + ST.islaTotal + ' na ilha' : '') + '. Fitas perdidas: ' + (T ? T.found + ' of ' + T.total : '—') +
      (GAME.strangers ? '. Desconhecidos ajudados: ' + GAME.strangers.done + ' of ' + GAME.strangers.total : '') +
      (GAME.heist && (GAME.heist.offered() || GAME.heist.step > 0) ? '. O grande golpe: ' + Math.min(GAME.heist.step, 4) + ' de 4 partes' : '') +
      (GAME.business && GAME.business.count ? '. Negócios: ' + GAME.business.count + ' of ' + GAME.business.total : '') +
      '. Você está com $' + P.cash.toLocaleString() + ', você tem ' + homes + ' de 3 lugares' + (g ? ' and ' + g + ' na garagem' : '') +
      '. Digamos que seja ' + pct + '% de Costa Rosa. ' + (pct < 25 ? 'Ainda tem muito pela frente.' : pct < 75 ? 'Chegando lá.' : 'Quase lá, garoto.') };
  }
  // the Savings & Loan: where it stands, and the next part to go and do
  function bigScore() {
    var H = GAME.heist, b = H.board();
    return { say: b.say, list: b.next ? [{ label: '▶ ' + b.next, fn: function () { close(); H.begin(); } }] : [] };
  }
  function controlsHelp() {
    if (onPad()) return { say: 'O analógico esquerdo move, o direito olha. RT atira e LT mira a pé; em qualquer coisa com motor, são o acelerador e o freio. ' +
      'A pula, B corre, Y entra e sai, X começa um bico. LB e RB escolhem um alvo ou atiram pela janela, R3 a buzina, L3 uma foto, o D-pad as armas e o rádio. ' +
      'BACK é o mapa. START pausa — e é lá que você me encontra.' };
    if (touch()) return { say: 'Polegar esquerdo: onde ele pousar é o seu analógico. Lado direito: ATIRAR, PULAR e CORRER a pé, os pedais em um carro. SAIR entra e sai, JOB começa um turno, 📢 é a buzina, 📷 tira uma foto. PAUSAR tem o mapa, seus ajustes — e eu.' };
    return { say: K('KeyW') + K('KeyA') + K('KeyS') + K('KeyD') + ' para andar, o mouse para olhar, clique esquerdo para atirar e clique direito (ou ' + K('Tab') + ') para fixar o alvo. ' +
      K('KeyF') + ' entra e sai, ' + K('Space') + ' pula ou escala, ' + K('ShiftLeft') + ' sprints. ' + K('KeyJ') + ' começa um bico, ' + K('KeyG') + ' a buzina, ' +
      K('KeyC') + ' uma foto (' + K('KeyV') + ' para ver), ' + K('KeyP') + ' o mapa, e ' + K('KeyL') + ' me chama. CONTROLES na tela de pausa redefine tudo.' };
  }

  function topLevel() {
    var w = GAME.police && GAME.police.wanted > 0, law;
    var list = [
      { label: '🧭 O QUE EU DEVO FAZER AGORA?', fn: function () { answer(nextThing()); } },
      // her guided first day (guide.js), for anyone who turned it down or
      // walked off part way, until it has been seen through once
      GAME.guide && GAME.guide.canStart() ? { label: '🎓 ME MOSTRE O BÁSICO', fn: function () { close(); GAME.guide.begin(); } } : null,
      // her big score, once the bridges are open (heist.js)
      GAME.heist && GAME.heist.offered() && !GAME.heist.busy ? { label: '💰 O GRANDE GOLPE', fn: function () { answer(bigScore()); } } : null,
      law = { label: w ? '🚨 A POLÍCIA ESTÁ NO MEU PÉ' : '🚨 COMO DESPISTO A POLÍCIA?', fn: function () { answer(theLaw()); } },
      { label: '💰 ONDE ESTÁ O DINHEIRO?', fn: function () { answer(money()); } },
      { label: '📍 ME LEVE A ALGUM LUGAR', fn: function () { answer(takeMe()); } },
      { label: '📖 ME FALE SOBRE…', fn: function () { answer(explain()); } },
      { label: '🌴 ME FALE SOBRE COSTA ROSA', fn: function () { answer(costaRosa()); } },
      { label: '📊 COMO ESTOU INDO?', fn: function () { answer(howAmI()); } },
      { label: '🎮 ME LEMBRE DOS CONTROLES', fn: function () { answer(controlsHelp()); } },
      { label: '👋 NADA, OBRIGADO', fn: close }
    ];
    list = list.filter(Boolean);
    // with the law on you, that comes first
    if (w) { list.splice(list.indexOf(law), 1); list.unshift(law); }
    var h = GAME.timeOfDay !== undefined && GAME.timeOfDay < 0.35 ? 'Acordado até tarde, garoto?' : 'Oi, garoto.';
    return { say: h + (w ? ' Parece movimentado onde você está.' : '') + ' O que posso fazer por você?', list: list, top: true };
  }

  // -- the screen --
  function render() {
    var v = view;
    // (somebody else asking — a stranger on the pavement: strangers.js)
    $('lola-from').textContent = v.from || '📟 LOLA';
    $('lola-say').textContent = v.say;
    // whose face it is: hers, or the stranger asking (cast.js)
    var fc = $('lola-face'), id = v.face || (v.from ? GAME.cast && GAME.cast.idFor(v.from) : 'lola');
    if (fc && fc.getAttribute('data-who') !== String(id)) {
      fc.innerHTML = id && GAME.cast ? GAME.cast.portrait(id) : '';
      fc.setAttribute('data-who', String(id));
    }
    opts = (v.list || []).slice();
    (v.acts || []).forEach(function (a) { opts.push(a); });
    if (!v.top) {
      opts.push({ label: '↩ OUTRA COISA', fn: function () { show(topLevel()); }, back: true });
      opts.push({ label: '✓ VALEU, LOLA', fn: close });
    }
    sel = Math.min(sel, opts.length - 1);
    var box = $('lola-opts');
    box.innerHTML = '';
    opts.forEach(function (o, i) {
      var b = document.createElement('div');
      b.className = 'lola-opt' + (i === sel ? ' sel' : '');
      b.textContent = o.label;
      b.addEventListener('click', function (e) { e.preventDefault(); sel = i; pick(); });
      box.appendChild(b);
    });
    var cur = box.children[sel];
    if (cur && cur.scrollIntoView) cur.scrollIntoView({ block: 'nearest' });
    $('lola-hint').textContent = touch() ? 'Toque em um' : '↑↓ e Enter, ou clique  ·  Esc ' + (v.escSays || 'para voltar');
  }
  function show(v) {
    view = v; sel = 0; render();
    // a word or two of it in their voice, as the card comes up
    var id = v.face || (v.from ? GAME.cast && GAME.cast.idFor(v.from) : 'lola');
    if (id && GAME.cast) GAME.cast.say(id, v.say, 1.4);
  }
  function answer(v) { if (GAME.audio) GAME.audio.cashTick(); show(v); }
  // a choice is an answer: whatever it does, closing after it is not a no
  function pick() { var o = opts[sel]; if (o) { onClose = null; o.fn(); } }
  function open() {
    if (GAME.lolaOpen || !GAME.started || GAME.mapOpen || GAME.shopOpen || GAME.shareOpen) return false;
    if (GAME.player.state !== 'alive') return false;
    if (GAME.paused) GAME.togglePause();
    GAME.lolaOpen = true;
    var scr = $('lola-screen');
    // a click or a tap off her card closes it, as Esc does at her top level
    if (!scr.__offCard) {
      scr.__offCard = true;
      scr.addEventListener('click', function (e) { if (e.target === scr) { e.preventDefault(); close(); } });
    }
    scr.style.display = 'flex';
    if (GAME.audio && GAME.audio.pagerBeep) GAME.audio.pagerBeep();
    if (GAME.releasePointer) GAME.releasePointer();
    if (GAME.syncOverlayMusic) GAME.syncOverlayMusic();
    show(topLevel());
    if (GAME.track) GAME.track('lola-called');
    return true;
  }
  // Open on a question of somebody else's (guide.js), rather than her menu.
  // Closing it without an answer — Esc, L, B — is an answer too: onClose.
  var onClose = null;
  function offer(v) {
    if (!open()) return false;
    onClose = v.onClose || null;
    show(v);
    return true;
  }
  function close() {
    if (!GAME.lolaOpen) return;
    var then = onClose;
    onClose = null;
    GAME.lolaOpen = false;
    $('lola-screen').style.display = 'none';
    if (GAME.cast) GAME.cast.hush();
    if (GAME.syncOverlayMusic) GAME.syncOverlayMusic();
    if (GAME.regainPointer) GAME.regainPointer();
    if (then) then();
  }
  function key(code) {
    if (code === 'ArrowDown' || code === 'KeyS') { sel = (sel + 1) % opts.length; render(); }
    else if (code === 'ArrowUp' || code === 'KeyW') { sel = (sel - 1 + opts.length) % opts.length; render(); }
    else if (code === 'Enter' || code === 'Space' || code === 'KeyE') pick();
    else if (code === 'Escape' || code === 'Backspace' || code === 'KeyL') { if (view && !view.top) show(topLevel()); else close(); }
    else if (/^Digit[1-9]$/.test(code)) { var n = +code.slice(5) - 1; if (n < opts.length) { sel = n; pick(); } }
  }

  return {
    first: first,
    setTips: setTips,
    introScene: introScene,
    // headless: the world as she tells it, part by part
    world: function () { return WORLD.map(function (w) { return { label: w[0], say: w[1]() }; }); },
    open: open,
    offer: offer,
    close: close,
    key: key,
    get isOpen() { return !!GAME.lolaOpen; },
    // headless: what is on offer, and choosing one by its label
    options: function () { return opts.map(function (o) { return o.label; }); },
    choose: function (re) { for (var i = 0; i < opts.length; i++) if (re.test(opts[i].label)) { sel = i; pick(); return true; } return false; },
    get says() { return view ? view.say : ''; },
    get tips() { return tipsOn(); },
    keys: function () { return Object.keys(TIPS); },
    // headless: what a tip says, as it would be said now
    line: function (key) { var l = TIPS[key]; return typeof l === 'function' ? l() : l; }
  };
})();

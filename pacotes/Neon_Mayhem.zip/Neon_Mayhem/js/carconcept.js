// CarConcept GLB loader — built for the game's bundled Three.js r128.
GAME.carConcept = (function () {
  var template = null, loading = false, ready = false, failed = false, urls = [];
  var url = 'media/vehicles/CarConcept.glb';

  function componentArray(type) {
    if (type === 5126) return Float32Array;
    if (type === 5123) return Uint16Array;
    if (type === 5125) return Uint32Array;
    if (type === 5121) return Uint8Array;
    if (type === 5122) return Int16Array;
    if (type === 5120) return Int8Array;
    throw new Error('Componente glTF não suportado: ' + type);
  }
  function components(type) {
    return type === 'SCALAR' ? 1 : type === 'VEC2' ? 2 : type === 'VEC3' ? 3 : type === 'VEC4' ? 4 : 16;
  }
  function accessorData(json, bin, index) {
    var a = json.accessors[index], bv = json.bufferViews[a.bufferView];
    var Ctor = componentArray(a.componentType), n = components(a.type);
    var bytes = Ctor.BYTES_PER_ELEMENT, stride = bv.byteStride || n * bytes;
    var start = (bv.byteOffset || 0) + (a.byteOffset || 0);
    var out = new Ctor(a.count * n), view = new DataView(bin);
    function read(off) {
      if (a.componentType === 5126) return view.getFloat32(off, true);
      if (a.componentType === 5125) return view.getUint32(off, true);
      if (a.componentType === 5123) return view.getUint16(off, true);
      if (a.componentType === 5121) return view.getUint8(off);
      if (a.componentType === 5122) return view.getInt16(off, true);
      return view.getInt8(off);
    }
    for (var i = 0; i < a.count; i++) {
      for (var k = 0; k < n; k++) out[i * n + k] = read(start + i * stride + k * bytes);
    }
    return { array: out, size: n, normalized: !!a.normalized };
  }
  function makeTexture(json, bin, index, cache) {
    if (cache[index]) return cache[index];
    var def = json.textures[index], img = json.images[def.source], bv = json.bufferViews[img.bufferView];
    var begin = bv.byteOffset || 0, end = begin + bv.byteLength;
    var blob = new Blob([bin.slice(begin, end)], { type: img.mimeType || 'image/png' });
    var objectUrl = URL.createObjectURL(blob);
    urls.push(objectUrl);
    var tex = new THREE.TextureLoader().load(objectUrl);
    tex.flipY = false;
    if (THREE.sRGBEncoding !== undefined) tex.encoding = THREE.sRGBEncoding;
    var smp = json.samplers && json.samplers[def.sampler || 0];
    if (smp) {
      tex.wrapS = smp.wrapS === 33648 ? THREE.MirroredRepeatWrapping : smp.wrapS === 33071 ? THREE.ClampToEdgeWrapping : THREE.RepeatWrapping;
      tex.wrapT = smp.wrapT === 33648 ? THREE.MirroredRepeatWrapping : smp.wrapT === 33071 ? THREE.ClampToEdgeWrapping : THREE.RepeatWrapping;
      if (smp.magFilter) tex.magFilter = smp.magFilter;
      if (smp.minFilter) tex.minFilter = smp.minFilter;
    }
    cache[index] = tex;
    return tex;
  }
  function materialFor(json, bin, index, textures) {
    var m = json.materials && json.materials[index] || {};
    var p = m.pbrMetallicRoughness || {}, ext = m.extensions || {};
    var physical = !!(ext.KHR_materials_clearcoat || ext.KHR_materials_transmission);
    var opts = {
      color: p.baseColorFactor ? new THREE.Color().fromArray(p.baseColorFactor) : 0xffffff,
      metalness: p.metallicFactor === undefined ? 0 : p.metallicFactor,
      roughness: p.roughnessFactor === undefined ? 1 : p.roughnessFactor,
      side: m.doubleSided ? THREE.DoubleSide : THREE.FrontSide
    };
    function tex(info) { return info && makeTexture(json, bin, info.index, textures); }
    opts.map = tex(p.baseColorTexture);
    opts.normalMap = tex(m.normalTexture);
    opts.aoMap = tex(m.occlusionTexture);
    opts.emissiveMap = tex(m.emissiveTexture);
    opts.roughnessMap = tex(p.metallicRoughnessTexture);
    opts.metalnessMap = tex(p.metallicRoughnessTexture);
    if (m.emissiveFactor) opts.emissive = new THREE.Color().fromArray(m.emissiveFactor);
    if (m.alphaMode === 'BLEND') { opts.transparent = true; opts.opacity = p.baseColorFactor ? p.baseColorFactor[3] : 0.55; }
    if (m.alphaMode === 'MASK') opts.alphaTest = m.alphaCutoff === undefined ? 0.5 : m.alphaCutoff;
    if (ext.KHR_materials_clearcoat) {
      opts.clearcoat = ext.KHR_materials_clearcoat.clearcoatFactor || 0;
      opts.clearcoatRoughness = ext.KHR_materials_clearcoat.clearcoatRoughnessFactor || 0;
    }
    if (ext.KHR_materials_transmission && ext.KHR_materials_transmission.transmissionFactor > 0) {
      opts.transparent = true; opts.opacity = Math.max(0.22, 1 - ext.KHR_materials_transmission.transmissionFactor * 0.72);
    }
    var made = physical ? new THREE.MeshPhysicalMaterial(opts) : new THREE.MeshStandardMaterial(opts);
    made.name = m.name || '';
    return made;
  }
  function parse(buffer) {
    var dv = new DataView(buffer);
    if (dv.getUint32(0, true) !== 0x46546c67) throw new Error('Arquivo GLB inválido');
    var len = dv.getUint32(8, true), offset = 12, json = null, bin = null;
    while (offset < len) {
      var size = dv.getUint32(offset, true), type = dv.getUint32(offset + 4, true);
      offset += 8;
      if (type === 0x4e4f534a) json = JSON.parse(new TextDecoder().decode(new Uint8Array(buffer, offset, size)).replace(/\u0000+$/g, '').trim());
      else if (type === 0x004e4942) bin = buffer.slice(offset, offset + size);
      offset += size;
    }
    if (!json || !bin) throw new Error('GLB sem dados de modelo');
    var textureCache = {}, materialCache = [], meshes = json.meshes || [];
    function buildMesh(meshIndex) {
      var group = new THREE.Group(), def = meshes[meshIndex];
      (def.primitives || []).forEach(function (prim) {
        var geo = new THREE.BufferGeometry(), attrs = prim.attributes || {};
        Object.keys(attrs).forEach(function (name) {
          var d = accessorData(json, bin, attrs[name]);
          var key = name === 'POSITION' ? 'position' : name === 'NORMAL' ? 'normal' :
            name === 'TEXCOORD_0' ? 'uv' : name === 'TEXCOORD_1' ? 'uv2' : null;
          if (key) geo.setAttribute(key, new THREE.BufferAttribute(d.array, d.size, d.normalized));
        });
        if (prim.indices !== undefined) {
          var id = accessorData(json, bin, prim.indices);
          geo.setIndex(new THREE.BufferAttribute(id.array, 1));
        }
        if (!geo.attributes.normal) geo.computeVertexNormals();
        var mi = prim.material === undefined ? -1 : prim.material;
        if (!materialCache[mi]) materialCache[mi] = materialFor(json, bin, mi, textureCache);
        var mat = materialCache[mi];
        if (mat.aoMap && geo.attributes.uv2) geo.attributes.uv2.needsUpdate = true;
        group.add(new THREE.Mesh(geo, mat));
      });
      return group;
    }
    function buildNode(index) {
      var def = json.nodes[index], obj = new THREE.Group();
      obj.name = def.name || '';
      if (def.matrix) {
        var matrix = new THREE.Matrix4().fromArray(def.matrix);
        matrix.decompose(obj.position, obj.quaternion, obj.scale);
      } else {
        if (def.translation) obj.position.fromArray(def.translation);
        if (def.rotation) obj.quaternion.fromArray(def.rotation);
        if (def.scale) obj.scale.fromArray(def.scale);
      }
      if (def.mesh !== undefined) obj.add(buildMesh(def.mesh));
      (def.children || []).forEach(function (child) { obj.add(buildNode(child)); });
      return obj;
    }
    var sceneDef = (json.scenes || [])[json.scene || 0], root = new THREE.Group();
    (sceneDef.nodes || []).forEach(function (n) { root.add(buildNode(n)); });
    root.updateMatrixWorld(true);
    var bounds = new THREE.Box3().setFromObject(root);
    if (bounds.isEmpty()) throw new Error('O modelo não contém geometria');
    var center = bounds.getCenter(new THREE.Vector3()), min = bounds.min;
    // O carro é alinhado ao padrão do jogo: X = largura, Y = altura, Z = comprimento.
    var wrapper = new THREE.Group();
    root.position.set(-center.x, -min.y, -center.z);
    wrapper.add(root);
    wrapper.scale.set(0.81 * 1.33, 0.90, 1.03); // +33% de largura lateral, sem alterar altura/comprimento
    wrapper.userData.carConceptModel = true;
    wrapper.traverse(function (o) {
      if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; }
    });
    return wrapper;
  }
  function replacePending() {
    if (!GAME.world || !GAME.scene) return;
    GAME.world.cars.forEach(function (car) {
      if (car.type !== 'carconcept' || !car.mesh || !car.mesh.userData.carConceptPending) return;
      var old = car.mesh, fresh = makeMesh(car.color);
      if (!fresh) return;
      fresh.position.copy(old.position);
      fresh.rotation.copy(old.rotation);
      GAME.scene.remove(old);
      GAME.scene.add(fresh);
      car.mesh = fresh;
      car.pos = fresh.position;
      if (GAME.vehicles && GAME.vehicles.dressAll) GAME.vehicles.dressAll();
      if (old.parent) old.parent.remove(old);
    });
  }
  function makeMesh(colorHex) {
    if (!template) return null;
    var clone = template.clone(true), first = null, materialCopies = [];
    clone.traverse(function (o) {
      if (!first && o.isMesh) first = o;
      if (!o.isMesh || !o.material) return;
      function recolor(mat) {
        if (!mat) return mat;
        var copy = materialCopies[mat.uuid];
        if (copy) return copy;
        copy = mat.clone();
        // Only the painted body panels change; glass, tyres, lights and cabin stay original.
        if (/^Paint/i.test(copy.name || '')) copy.color.setHex(colorHex === undefined ? 0xffffff : colorHex);
        materialCopies[mat.uuid] = copy;
        return copy;
      }
      o.material = Array.isArray(o.material) ? o.material.map(recolor) : recolor(o.material);
    });
    clone.userData.bodyMesh = first;
    return clone;
  }
  function load() {
    if (loading || ready || failed) return;
    loading = true;
    fetch(url).then(function (r) {
      if (!r.ok) throw new Error('Não foi possível abrir CarConcept.glb');
      return r.arrayBuffer();
    }).then(function (buffer) {
      template = parse(buffer);
      ready = true; loading = false;
      replacePending();
    }).catch(function (err) {
      failed = true; loading = false;
      if (window.console && console.warn) console.warn('CarConcept:', err);
    });
  }
  function placeholder() {
    var g = new THREE.Group();
    g.userData.carConceptPending = true;
    return g;
  }
  return { load: load, makeMesh: makeMesh, placeholder: placeholder, parseGLB: parse, isReady: function () { return ready; } };
})();

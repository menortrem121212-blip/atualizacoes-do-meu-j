// The papers. After the big moments — a manhunt you slipped, an armoured van
// hit, a getaway stopped by somebody passing, Rico Salazar's last ride — the
// next morning's front page slides in for a few seconds: the masthead, the
// date, the headline, and the scene in newsprint grey (photo.js takes it).
//
// It never stops the game: it hangs at the top of the screen, waits out any
// menu or map, goes when it has been read, and a click sends it away sooner.
// The same kind of story twice reads differently, and a big one comes once.
GAME.herald = (function () {
  var SHOW = 9, COOLDOWN = 150;   // seconds on screen, and between front pages
  var lastT = -1e9, queue = [], showing = null, showT = 0, el = null, printed = [], total = 0;
  var MONTHS = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];
  var DAYS = ['Domingo', 'Segunda-feira', 'Terça-feira', 'Quarta-feira', 'Quinta-feira', 'Sexta-feira', 'Sábado'];

  // what each kind of story says, by how many times it has run before
  var STORIES = {
    manhunt: [
      function (o) { return { head: 'CAÇADA TERMINA EM NADA', sub: 'A ' + o.stars + '-estrelas pela cidade é encerrada. \"Estávamos com eles, e então não estávamos mais\", diz um capitão que prefere não ser identificado.' }; },
      function (o) { return { head: 'POLÍCIA PERDE SUSPEITO — DE NOVO', sub: 'Viaturas, bloqueios e um helicóptero, e ainda assim nenhuma prisão. O departamento diz que está \"revendo os procedimentos\".' }; },
      function (o) { return { head: 'QUEM É O FANTASMA DE COSTA ROSA?', sub: 'Mais uma perseguição de ' + o.stars + '-estrelas, mais uma rua vazia. Policiais, em off, admitem que não têm nome nem rosto.' }; }
    ],
    van: [
      function () { return { head: 'CARRO-FORTE ASSALTADO EM PLENA LUZ DO DIA', sub: 'Seguranças abalados, mas ilesos, enquanto o dinheiro some no ar. Empresa de segurança \"profundamente envergonhada\".' }; },
      function () { return { head: 'OUTRA VAN, OUTRO ASSALTO', sub: 'Empresas de segurança dobram a guarda nas rondas. Seguradoras perguntam se vai bastar.' }; }
    ],
    hero: [
      function (o) { return o.what === 'thief'
        ? { head: 'HERÓI DE PASSAGEM FRUSTRA ASSALTO', sub: 'Um transeunte derruba um ladrão que fugia de ' + (o.shop || 'uma loja') + ' com o apurado. \"Nem pensou duas vezes\", diz uma testemunha.' }
        : { head: 'FUGA TERMINA EM DESTROÇOS', sub: 'Um carro em fuga é tirado da pista por um passante em plena perseguição. O departamento, em nota, agradece.' }; },
      function (o) { return { head: 'MISTERIOSO CAÇADOR DE CRIMINOSOS DA CIDADE ATACA DE NOVO', sub: 'Mais uma prisão, mais um estranho que não quis deixar o nome. A polícia agradece. Quase sempre.' }; }
    ],
    samaritan: [
      function () { return { head: 'O ESTRANHO QUE AJUDA ESTRANHOS', sub: 'Um voo perdido, uma moto roubada, um cachorro sumido, um encontro — Costa Rosa está cheia de gente com uma história sobre a mesma alma generosa. Ninguém pegou o nome.' }; }
    ],
    rico: [
      function () { return { head: 'O ÚLTIMO PASSEIO DE SALAZAR TERMINA NA MARINA', sub: 'Rico Salazar, apontado há muito tempo como dono do porto, some na maré alta. A orla, dizem, agora pertence a Lola Reyes.' }; }
    ],
    heist: [
      function (o) { return { head: 'SAVINGS & LOAN É LIMPO', sub: o.alarm
        ? 'O alarme tocava, a rua estava cheia de policiais, e ainda assim o cofre da orla está vazio. \"Profissionais\", diz um detetive, com algo parecido com respeito.'
        : 'Ninguém ouviu nada. O cofre da orla foi aberto como lata de sardinha, e o carro de fuga tinha uma cor sobre a qual nenhuma testemunha concorda.' }; }
    ]
  };
  var ONCE = { rico: true, samaritan: true, heist: true };

  function prefs() { GAME.prefs = GAME.prefs || {}; return GAME.prefs; }
  function runs(kind) { var h = prefs().herald || {}; return h[kind] || 0; }
  function counted(kind) {
    var p = prefs(); p.herald = p.herald || {};
    p.herald[kind] = (p.herald[kind] || 0) + 1;
    if (GAME.save) GAME.save();
  }
  // the camera's way with the date: today's, in 1986
  function dateline() {
    var now = new Date(), d = new Date(1986, now.getMonth(), now.getDate());
    return DAYS[d.getDay()] + ', ' + MONTHS[d.getMonth()] + ' ' + d.getDate() + ', 1986';
  }

  function build() {
    el = document.getElementById('herald');
    if (!el) return;
    el.addEventListener('click', function () { if (showing) showT = Math.min(showT, 0.35); });
  }
  function busy() {
    return GAME.paused || GAME.mapOpen || GAME.shopOpen || GAME.shareOpen || GAME.lolaOpen ||
      (GAME.photo && (GAME.photo.albumOpen || GAME.photo.viewing));
  }

  // Run a story. Returns whether it made the paper — a once-only story that
  // already ran, or anything inside the cooldown of the last one, does not
  // (unless it is `big`).
  function front(kind, o) {
    var list = STORIES[kind];
    if (!list) return false;
    var n = runs(kind);
    if (ONCE[kind] && n > 0) return false;
    if (!ONCE[kind] && GAME.time - lastT < COOLDOWN) return false;
    lastT = GAME.time;
    var story = list[Math.min(n, list.length - 1)](o || {});
    counted(kind);
    var page = { kind: kind, head: story.head, sub: story.sub, date: dateline(), photo: null };
    printed.push(page); total++;
    if (printed.length > 3) printed.shift();   // (a photograph each: keep only the last few)
    // the scene, as it is right now
    if (GAME.photo && GAME.photo.grab) GAME.photo.grab(function (c) { page.photo = c; if (showing === page) fill(page); });
    queue.push(page);
    if (GAME.track) GAME.track('front-page');
    return true;
  }

  function fill(page) {
    if (!el) return;
    el.querySelector('.hd-date').textContent = page.date + '  ·  Edição final  ·  25¢';
    el.querySelector('.hd-head').textContent = page.head;
    el.querySelector('.hd-sub').textContent = page.sub;
    var ph = el.querySelector('.hd-photo');
    ph.innerHTML = '';
    if (page.photo) ph.appendChild(page.photo);
    ph.style.display = page.photo ? '' : 'none';
  }
  function update(dt) {
    if (!el) return;
    if (showing) {
      // a menu over it puts it away until the game is back
      if (busy()) { el.classList.remove('on'); return; }
      el.classList.add('on');
      showT -= dt;
      if (showT <= 0) { showing = null; el.classList.remove('on'); }
      return;
    }
    if (!queue.length || busy()) return;
    showing = queue.shift();
    showT = SHOW;
    fill(showing);
    el.classList.add('on');
  }

  return {
    init: build,
    front: front,
    update: update,
    get showing() { return showing; },
    get printed() { return printed; },
    get total() { return total; },   // pages run this session (printed keeps the last few)
    // headless hook: let the next story run whatever ran last
    resetCooldown: function () { lastT = -1e9; }
  };
})();
